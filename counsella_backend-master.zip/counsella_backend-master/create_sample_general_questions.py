#!/usr/bin/env python3
"""
Script to create 16 general assessment questions for GeneralTestQuestion model.
Place this file in your Django project root (where manage.py is).
Usage:
  python add_general_questions.py
"""

import os
import sys
import django

# Adjust these as needed for your project name and app location!
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')  # Update your Django project name here
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
django.setup()

from school.models import GeneralTestQuestion

GENERAL_QUESTIONS = [
    {"order": 1, "question_text": "What is your favourite subject in school?"},

    {"order": 2, "question_text": "What are your three favourite activities to do in your free time?"},

    {"order": 3, "question_text": "What are your strengths, and how do you use them in daily life?"},

    {"order": 4, "question_text": "What careers or professions do you find interesting?"},

    {"order": 5, "question_text": "Do you have a role model in a specific profession? Who and Why ?"},

    {"order": 6, "question_text": "Who influences your decisions the most in your family?"},

    {"order": 7, "question_text": "What do your parents do? Which company?"},
   
    {"order":8, "question_text": "How do you handle conflicts with peers or family members?"},
 
    {"order":9, "question_text": "Have you ever attended any workshop, seminar, or event that inspired you? Describe it."}, 

    {"order":10, "question_text": "What type of books, movies, or documentaries do you enjoy? Have you ever been passionate about reading novels or books outside of the academic sphere?"},
   
 
    {"order":11, "question_text": "If you had to plan a vacation, where would you prefer to go: a nearby place, a different state, or an international destination? Why?"},
        

    {"order":12, "question_text": "How do you usually spend your pocket money or allowance? "},

    {"order":13, "question_text": "When buying clothes or accessories, do you prefer branded items, local shops, or online deals?"},
]

def create_questions():
    created, skipped = 0, 0
    for q in GENERAL_QUESTIONS:
        obj, is_created = GeneralTestQuestion.objects.get_or_create(
            order=q["order"],
            defaults={"question_text": q["question_text"]},
        )
        if is_created:
            created += 1
            print(f"Created Q{q['order']}")
        else:
            skipped += 1
            print(f"Skipped existing Q{q['order']}")
    print(f"\nSummary: {created} created, {skipped} skipped. Total: {GeneralTestQuestion.objects.count()} questions.")

if __name__ == "__main__":
    create_questions()