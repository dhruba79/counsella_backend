#!/bin/bash

set -e

echo "🔄 Deploying frontend..."

# Go to frontend directory
cd /home/ubuntu/counsella_frontend

# Reset and pull latest
git reset --hard
git pull origin main

# Install dependencies (if needed)
npm install

# Build the frontend
npm run build

# Deploy to Nginx directory
sudo -n rm -rf /var/www/counsella/*
sudo -n cp -r dist/* /var/www/counsella/
sudo -n chown -R www-data:www-data /var/www/counsella

# Reload nginx (optional)
sudo -n systemctl reload nginx

echo "✅ Frontend deployed to https://counsella.mycareermyway.com"