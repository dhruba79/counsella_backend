#!/usr/bin/env bash
set -e

PROJECT_MAIN_DIR_NAME="dj_mcmy"

# Validate variables
if [ -z "$PROJECT_MAIN_DIR_NAME" ]; then
    echo "Error: PROJECT_MAIN_DIR_NAME is not set. Please set it to your project directory name." >&2
    exit 1
fi

# Backup the database before making any changes
DB_PATH="/home/ubuntu/$PROJECT_MAIN_DIR_NAME/db.sqlite3"
if [ -f "$DB_PATH" ]; then
    echo "Backing up existing database..."
    cp "$DB_PATH" "${DB_PATH}.backup"
fi

# Change ownership to ubuntu user
sudo chown -R ubuntu:ubuntu "/home/ubuntu/$PROJECT_MAIN_DIR_NAME"

# Create virtual environment
echo "Creating virtual environment..."
virtualenv "/home/ubuntu/$PROJECT_MAIN_DIR_NAME/venv"

# Activate virtual environment
echo "Activating virtual environment..."
source "/home/ubuntu/$PROJECT_MAIN_DIR_NAME/venv/bin/activate"

# Install dependencies
echo "Installing Python dependencies..."
pip3 install -r "/home/ubuntu/$PROJECT_MAIN_DIR_NAME/requirements.txt"

echo "Dependencies installed successfully."

# If we have a backup and the database was replaced, restore it
if [ ! -f "$DB_PATH" ] && [ -f "${DB_PATH}.backup" ]; then
    echo "Restoring database from backup..."
    cp "${DB_PATH}.backup" "$DB_PATH"
fi

# Run migrations without resetting the database
echo "Running database migrations..."
python3 manage.py makemigrations
python3 manage.py migrate --no-input

echo "Collecting static files..."
python3 manage.py collectstatic --noinput