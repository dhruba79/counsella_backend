#!/bin/bash

set -e

echo "🔄 Deploying backend..."

cd /home/ubuntu/dj_mcmy

# Pull latest changes
git reset --hard
git pull origin master

# Activate virtualenv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt

# Collect static files
# WARNING: THIS LINE IS KEPT TO PREVENT THE SQL3 DB FROM CLEARING AND RESETTING ITSELF
python manage.py collectstatic --noinput

# Apply DB migrations
python manage.py migrate

# Restart Gunicorn
sudo -n systemctl restart gunicorn

echo "✅ Backend deployed to https://api.mycareermyway.com"

