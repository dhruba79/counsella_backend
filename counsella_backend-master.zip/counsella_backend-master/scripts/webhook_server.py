from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    if not data or 'ref' not in data:
        return 'Ignored', 400

    branch = data['ref']
    repo = data['repository']['name']

    # Fix: match correct GitHub repo name
    if repo == 'counsella_backend' and branch == 'refs/heads/master':
        subprocess.Popen(['/home/ubuntu/deploy_files/deploy_backend.sh'])
        return 'Deploying backend', 200

    elif repo == 'counsella_frontend' and branch == 'refs/heads/main':
        subprocess.Popen(['/home/ubuntu/deploy_files/deploy_frontend.sh'])
        return 'Deploying frontend', 200

    return 'No action', 200

if __name__ == '__main__':
    from waitress import serve
    serve(app, host="0.0.0.0", port=9000)

### sudo journalctl -u webhook -f
