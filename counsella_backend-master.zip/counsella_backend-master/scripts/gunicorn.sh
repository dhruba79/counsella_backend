#!/usr/bin/bash

# Replace {YOUR_PROJECT_MAIN_DIR_NAME} with your actual project directory name
PROJECT_MAIN_DIR_NAME="dj_mcmy"

# Copy gunicorn socket and service files
sudo cp "/home/ubuntu/$PROJECT_MAIN_DIR_NAME/gunicorn/dj_mcmy.socket" "/etc/systemd/system/dj_mcmy.socket"
sudo cp "/home/ubuntu/$PROJECT_MAIN_DIR_NAME/gunicorn/dj_mcmy.service" "/etc/systemd/system/dj_mcmy.service"

# Start and enable Gunicorn service
sudo systemctl start dj_mcmy.socket
sudo systemctl enable dj_mcmy.socket

# Start and enable Gunicorn service
sudo systemctl start dj_mcmy.service
sudo systemctl enable dj_mcmy.service
