import numpy as np
import pandas as pd
import os
import joblib
import datetime
import json
from django.conf import settings
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import logging

logger = logging.getLogger(__name__)

# Define default subject columns if not specified
DEFAULT_SUBJECT_COLS = [
    'Literature', 'Grammer', 'History', 'Geography', 
    'Math', 'Biology', 'Physics', 'Chemistry'
]

def process_csv_file(file_obj, student_id_cols=None):
    """
    Process a CSV file from either a file path or a Django file object
    """
    if student_id_cols is None:
        student_id_cols = ['Name', 'Roll Number']
    
    try:
        # Check if it's a Django file object or a path
        if hasattr(file_obj, 'read'):
            # It's a file-like object
            df = pd.read_csv(file_obj)
        else:
            # It's a file path
            with default_storage.open(file_obj, 'rb') as f:
                df = pd.read_csv(f)
                
        # Clean column names
        df.columns = df.columns.str.strip()
        
        # Print columns for debugging
        logger.info(f"CSV columns: {df.columns.tolist()}")
        
        # Make sure we have the required columns
        for col in student_id_cols:
            if col not in df.columns:
                logger.error(f"Missing required column: {col}")
                raise ValueError(f"The CSV file is missing the required column: {col}")
        
        return df
    except Exception as e:
        logger.error(f"Error processing CSV file: {str(e)}")
        raise ValueError(f"Error processing CSV file: {str(e)}")

def create_simple_prediction_model(half_yearly_data, pretest1_data, pretest2_data,
                                  student_id_cols=None, subject_cols=None):
    """
    Create a simple prediction model based on linear relationships
    when there's not enough historical data for training.
    """
    if student_id_cols is None:
        student_id_cols = ['Name', 'Roll Number']
    
    if subject_cols is None:
        subject_cols = DEFAULT_SUBJECT_COLS
    
    # Check available subjects in the input data
    available_subjects = []
    for subject in subject_cols:
        if subject in half_yearly_data.columns and subject in pretest1_data.columns and subject in pretest2_data.columns:
            available_subjects.append(subject)
    
    logger.info(f"Available subjects for prediction: {available_subjects}")
    
    if not available_subjects:
        logger.error("No matching subjects found in all three exam datasets")
        return None, []
    
    # Create a simple prediction model using fixed coefficients
    # This is a fallback when we don't have enough training data
    simple_models = {}
    
    for subject in available_subjects:
        # Create a simple linear model with fixed coefficients based on domain knowledge
        # General formula: board_score = 0.7 * half_yearly + 0.2 * pretest2 + 0.1 * pretest1 + 5
        model = LinearRegression()
        
        # Mock training with fixed coefficients
        # We set these manually instead of learning from data
        model.coef_ = np.array([0.7, 0.2, 0.1])  # Weights for half_yearly, pretest2, pretest1
        model.intercept_ = 5  # Small boost to account for board exam preparation
        
        simple_models[subject] = {
            'model': model,
            'features': [f'half_{subject}', f'pretest2_{subject}', f'pretest1_{subject}']
        }
    
    # Merge datasets to create prediction dataframe
    merged_data = half_yearly_data[student_id_cols + available_subjects].copy()
    merged_data.columns = student_id_cols + [f'half_{col}' for col in available_subjects]
    
    # Add pretest1 data
    pretest1_subset = pretest1_data[student_id_cols + available_subjects].copy()
    pretest1_subset.columns = student_id_cols + [f'pretest1_{col}' for col in available_subjects]
    merged_data = pd.merge(merged_data, pretest1_subset, on=student_id_cols, how='inner')
    
    # Add pretest2 data
    pretest2_subset = pretest2_data[student_id_cols + available_subjects].copy()
    pretest2_subset.columns = student_id_cols + [f'pretest2_{col}' for col in available_subjects]
    merged_data = pd.merge(merged_data, pretest2_subset, on=student_id_cols, how='inner')
    
    # Handle missing values
    for subject in available_subjects:
        for prefix in ['half_', 'pretest1_', 'pretest2_']:
            col = f"{prefix}{subject}"
            if col in merged_data.columns:
                # Fix the FutureWarning with proper pandas method
                merged_data[col] = merged_data[col].fillna(merged_data[col].mean())
    
    return simple_models, merged_data

def predict_board_scores_simple(half_yearly_file, pretest1_file, pretest2_file, 
                               school_id=None, academic_year=None):
    """
    A simplified version of prediction when no trained models are available.
    """
    try:
        logger.info(f"Starting simplified board score prediction for academic year {academic_year}")
        
        # Load and process CSV files
        student_id_cols = ['Name', 'Roll Number']
        
        # Process input files
        half_data = process_csv_file(half_yearly_file, student_id_cols)
        pretest1_data = process_csv_file(pretest1_file, student_id_cols)
        pretest2_data = process_csv_file(pretest2_file, student_id_cols)
        
        # Get list of subjects common to all three datasets
        all_subjects = []
        for subject in DEFAULT_SUBJECT_COLS:
            if subject in half_data.columns and subject in pretest1_data.columns and subject in pretest2_data.columns:
                all_subjects.append(subject)
        
        logger.info(f"Found common subjects across datasets: {all_subjects}")
        
        if not all_subjects:
            logger.error("No common subjects found across all three datasets")
            return {
                'success': False,
                'error': "No common subjects found across all three datasets"
            }
        
        # Create simple prediction model and prepare data
        models, predict_data = create_simple_prediction_model(
            half_data, pretest1_data, pretest2_data,
            student_id_cols=student_id_cols,
            subject_cols=all_subjects
        )
        
        if models is None or predict_data.empty:
            logger.error("Failed to create prediction model or process data")
            return {
                'success': False,
                'error': "Failed to create prediction model or process data"
            }
        
        # Make predictions
        predictions = predict_data[student_id_cols].copy()
        
        for subject in all_subjects:
            model_info = models[subject]
            model = model_info['model']
            features = model_info['features']
            
            # Make sure all features are available
            if all(feature in predict_data.columns for feature in features):
                # Make prediction
                X_pred = predict_data[features]
                pred = model.predict(X_pred)
                
                # Round predictions to whole numbers and cap at 100
                predictions[f'predicted_board_{subject}'] = np.minimum(np.round(pred), 100)
                
                # Also add a simpler prediction for reference (half-yearly + 10%)
                predictions[f'simple_linear_{subject}'] = np.minimum(
                    np.round(predict_data[f'half_{subject}'] * 1.1), 100
                )
        
        # Add academic year to predictions if provided
        if academic_year:
            predictions['Academic_Year'] = academic_year
        
        # Save predictions to CSV
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f'predicted_board_results_{academic_year}_{timestamp}.csv'
        
        # Save to Django's storage
        if school_id:
            output_path = f'predictions/school_{school_id}/{academic_year}/{output_filename}'
        else:
            output_path = f'predictions/{academic_year}/{output_filename}'
        
        # Ensure the directory exists
        output_dir = os.path.dirname(os.path.join(settings.MEDIA_ROOT, output_path))
        os.makedirs(output_dir, exist_ok=True)
        
        # Save the CSV to storage
        csv_path = os.path.join(settings.MEDIA_ROOT, output_path)
        predictions.to_csv(csv_path, index=False)
        
        logger.info(f"Predictions saved to {csv_path}")
        
        # Also save through Django's storage system
        with open(csv_path, 'rb') as f:
            storage_path = default_storage.save(output_path, ContentFile(f.read()))
            
        # Create a URL for accessing the file
        file_url = os.path.join(settings.MEDIA_URL, storage_path)
        
        return {
            'success': True,
            'predictions': predictions,
            'file_path': output_path,
            'file_url': file_url,
            'timestamp': timestamp
        }
        
    except Exception as e:
        logger.error(f"Error in simplified prediction: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e)
        }