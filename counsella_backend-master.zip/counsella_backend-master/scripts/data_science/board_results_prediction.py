import numpy as np
import pandas as pd
import os
import joblib
import datetime
import json
from django.conf import settings
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import logging

logger = logging.getLogger(__name__)

# Define default subject columns if not specified
DEFAULT_SUBJECT_COLS = [
    'Literature', 'Grammer', 'History', 'Geography', 
    'Math', 'Biology', 'Physics', 'Chemistry'
]

def process_csv_file(file_obj, student_id_cols=None):
    """
    Process a CSV file from either a file path or a Django file object
    """
    if student_id_cols is None:
        student_id_cols = ['Name', 'Roll Number']
    
    try:
        # Check if it's a Django file object or a path
        if hasattr(file_obj, 'read'):
            # It's a file-like object
            df = pd.read_csv(file_obj)
            # Reset file pointer to beginning for potential reuse
            if hasattr(file_obj, 'seek'):
                file_obj.seek(0)
        else:
            # It's a file path
            with default_storage.open(file_obj, 'rb') as f:
                df = pd.read_csv(f)
                
        # Clean column names
        df.columns = df.columns.str.strip()
        
        # Print columns for debugging
        logger.info(f"CSV columns: {df.columns.tolist()}")
        
        # Make sure we have the required columns
        for col in student_id_cols:
            if col not in df.columns:
                logger.error(f"Missing required column: {col}")
                raise ValueError(f"The CSV file is missing the required column: {col}")
        
        return df
    except Exception as e:
        logger.error(f"Error processing CSV file: {str(e)}")
        raise ValueError(f"Error processing CSV file: {str(e)}")

def create_combined_dataset(half_data, pretest1_data, pretest2_data, board_data=None, 
                           student_id_cols=None, subject_cols=None,
                           is_prediction=False):
    """
    Create a combined dataset for training or prediction
    """
    if student_id_cols is None:
        student_id_cols = ['Name', 'Roll Number']
    
    if subject_cols is None:
        subject_cols = DEFAULT_SUBJECT_COLS
    
    # Identify available subjects across datasets
    available_subjects = []
    for subject in subject_cols:
        if subject in half_data.columns and subject in pretest1_data.columns and subject in pretest2_data.columns:
            # For training, we also need the subject in board data
            if not is_prediction and board_data is not None:
                if subject in board_data.columns:
                    available_subjects.append(subject)
            else:
                available_subjects.append(subject)
    
    if not available_subjects:
        logger.error("No common subjects found across datasets")
        raise ValueError("No common subjects found across all datasets")
    
    logger.info(f"Common subjects across datasets: {available_subjects}")
    
    # Merge datasets on student identifiers
    data = half_data[student_id_cols + available_subjects].copy()
    
    # Rename columns to distinguish between different exams
    data.columns = student_id_cols + [f'half_{col}' for col in available_subjects]
    
    # Merge pretest1 data
    pretest1_subset = pretest1_data[student_id_cols + available_subjects].copy()
    pretest1_subset.columns = student_id_cols + [f'pretest1_{col}' for col in available_subjects]
    data = pd.merge(data, pretest1_subset, on=student_id_cols, how='inner')
    
    # Merge pretest2 data
    pretest2_subset = pretest2_data[student_id_cols + available_subjects].copy()
    pretest2_subset.columns = student_id_cols + [f'pretest2_{col}' for col in available_subjects]
    data = pd.merge(data, pretest2_subset, on=student_id_cols, how='inner')
    
    # For training data, merge board results as well
    if not is_prediction and board_data is not None:
        board_subset = board_data[student_id_cols + available_subjects].copy()
        board_subset.columns = student_id_cols + [f'board_{col}' for col in available_subjects]
        data = pd.merge(data, board_subset, on=student_id_cols, how='inner')
    
    # Check if we have enough data
    if len(data) == 0:
        logger.error("No matching student records found across datasets")
        raise ValueError("No matching student records found across datasets")
    
    logger.info(f"Combined dataset has {len(data)} student records")
    
    # Fill missing values with mean for each exam type
    for prefix in ['half_', 'pretest1_', 'pretest2_', 'board_']:
        cols = [col for col in data.columns if col.startswith(prefix)]
        for col in cols:
            if col in data.columns:
                # Fix for FutureWarning - don't use inplace=True
                data[col] = data[col].fillna(data[col].mean())
    
    # Add features based on the known linear relationships
    for subject in available_subjects:
        # Create differences between exam scores
        if f'half_{subject}' in data.columns and f'pretest1_{subject}' in data.columns:
            data[f'half_pretest1_diff_{subject}'] = data[f'half_{subject}'] - data[f'pretest1_{subject}']
        
        if f'half_{subject}' in data.columns and f'pretest2_{subject}' in data.columns:
            data[f'half_pretest2_diff_{subject}'] = data[f'half_{subject}'] - data[f'pretest2_{subject}']
        
        # Create simple linear prediction feature
        if f'half_{subject}' in data.columns:
            data[f'linear_pred_{subject}'] = data[f'half_{subject}'] + 10
    
    return data

def train_subject_models(train_data, subject_cols=None):
    """
    Train separate regression models for each subject
    """
    if subject_cols is None:
        # Find available subjects in training data
        subject_cols = []
        for col in train_data.columns:
            if col.startswith('board_'):
                subject = col.replace('board_', '')
                subject_cols.append(subject)
    
    if not subject_cols:
        logger.error("No target subjects found in training data")
        raise ValueError("No target subjects found in training data")
    
    models = {}
    metrics = {}
    test_predictions = {}
    
    for subject in subject_cols:
        try:
            # Define features and target
            target = f'board_{subject}'
            
            if target not in train_data.columns:
                logger.warning(f"Target column {target} not found in training data, skipping subject")
                continue
            
            # Define possible features
            feature_patterns = [
                f'half_{subject}', 
                f'pretest1_{subject}', 
                f'pretest2_{subject}',
                f'half_pretest1_diff_{subject}',
                f'half_pretest2_diff_{subject}',
                f'linear_pred_{subject}'
            ]
            
            # Check which features exist
            features = [f for f in feature_patterns if f in train_data.columns]
            
            if not features:
                logger.warning(f"No valid features found for {subject}, skipping")
                continue
                
            # Check if we have enough data
            min_training_records = 10
            if len(train_data) < min_training_records:
                logger.warning(f"Not enough data to train model for {subject}. Only {len(train_data)} records. Need at least {min_training_records}.")
                continue
            
            X = train_data[features]
            y = train_data[target]
            
            # Check correlation with target
            correlations = X.corrwith(y).abs()
            logger.info(f"Feature correlations for {subject}: {correlations.to_dict()}")
            
            # Filter features with correlation > 0.4 (relaxed threshold)
            strong_features = correlations[correlations > 0.4].index.tolist()
            
            if not strong_features:
                logger.warning(f"No strong features for {subject}. Using all features.")
                strong_features = features
            
            logger.info(f"Selected features for {subject}: {strong_features}")
            
            X = train_data[strong_features]
            
            # Split data into training and testing sets
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Train linear regression model
            model = LinearRegression()
            model.fit(X_train, y_train)
            
            # Evaluate model
            y_pred = model.predict(X_test)
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            
            # Store test predictions for analysis
            test_predictions[subject] = {
                'actual': y_test,
                'predicted': y_pred,
                'half_yearly': X_test[f'half_{subject}'] if f'half_{subject}' in X_test else None,
                'linear_pred': X_test[f'linear_pred_{subject}'] if f'linear_pred_{subject}' in X_test else None
            }
            
            # Store model and metrics
            models[subject] = {
                'model': model,
                'features': strong_features
            }
            
            metrics[subject] = {
                'mse': mse,
                'r2': r2,
                'coefficients': dict(zip(strong_features, model.coef_)),
                'intercept': model.intercept_
            }
            
            logger.info(f"Model for {subject}: R2={r2:.4f}, MSE={mse:.4f}")
            
        except Exception as e:
            logger.error(f"Error training model for {subject}: {str(e)}")
    
    if not models:
        logger.error("Failed to train any subject models")
        raise ValueError("Failed to train any subject models")
        
    return models, metrics, test_predictions

def predict_board_results(models, predict_data, subject_cols=None):
    """
    Predict board results for each subject using trained models
    """
    if subject_cols is None:
        # Use subjects from models
        subject_cols = list(models.keys())
    
    # Check if there are student identifiers
    if 'Name' not in predict_data.columns or 'Roll Number' not in predict_data.columns:
        logger.error("Prediction data must include 'Name' and 'Roll Number' columns")
        raise ValueError("Prediction data must include 'Name' and 'Roll Number' columns")
    
    predictions = predict_data[['Name', 'Roll Number']].copy()
    
    for subject in subject_cols:
        if subject not in models:
            logger.warning(f"No model available for {subject}")
            continue
            
        model_info = models[subject]
        model = model_info['model']
        features = model_info['features']
        
        # Check if all features exist in the data
        if not all(feature in predict_data.columns for feature in features):
            missing_features = [f for f in features if f not in predict_data.columns]
            logger.warning(f"Missing features for {subject}: {missing_features}")
            continue
        
        # Make prediction
        X_pred = predict_data[features]
        pred = model.predict(X_pred)
        
        # Round predictions to whole numbers and cap between 0-100
        predictions[f'predicted_board_{subject}'] = np.maximum(0, np.minimum(np.round(pred), 100))
        
        # Add linear prediction as comparison (also cap at 100)
        if f'linear_pred_{subject}' in predict_data.columns:
            predictions[f'simple_linear_{subject}'] = np.maximum(0, np.minimum(
                np.round(predict_data[f'linear_pred_{subject}']), 100
            ))
    
    return predictions

def get_models_dir():
    """Get the directory where models are stored"""
    # Create a models directory in MEDIA_ROOT if it doesn't exist
    models_dir = os.path.join(settings.MEDIA_ROOT, 'models')
    os.makedirs(models_dir, exist_ok=True)
    return models_dir

def save_models(models, metrics, subject_cols=None, school_id=None):
    """
    Save trained models, their configurations, and performance metrics
    """
    if subject_cols is None:
        subject_cols = list(models.keys())
    
    logger.info("Saving models to disk...")
    
    # Get models directory
    models_dir = get_models_dir()
    
    # Create school-specific subfolder if school_id is provided
    if school_id:
        models_dir = os.path.join(models_dir, str(school_id))
        os.makedirs(models_dir, exist_ok=True)
    
    # Get current timestamp for versioning
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Create model info to save alongside the model files
    model_info = {
        'timestamp': timestamp,
        'subjects': subject_cols,
        'metrics': {},
        'features_used': {}
    }
    
    # Save each subject model
    for subject in subject_cols:
        if subject not in models:
            continue
            
        # Save the model using joblib
        model_file = os.path.join(models_dir, f'{subject}_model_{timestamp}.joblib')
        joblib.dump(models[subject]['model'], model_file)
        
        # Store metadata
        model_info['metrics'][subject] = {
            'mse': metrics[subject]['mse'],
            'r2': metrics[subject]['r2'],
            'intercept': float(metrics[subject]['intercept'])
        }
        model_info['features_used'][subject] = models[subject]['features']
    
    # Save model info as JSON
    info_file = os.path.join(models_dir, f'model_info_{timestamp}.json')
    with open(info_file, 'w') as f:
        # Convert any numpy types to native Python types for JSON serialization
        for subject in subject_cols:
            if subject in metrics:
                coeffs = metrics[subject]['coefficients']
                model_info['metrics'][subject]['coefficients'] = {
                    k: float(v) for k, v in coeffs.items()
                }
        
        json.dump(model_info, f, indent=4)
    
    # Save a link to the latest model
    latest_file = os.path.join(models_dir, 'latest_model.txt')
    with open(latest_file, 'w') as f:
        f.write(timestamp)
    
    logger.info(f"Models saved with timestamp: {timestamp}")
    return timestamp

def load_models(timestamp=None, school_id=None):
    """
    Load saved models and their configurations
    If timestamp is None, load the latest model
    """
    logger.info("Loading models from disk...")
    
    # Get models directory
    models_dir = get_models_dir()
    
    # Use school-specific subfolder if school_id is provided
    if school_id:
        school_models_dir = os.path.join(models_dir, str(school_id))
        if os.path.exists(school_models_dir):
            models_dir = school_models_dir
        else:
            logger.warning(f"No school-specific models found for school {school_id}. Using global models.")
    
    if not os.path.exists(models_dir):
        logger.error(f"Models directory not found: {models_dir}")
        return None, None
    
    # Determine which model version to load
    if timestamp is None:
        # Load the latest model
        latest_file = os.path.join(models_dir, 'latest_model.txt')
        if not os.path.exists(latest_file):
            logger.error("No saved models found (latest_model.txt missing).")
            return None, None
        
        try:
            with open(latest_file, 'r') as f:
                timestamp = f.read().strip()
        except Exception as e:
            logger.error(f"Error reading latest model timestamp: {str(e)}")
            return None, None
    
    # Load model info
    info_file = os.path.join(models_dir, f'model_info_{timestamp}.json')
    if not os.path.exists(info_file):
        logger.error(f"Model info file not found: {info_file}")
        return None, None
    
    try:
        with open(info_file, 'r') as f:
            model_info = json.load(f)
    except Exception as e:
        logger.error(f"Error reading model info: {str(e)}")
        return None, None
    
    # Load models for each subject
    models = {}
    subject_cols = model_info['subjects']
    
    for subject in subject_cols:
        model_file = os.path.join(models_dir, f'{subject}_model_{timestamp}.joblib')
        if not os.path.exists(model_file):
            logger.warning(f"Model file not found: {model_file}")
            continue
        
        try:
            # Load the model
            model = joblib.load(model_file)
            
            # Store model and its features
            models[subject] = {
                'model': model,
                'features': model_info['features_used'][subject]
            }
        except Exception as e:
            logger.error(f"Error loading model for {subject}: {str(e)}")
    
    if not models:
        logger.warning("No models were successfully loaded")
        return None, None
        
    metrics = {subject: model_info['metrics'][subject] for subject in subject_cols if subject in model_info['metrics']}
    logger.info(f"Successfully loaded models from timestamp: {timestamp}")
    
    return models, metrics

def train_prediction_model(half_yearly_file, pretest1_file, pretest2_file, board_file=None, 
                          school_id=None, student_id_cols=None, subject_cols=None, retrain=True):
    """
    Train a prediction model using the provided files.
    If board_file is not provided, attempts to load existing models.
    Returns models for prediction.
    """
    if student_id_cols is None:
        student_id_cols = ['Name', 'Roll Number']
    
    if subject_cols is None:
        subject_cols = DEFAULT_SUBJECT_COLS
    
    logger.info(f"Processing files for prediction model")
    
    try:
        # Process input files
        half_data = process_csv_file(half_yearly_file, student_id_cols)
        pretest1_data = process_csv_file(pretest1_file, student_id_cols)
        pretest2_data = process_csv_file(pretest2_file, student_id_cols)
        
        # Check if we have board data for training
        if board_file:
            logger.info("Board data provided - training new models")
            board_data = process_csv_file(board_file, student_id_cols)
            
            # Create training dataset
            train_data = create_combined_dataset(
                half_data, pretest1_data, pretest2_data, board_data,
                student_id_cols=student_id_cols, subject_cols=subject_cols,
                is_prediction=False
            )
            
            # Train models
            models, metrics, _ = train_subject_models(train_data, subject_cols)
            
            # Save models if requested
            if retrain:
                save_models(models, metrics, subject_cols, school_id)
            
            # Create prediction dataset for the same data (for testing)
            predict_data = create_combined_dataset(
                half_data, pretest1_data, pretest2_data, None,
                student_id_cols=student_id_cols, subject_cols=subject_cols,
                is_prediction=True
            )
            
            return models, predict_data
        else:
            logger.info("No board data provided - using existing models for prediction")
            # Load existing models
            models, _ = load_models(school_id=school_id)
            
            if not models:
                logger.error("No existing models found and no board data provided for training")
                raise ValueError("No existing models found and no board data provided for training")
            
            # Create prediction dataset
            predict_data = create_combined_dataset(
                half_data, pretest1_data, pretest2_data, None,
                student_id_cols=student_id_cols, subject_cols=subject_cols,
                is_prediction=True
            )
            
            return models, predict_data
            
    except Exception as e:
        logger.error(f"Error training prediction model: {str(e)}")
        raise ValueError(f"Error training prediction model: {str(e)}")

def predict_board_scores(half_yearly_file, pretest1_file, pretest2_file, board_file=None, 
                        school_id=None, academic_year=None, retrain=False):
    """
    Main function to predict board scores using input files
    """
    try:
        logger.info(f"Starting board score prediction for academic year {academic_year}")
        
        # First try to load the existing models
        models, metrics = load_models(school_id=school_id)
        
        if retrain and board_file:
            # If retraining is requested with board data, try to train new models
            try:
                logger.info("Attempting to train new models with provided data...")
                new_models, predict_data = train_prediction_model(
                    half_yearly_file, pretest1_file, pretest2_file, board_file,
                    school_id=school_id, retrain=retrain
                )
                models = new_models  # Use the newly trained models
            except Exception as e:
                logger.warning(f"Error training new models: {str(e)}. Using existing models instead.")
        
        # If no models available, use fallback approach
        if not models:
            logger.warning("No models available. Using fallback prediction approach.")
            return predict_board_scores_fallback(
                half_yearly_file, pretest1_file, pretest2_file,
                school_id=school_id, academic_year=academic_year
            )
        
        # Process prediction data regardless of whether training succeeded
        try:
            # Process input files
            half_data = process_csv_file(half_yearly_file)
            pretest1_data = process_csv_file(pretest1_file)
            pretest2_data = process_csv_file(pretest2_file)
            
            # Try to create prediction dataset with strict matching
            try:
                predict_data = create_combined_dataset(
                    half_data, pretest1_data, pretest2_data, None,
                    student_id_cols=['Name', 'Roll Number'],
                    is_prediction=True
                )
            except ValueError as e:
                logger.warning(f"Strict matching failed: {str(e)}. Trying with more flexible matching...")
                # Fall back to more flexible matching - just use Roll Number
                predict_data = create_flexible_dataset(
                    half_data, pretest1_data, pretest2_data,
                    student_id_cols=['Roll Number']
                )
            
            # Make predictions
            predictions = predict_board_results(models, predict_data)
            
            # Add academic year to predictions if provided
            if academic_year:
                predictions['Academic_Year'] = academic_year
            
            # Save predictions to CSV
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f'predicted_board_results_{academic_year}_{timestamp}.csv'
            
            # Save to Django's storage
            if school_id:
                output_path = f'predictions/school_{school_id}/{academic_year}/{output_filename}'
            else:
                output_path = f'predictions/{academic_year}/{output_filename}'
            
            # Ensure the directory exists
            output_dir = os.path.dirname(os.path.join(settings.MEDIA_ROOT, output_path))
            os.makedirs(output_dir, exist_ok=True)
            
            # Save the CSV to storage
            csv_path = os.path.join(settings.MEDIA_ROOT, output_path)
            predictions.to_csv(csv_path, index=False)
            
            logger.info(f"Predictions saved to {csv_path}")
            
            # Also save through Django's storage system
            with open(csv_path, 'rb') as f:
                storage_path = default_storage.save(output_path, ContentFile(f.read()))
                
            # Create a URL for accessing the file
            file_url = os.path.join(settings.MEDIA_URL, storage_path)
            
            return {
                'success': True,
                'predictions': predictions,
                'file_path': output_path,
                'file_url': file_url,
                'timestamp': timestamp
            }
            
        except Exception as e:
            logger.error(f"Error processing prediction data: {str(e)}")
            if models:
                logger.info("Attempting fallback prediction approach...")
                return predict_board_scores_fallback(
                    half_yearly_file, pretest1_file, pretest2_file,
                    school_id=school_id, academic_year=academic_year
                )
            else:
                raise
        
    except Exception as e:
        logger.error(f"Error in predict_board_scores: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e)
        }

def create_flexible_dataset(half_data, pretest1_data, pretest2_data, student_id_cols=None):
    """
    Create a combined dataset with more flexible matching.
    This uses outer joins and fills missing values.
    """
    if student_id_cols is None:
        student_id_cols = ['Roll Number']
    
    # Get all subjects
    subjects = [
        'Literature', 'Grammer', 'History', 'Geography', 
        'Math', 'Biology', 'Physics', 'Chemistry'
    ]
    
    # Start with half yearly data
    half_subset = half_data[student_id_cols + subjects].copy()
    half_subset.columns = student_id_cols + [f'half_{s}' for s in subjects]
    
    # Merge with pretest1 using outer join
    pretest1_subset = pretest1_data[student_id_cols + subjects].copy()
    pretest1_subset.columns = student_id_cols + [f'pretest1_{s}' for s in subjects]
    
    data = pd.merge(half_subset, pretest1_subset, on=student_id_cols, how='outer')
    logger.info(f"After flexible merge with pretest1: {len(data)} records")
    
    # Merge with pretest2 using outer join
    pretest2_subset = pretest2_data[student_id_cols + subjects].copy()
    pretest2_subset.columns = student_id_cols + [f'pretest2_{s}' for s in subjects]
    
    data = pd.merge(data, pretest2_subset, on=student_id_cols, how='outer')
    logger.info(f"After flexible merge with pretest2: {len(data)} records")
    
    # Fill missing values
    for col in data.columns:
        if col not in student_id_cols:
            # Fill missing with mean of that column
            data[col] = data[col].fillna(data[col].mean())
    
    # Add derived features
    for subject in subjects:
        # Create differences
        if f'half_{subject}' in data.columns and f'pretest1_{subject}' in data.columns:
            data[f'half_pretest1_diff_{subject}'] = data[f'half_{subject}'] - data[f'pretest1_{subject}']
        
        if f'half_{subject}' in data.columns and f'pretest2_{subject}' in data.columns:
            data[f'half_pretest2_diff_{subject}'] = data[f'half_{subject}'] - data[f'pretest2_{subject}']
        
        # Linear prediction
        if f'half_{subject}' in data.columns:
            data[f'linear_pred_{subject}'] = data[f'half_{subject}'] + 10
    
    return data

def predict_board_scores_fallback(half_yearly_file, pretest1_file, pretest2_file, 
                                school_id=None, academic_year=None):
    """
    Fallback prediction method when no models are available or matching fails
    """
    logger.info("Using fallback prediction method based on weighted averages")
    
    try:
        # Process input files
        half_data = process_csv_file(half_yearly_file)
        pretest1_data = process_csv_file(pretest1_file)
        pretest2_data = process_csv_file(pretest2_file)
        
        # Get all students from half-yearly (our primary source)
        id_cols = ['Name', 'Roll Number']
        subject_cols = [
            'Literature', 'Grammer', 'History', 'Geography', 
            'Math', 'Biology', 'Physics', 'Chemistry'
        ]
        
        # Create predictions for all students in half-yearly
        predictions = half_data[id_cols].copy()
        
        # For each student and subject, use weighted formula
        for subject in subject_cols:
            # Create student lookup dictionaries
            half_scores = dict(zip(half_data['Roll Number'], half_data[subject]))
            pretest1_scores = dict(zip(pretest1_data['Roll Number'], pretest1_data[subject]))
            pretest2_scores = dict(zip(pretest2_data['Roll Number'], pretest2_data[subject]))
            
            # Calculate predictions
            pred_scores = []
            for roll_num in predictions['Roll Number']:
                half = half_scores.get(roll_num, 0)
                pre1 = pretest1_scores.get(roll_num, 0)
                pre2 = pretest2_scores.get(roll_num, 0)
                
                # Use weighted formula: 70% half-yearly, 20% pretest2, 10% pretest1, +5 points
                pred = (0.7 * half) + (0.2 * pre2) + (0.1 * pre1) + 5
                pred_scores.append(min(100, max(0, round(pred))))
            
            predictions[f'predicted_board_{subject}'] = pred_scores
            predictions[f'simple_linear_{subject}'] = [min(100, h + 10) for h in half_data[subject]]
        
        # Add academic year
        if academic_year:
            predictions['Academic_Year'] = academic_year
        
        # Save predictions to CSV
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f'predicted_board_results_fallback_{academic_year}_{timestamp}.csv'
        
        # Save to Django's storage
        if school_id:
            output_path = f'predictions/school_{school_id}/{academic_year}/{output_filename}'
        else:
            output_path = f'predictions/{academic_year}/{output_filename}'
        
        # Ensure the directory exists
        output_dir = os.path.dirname(os.path.join(settings.MEDIA_ROOT, output_path))
        os.makedirs(output_dir, exist_ok=True)
        
        # Save the CSV to storage
        csv_path = os.path.join(settings.MEDIA_ROOT, output_path)
        predictions.to_csv(csv_path, index=False)
        
        logger.info(f"Fallback predictions saved to {csv_path}")
        
        # Also save through Django's storage system
        with open(csv_path, 'rb') as f:
            storage_path = default_storage.save(output_path, ContentFile(f.read()))
            
        # Create a URL for accessing the file
        file_url = os.path.join(settings.MEDIA_URL, storage_path)
        
        return {
            'success': True,
            'predictions': predictions,
            'file_path': output_path,
            'file_url': file_url,
            'timestamp': timestamp,
            'method': 'fallback'
        }
    
    except Exception as e:
        logger.error(f"Error in fallback prediction: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': f"Fallback prediction failed: {str(e)}"
        }

# Simple function for testing in standalone mode
def test_prediction():
    """Simple function to test the prediction functionality"""
    from django.conf import settings
    import os
    
    # Define test file paths
    test_dir = os.path.join(settings.BASE_DIR, 'test_data')
    half_yearly_file = os.path.join(test_dir, 'half_yearly.csv')
    pretest1_file = os.path.join(test_dir, 'pretest1.csv')
    pretest2_file = os.path.join(test_dir, 'pretest2.csv')
    board_file = os.path.join(test_dir, 'board.csv')
    
    # Run prediction
    result = predict_board_scores(
        half_yearly_file=half_yearly_file,
        pretest1_file=pretest1_file,
        pretest2_file=pretest2_file,
        board_file=board_file,
        academic_year=2024,
        retrain=True
    )
    
    if result['success']:
        print(f"Prediction successful! Results saved to: {result['file_path']}")
        print(f"First 5 predictions: {result['predictions'].head()}")
    else:
        print(f"Prediction failed: {result['error']}")

if __name__ == "__main__":
    # Run test if this file is executed directly
    test_prediction()