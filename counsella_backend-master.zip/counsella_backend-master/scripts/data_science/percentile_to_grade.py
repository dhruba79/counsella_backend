import numpy  as np 
import pandas as pd 
import matplotlib.pyplot as plt
import sys 

subjects = [ "Literature","Grammer","History","Geography","Biology","Physics","Chemistry","Math"];

#Description: This function calculate grade from percentile marks .
#It should be iterated over each subject.
#Input:
# dataset : Panda Data Frame 
# Subject: A string describing subject Eg: Garmmer , Physics.
# Output :
#  dataset : Output data frame 
# Pre condition : None,
#----------------------------------------------------------

def calculate_grade_each_subject(dataset, subject):
    length = len(dataset)
  
    for i in range(0, length):
        marks = dataset[subject].iloc[i]

        if marks >= 90:
            dataset.loc[i, subject] = 'Excellent'
        elif marks >= 80:
            dataset.loc[i, subject] = 'Good' 
        elif marks >= 60:
            dataset.loc[i, subject] = 'Fair'
        elif marks >= 40:
            dataset.loc[i, subject] = 'Average'
        else:
            dataset.loc[i, subject] = 'Poor'


# Description: This function calculate percentile of all the subjects 
# Input :
#   input_file : Input file contains absolute marks
# Output : 
#   output_file : The output file contains percentile mark(s)
#---------------------------------------------------------------------

def calculate_grades(input_file, output_file):
    dataset = pd.read_csv(input_file)
   
    # Loop through the array and print each subject
    for subject in subjects:
        calculate_grade_each_subject(dataset, subject)

    dataset.to_csv(output_file, index=False)
    return dataset  # Return the dataset for use in the API


if __name__ == "__main__":
   
   # sys.argv contains the command line arguments
   # argc = len(sys.argv) 
   # Check if the required number of arguments is passed
   # if argc != 2:
   #     print("Usage: script.py <arg1>")

   if len(sys.argv) != 2:
        print("Usage: script.py <input_file>")
        sys.exit(1)
        
   input_file = sys.argv[1]
   out_file = "grade_file.csv"
   calculate_grades(input_file, out_file)

#    input_file = sys.argv[1]

# out_file = "grade_file.csv" 
# calculate_grades(input_file, out_file) 
