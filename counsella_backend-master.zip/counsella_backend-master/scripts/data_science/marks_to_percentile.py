import numpy  as np 
import pandas as pd 
import matplotlib.pyplot as plt
import sys 
import argparse



all_subjects  = [ "Literature" , "Grammer", "History", "Geography" , "Math" , "Biology", "Physics" , "Chemistry" ]

#Description: This function calculate percentile from absolute marks .
#It should be iterated over each subject.
#Input:
# dataset : Panda Data Frame 
# Subject: A string describing subject Eg: Garmmer , Physics.
# Output :
#  dataset : Output data frame 
# Pre condition : None,
#----------------------------------------------------------

def calculate_percentile_each_subject(dataset, subject):
   length = len(dataset)
   print(subject)

   # Make sure we have data to process
   if length == 0:
       print(f"Warning: Empty dataset for {subject}")
       return
   
   arr = np.zeros(0)
   percentile = 0

   # Create percentile Array 
   for i in range(0,101):
     ptile_value = np.percentile(dataset[subject], percentile)
     arr = np.insert(arr, i, ptile_value)
     percentile += 1

   # Populate output data frame, but only up to the actual length of the dataset
   for i in range(0, length):  # Change this from 100 to length
      for j in range(0, 100):
          # Ensure we don't go out of bounds
          if j+1 >= len(arr):
              break
              
          if ((arr[j] < dataset[subject].iloc[i]) and (dataset[subject].iloc[i] <= arr[j+1])):
               # Safer implementation of the k loop
               for k in range(j+1, min(100, len(arr))):
                  if k < len(arr) and arr[k] == dataset[subject].iloc[i]:
                      j = j+1
               dataset.loc[i, subject] = j + 1
               break
   


# Description: This function calculate percentile of all the subjects 
# Input :
#   input_file : Input file contains absolute marks
# Output : 
#   output_file : The output file contains percentile mark(s)
#---------------------------------------------------------------------

def calc_percentile(in_data):
    # Loop through the array and print each subject
    for subject in all_subjects:
        calculate_percentile_each_subject(in_data, subject)
    return in_data  # Return the processed dataframe for use in the API


def combine_two_percentile(merge_data, indata) :
   length = len(indata)
   for subject in all_subjects :
       for i in range(0, length) :
          merge_data.loc[i , subject ] =int((indata[subject].iloc[i] + merge_data[subject].iloc[i])/2) 



#Usage python3 convert_each_exam_stream_to_percentile.py --half yes Rabindabharati_2024_10_halfyear_sectionA.csv pretest1=yes Rabindabharati_2024_10_pretest1_sectionA.csv pretest2=yes Rabindabharati_2024_10_pretest2_sectionA.csv
# Output will be saved as percentile_file.csv 


if __name__ == "__main__":
    
    to_write = False
    outfile = "percentile_file.csv"
    # Create an argument parser
    parser = argparse.ArgumentParser(description="Command-line argument parsing example")

    # Add expected arguments
    parser.add_argument('--half', type=str, help="Half-yearly indicator", choices=['yes', 'no'])
    parser.add_argument('halfyearly_file', type=str, help="File for half-yearly data")
    
    # Dynamic arguments for pretests (using nargs='*' to accept multiple pairs)
    parser.add_argument('pretests', nargs='*', help="Pretest arguments in format 'pretestX=Y pretestX.csv'")

    # Parse arguments
    args = parser.parse_args()

    # Handle 'half' argument
    if args.half:
        print(f"Half: {args.half}")
        half_file = args.halfyearly_file

        hdata = pd.read_csv(half_file);
        calc_percentile(hdata); 
        h_clone =  hdata.copy()

    # Handle pretest arguments
    if args.pretests:
        pretests = {}
        for i in range(0, len(args.pretests), 2):
            if i + 1 < len(args.pretests):
               pretests[args.pretests[i]] = args.pretests[i + 1]
        for pretest, file in pretests.items():
            if pretest  == 'pretest1=yes' :
               p1data = pd.read_csv(file)
               print(f" {file}")
               calc_percentile(p1data)
               p1 = True 
               if args.half:
                   combine_two_percentile(h_clone, p1data)
               else : 
                   h_clone =  p1data.copy()
            elif pretest == 'pretest2=yes' :
               print("Second")
               p2data = pd.read_csv(file)
               print(f" {file}")
               calc_percentile(p2data)
               if p1 == True :
                  combine_two_percentile(h_clone, p2data)  
               else :
                   if args.half :
                      combine_two_percentile(h_clone, p2data)
                   else :
                      h_clone = p2data.copy()
            else:
               print("Wrong Input")
    
    h_clone.to_csv(outfile, index=False);
