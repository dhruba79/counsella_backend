from django.contrib.auth import authenticate
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import force_bytes, smart_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from drf_yasg.utils import swagger_auto_schema

from . import serializers
from .models import User
from api.renderers import ResponseRenderer
from .utils import Util


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserRegistrationView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.UserRegistrationSerializer)
    def post(self, request, format=None):
        serializer = serializers.UserRegistrationSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response({'message': 'Registration successful'}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLoginView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.UserLoginSerializer)
    def post(self, request, format=None):
        serializer = serializers.UserLoginSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            email = serializer.data.get('email')
            password = serializer.data.get('password')
            user = authenticate(email=email, password=password)
            if user:
                token = get_tokens_for_user(user)
                return Response({'token': token, 'message': 'Login successful'}, status=status.HTTP_200_OK)
            else:
                return Response({'errors': {'non_field_errors': ['Email or Password is not valid']}}, status=status.HTTP_404_NOT_FOUND)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserProfileView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        # Check if user_id parameter is provided
        user_id = request.query_params.get('user_id')
        
        if user_id:
            # Only allow admins or school admins to view other users' profiles
            if not (request.user.is_admin or request.user.is_school_admin):
                return Response(
                    {'error': 'You do not have permission to view other users\' profiles'},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # ADD SCHOOL ADMIN SCOPE CODE HERE - START
            # Restrict school admins to only view students from their school
            if request.user.is_school_admin and not request.user.is_admin:
                requested_user = get_object_or_404(User, id=user_id)
                
                # Check if the requested user is a student of the admin's school
                if hasattr(requested_user, 'student_profile'):
                    if requested_user.student_profile.school.id != request.user.school_admin.id:
                        return Response(
                            {'error': 'You can only view students from your school'},
                            status=status.HTTP_403_FORBIDDEN
                        )
                else:
                    # If not a student, deny access
                    return Response(
                        {'error': 'You do not have permission to view this user\'s profile'},
                        status=status.HTTP_403_FORBIDDEN
                    )
            # ADD SCHOOL ADMIN SCOPE CODE HERE - END
            
            # Get the requested user or return 404
            user = get_object_or_404(User, id=user_id)
            serializer = serializers.UserProfileSerializer(user)
        else:
            # Return the current user's profile
            serializer = serializers.UserProfileSerializer(request.user)
            
        return Response(serializer.data, status=status.HTTP_200_OK)


class UserChangePasswordView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(request_body=serializers.UserChangePasswordSerializer)
    def post(self, request, format=None):
        serializer = serializers.UserChangePasswordSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            password = serializer.data.get('password')
            user = request.user

            user.set_password(password)
            user.save()

            return Response({'message': 'Password Changed successfully'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SendResetPasswordEmailView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.SendResetPasswordEmailSerializer)
    def post(self, request, format=None):
        serializer = serializers.SendResetPasswordEmailSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            email = serializer.data.get('email')

            user = User.objects.get(email=email)
            uid = urlsafe_base64_encode(force_bytes(user.id))
            token = PasswordResetTokenGenerator().make_token(user)

            password_reset_link = f'http://localhost:8000/api/user/resetpassword/{uid}/{token}/'

            # send email to user
            body = f'''
Hello {user.name.title()},

A request has been received to change the password for your MyCarrerMyWay account.

Reset Password - {password_reset_link}

If you did not initiate this request, please contact us immediately at support@mycareermyway.com.

Thank you,
MyCarrerMyWay Team
            '''
            print (f'Sending email message - {body}')

            data = {
                'subject': 'Your MyCarrerMyWay password reset request',
                'body': body,
                'to_email': user.email
            }
            Util.send_email(data=data)
            return Response({'message': 'Password reset link send, please check your Email'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserResetPasswordView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.UserResetPasswordSerializer)
    def post(self, request, uid, token, format=None):
        serializer = serializers.UserResetPasswordSerializer(data=request.data, context={'uid': uid, 'token': token})

        if serializer.is_valid(raise_exception=True):
            user = User.objects.get(id=smart_str(urlsafe_base64_decode(uid)))
            password = serializer.data.get('password')

            user.set_password(password)
            user.save()

            return Response({'message': 'Password Reset Successfully'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class IsUserEmailAvailableView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.IsUserEmailAvailableSerializer)
    def post(self, request, format=None):
        serializer = serializers.IsUserEmailAvailableSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            return Response({'message': 'User email is available'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
