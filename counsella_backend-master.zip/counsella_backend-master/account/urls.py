
from django.urls import path

from . import views

urlpatterns = [
    path('register/', views.UserRegistrationView.as_view(), name='register'),
    path('login/', views.UserLoginView.as_view(), name='login'),
    path('profile/', views.UserProfileView.as_view(), name='profile'),
    path('changepassword/', views.UserChangePasswordView.as_view(), name='changepassword'),
    path('resetpasswordemail/', views.SendResetPasswordEmailView.as_view(), name='resetpasswordemail'),
    path('resetpassword/<uid>/<token>/', views.UserResetPasswordView.as_view(), name='resetpassword'),
    path('email-available/', views.IsUserEmailAvailableView.as_view(), name='is_email_available'),

]
