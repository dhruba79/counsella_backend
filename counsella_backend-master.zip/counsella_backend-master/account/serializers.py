from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import smart_str
from django.utils.http import urlsafe_base64_decode
from django.core.exceptions import ValidationError
from rest_framework import serializers

from .models import User
from .password_validation import PasswordValidator

class UserRegistrationSerializer(serializers.ModelSerializer):
    confirm_password = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    class Meta:
        model = User
        fields = ['email', 'name', 'password', 'confirm_password']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate(self, attrs):
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')

        if password != confirm_password:
            raise serializers.ValidationError('Password and Confirm Password doesn\'t match')

        # Add password validation
        validator = PasswordValidator()
        try:
            validator.validate_password(password)
        except ValidationError as e:
            raise serializers.ValidationError({'password': e.messages})

        return attrs

    def create(self, validate_date):
        return User.objects.create_user(**validate_date)


class UserLoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(max_length=255)
    class Meta:
        model = User
        fields = ['email', 'password']


class UserProfileSerializer(serializers.ModelSerializer):
    user_type = serializers.SerializerMethodField()
    school_info = serializers.SerializerMethodField()
    student_info = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ['id', 'email', 'name', 'user_type', 'school_info', 'student_info']
    
    def get_user_type(self, obj):
        if obj.is_school_admin:
            return 'school_admin'
        elif obj.is_school_student:
            return 'student'
        elif obj.is_admin:
            return 'admin'
        else:
            return 'user'
    
    def get_school_info(self, obj):
        if hasattr(obj, 'school_admin'):
            school = obj.school_admin
            return {
                'id': school.id,
                'name': school.name,
                'address': school.address,
                'contact_no': school.contact_no,
                'contact_email': school.contact_email
            }
        return None
    
    def get_student_info(self, obj):
        if hasattr(obj, 'student_profile'):
            student = obj.student_profile
            return {
                'id': student.id,
                'school_name': student.school.name,
                'class': student.student_class,
                'section': student.section,
                'roll_number': student.roll_number
            }
        return None


class UserChangePasswordSerializer(serializers.Serializer):
    password = serializers.CharField(max_length=255, style={'input_type': 'password'}, write_only=True)
    confirm_password = serializers.CharField(max_length=255, style={'input_type': 'password'}, write_only=True)

    class Meta:
        fields = ['password', 'confirm_password']

    def validate(self, attrs):
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')
        user = self.context.get('user')

        if password != confirm_password:
            raise serializers.ValidationError('Password and Confirm Password doesn\'t match')

        # Add password validation
        validator = PasswordValidator()
        try:
            validator.validate_password(password, user)
        except ValidationError as e:
            raise serializers.ValidationError({'password': e.messages})

        return attrs


class SendResetPasswordEmailSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=255)

    class Meta:
        fields = ['email']

    def validate(self, attrs):
        email = attrs.get('email')

        if not User.objects.filter(email=email).exists():
            raise serializers.ValidationError('User is not found for given email address')

        return attrs


class UserResetPasswordSerializer(serializers.Serializer):
    password = serializers.CharField(max_length=255, style={'input_type': 'password'}, write_only=True)
    confirm_password = serializers.CharField(max_length=255, style={'input_type': 'password'}, write_only=True)

    class Meta:
        fields = ['password', 'confirm_password']

    def validate(self, attrs):
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')

        uid = self.context.get('uid')
        token = self.context.get('token')

        if password != confirm_password:
            raise serializers.ValidationError('Password and Confirm Password doesn\'t match')

        user = User.objects.get(id=smart_str(urlsafe_base64_decode(uid)))

        if not PasswordResetTokenGenerator().check_token(user, token):
            raise serializers.ValidationError('Password reset token is not Valid or Expired. Please try again.')

        # Add password validation
        validator = PasswordValidator()
        try:
            validator.validate_password(password, user)
        except ValidationError as e:
            raise serializers.ValidationError({'password': e.messages})

        return attrs


class IsUserEmailAvailableSerializer(serializers.Serializer):
    email = serializers.EmailField(max_length=255)

    class Meta:
        fields = ['email']

    def validate(self, attrs):
        email = attrs.get('email')

        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError('User email is already used')

        return attrs