#!/usr/bin/env python3


import os
import sys
import django


sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')
django.setup()


from school.models import LeadershipTrait

traits = [
    {
        "leadership_trait_name": "medical_doctors",
        "unique_qualities": ["Helpfulness Empathy", "Attention to Detail", "Persistence Determination"],
        "hobbies": ["Literature", "Problem-solving Puzzles Strategy-games", "Building Making Tinkering"],
        "books": ["The Immortal Life of Henrietta Lacks", "The Man Who Mistook His Wife for a Hat", "The Emperor of All Maladies"],
        "authors": ["Siddhartha Mukherjee", "Oliver Sacks", "Rebecca Skloot"],
        "communication_activities": ["Debate", "Public Speaking", "Presentation", "Story Telling"],
        "public_service": ["Health Camps", "Community Drives And General Volunteering"],
        "secondary_domain": ["Literature", "Teacher", "Biomedical Science"],
        "analytical_activities": ["Chess", "Puzzle"],
        "favourite_subjects": ["Biology", "Chemistry", "English"],
        "suggestions": [
            {"name": "Abraham Verghese", "tip": "Never lose sight of the human story at the heart of every patient; Remember medicine is as much about healing as it is about science.", "url": "", "designation": ""},
            {"name": "Ajay Kumar", "tip": "Stay curious; Be patient with yourself; Remember that medicine is about caring for people, not just solving problems.", "url": "", "designation": ""},
            {"name": "Aparna Hegde", "tip": "Never lose your empathy. Always remain dedicated to lifelong learning.", "url": "", "designation": ""},
            {"name": "Eric Jeffrey Topol", "tip": "Stay curious. Be compassionate. Remember that medicine is about both science and caring for people.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "banking",
        "unique_qualities": ["Analytical Logical Thinking", "Numerical Ability"],
        "hobbies": ["Problem Solving Puzzles Strategy Games"],
        "books": ["The Intelligent Investor", "Liar's Poker"],
        "authors": ["Benjamin Graham", "Michael Lewis"],
        "communication_activities": ["Debate", "Oratory Competition"],
        "public_service": ["Community Drives General Volunteering", "Charity"],
        "secondary_domain": ["Management Consulting", "Entrepreneurship", "Business Strategy"],
        "analytical_activities": ["Strategy Games", "Chess"],
        "favourite_subjects": ["Mathematics", "Economics"],
        "suggestions": [
            {"name": "Aashish Somaiyaa", "tip": "Develop strong analytical and communication skills. Be prepared to work hard. Stay updated on global financial trends.", "url": "", "designation": ""},
            {"name": "Aditi Kothari Desai", "tip": "Develop strong analytical and communication skills. Be prepared to work hard. Stay updated on global financial trends.", "url": "", "designation": ""},
            {"name": "Akash Prakash", "tip": "Focus on building strong analytical and communication skills. Always be willing to learn from real-world experiences.", "url": "", "designation": ""},
            {"name": "Bandana Kankani", "tip": "Stay curious; Keep learning; Be prepared for hard work; Success in investment banking comes from persistence; adaptability.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "lawyer",
        "unique_qualities": ["Debating Argumentation", "Sense of Justice Fairness", "Analytical Logical Thinking"],
        "hobbies": ["Debate Discussions Argumentation", "Literature", "Problem Solving Puzzles Strategy Games"],
        "books": ["To Kill a Mockingbird", "The Argumentative Indian", "The Firm"],
        "authors": ["Harper Lee", "Amartya Sen", "John Grisham"],
        "communication_activities": ["Debate", "Oratory Competition", "Public Speaking"],
        "public_service": ["Community Drives General Volunteering", "Charity", "Advocacy For Rights"],
        "secondary_domain": ["Journalism", "Teaching", "Civil Service"],
        "analytical_activities": ["Chess", "Puzzle", "Strategy Game"],
        "favourite_subjects": ["English", "History", "Social Studies"],
        "suggestions": [
            {"name": "Abhishek Manu Singhvi", "tip": "Cultivate an unquenchable thirst for knowledge. Be willing to learn and adapt.", "url": "", "designation": ""},
            {"name": "Aitzaz Ahsan", "tip": "Stay committed to truth and justice, even when difficult. Law is a responsibility towards society.", "url": "", "designation": ""},
            {"name": "Arundhati Katju", "tip": "Be persistent. Stay true to your values. Use law responsibly and with empathy.", "url": "", "designation": ""},
            {"name": "Amit Sibal", "tip": "Develop strong analytical and communication skills. Always be willing to learn. Never compromise on ethical standards.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "medical_surgeons",
        "unique_qualities": ["Calmness Under Pressure", "Steady Hands Manual Dexterity", "Attention to Detail"],
        "hobbies": ["Problem Solving Puzzles Strategy Games", "Building Making Tinkering", "Literature", "Sports Outdoor Activities"],
        "books": ["The Emperor of All Maladies", "Do No Harm"],
        "authors": ["Siddhartha Mukherjee", "Henry Marsh"],
        "communication_activities": ["Debates", "Speech Competitions", "Elocution Competitions"],
        "public_service": ["Science Fairs", "Health Camps"],
        "secondary_domain": ["Biomedical Science", "Scientific Research"],
        "analytical_activities": ["Chess", "Puzzle"],
        "favourite_subjects": ["Biology", "Chemistry"],
        "suggestions": [
            {"name": "Dr. Ajay Kumar Kriplani", "tip": "Develop a strong foundation in science. Practice discipline. Always be willing to learn and adapt.", "url": "", "designation": ""},
            {"name": "Dr. Ashish Sabharwal", "tip": "Maintain curiosity. Work hard. Never hesitate to seek guidance. Skill and compassion go hand in hand.", "url": "", "designation": ""},
            {"name": "Dr. Binsa Basheer", "tip": "Be willing to work hard. Stay curious. Always remember that compassion is as important as skill.", "url": "", "designation": ""},
            {"name": "Dr. Deepali Raina", "tip": "Concise note-taking using diagrams. Regular revision. Focused on key concepts. Memory retention techniques.", "url": "", "designation": ""},
            {"name": "Dr. B. K. Misra", "tip": "Stay committed. Keep learning. Remember that compassion and teamwork are as important as technical skills.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "politics",
        "unique_qualities": ["Organizational Skills", "Sense Of Justice Fairness", "Helpfulness Empathy", "Initiative Drive", "Stay Grounded and Informed"],
        "hobbies": ["Debate Discussions Argumentation", "Literature", "Team Organisation", "Sports Outdoor Activities", "Performance Theatre Arts"],
        "books": ["Long Walk to Freedom", "Biographies of Social Reformers", "To Kill a Mockingbird", "India After Gandhi"],
        "authors": ["Ramachandra Guha", "Nelson Mandela", "Anne Frank", "Harper Lee"],
        "communication_activities": ["Debate", "Oratory Competition", "Public Speaking", "Story Telling"],
        "public_service": ["Community Drives and General Volunteering", "Health Camps", "Educational Camps", "Disaster Relief"],
        "secondary_domain": ["Journalism", "Social Work", "Community Service"],
        "analytical_activities": ["Puzzle", "Strategic Games", "Tinkering with Gadgets"],
        "favourite_subjects": ["English", "History"],
        "suggestions": [
            {"name": "Narendra Damodardas Modi", "tip": "Reading widely. Observing people’s behaviour. Stay connected with the people; Stay Grounded. Listen to their needs; Always act with integrity and sincerity.", "url": "", "designation": ""},
            {"name": "Karin Keller", "tip": "Stay informed. Listen to diverse perspectives. Stay Grounded. Remain committed to serving others with integrity.", "url": "", "designation": ""},
            {"name": "Naveen Patnaik", "tip": "Stay honest. Stay compassionate; Stay committed to public service. Real change takes patience. Real change takes persistence.", "url": "", "designation": ""},
            {"name": "Mayawati Prabhu Das", "tip": "Don’t be afraid to raise your voice for what’s right; always support those who cannot speak for themselves.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "teachers",
        "unique_qualities": ["Communication Skills", "Helpfulness Empathy", "Patience", "Curiosity"],
        "hobbies": ["Literature", "Research Analysis Deep Learning", "Experiments Scientific Enquiry", "Building Making Tinkering"],
        "books": ["To Sir, with Love", "Pedagogy of the Oppressed", "The Courage to Teach", "The First Days of School"],
        "authors": ["E.R. Braithwaite", "Paulo Freire", "Parker Palmer", "Harry Wong"],
        "communication_activities": ["Debate", "Discussions", "Storytelling", "Essay Competitions"],
        "public_service": ["Community Drives and General Volunteering", "Educational Camps"],
        "secondary_domain": ["Research", "Policy Development", "Psychology", "Writing"],
        "analytical_activities": ["Chess", "Puzzle", "Tinkering with Gadgets", "Strategy Games"],
        "favourite_subjects": ["Mathematics", "Science", "Biology", "History"],
        "suggestions": [
            {"name": "Abhijit Vinayak Banerjee", "tip": "Summarizing complex ideas in simple language; Discussing concepts with peers. Always stay curious and keep learning alongside your students; Teaching is about growth for both teacher and student.", "url": "", "designation": ""},
            {"name": "Arvind Panagariya", "tip": "Detailed notes; Summarized key concepts; discussed topics with peers. Focus on continuous learning. Stay patient. Always strive to inspire curiosity in your students.", "url": "", "designation": ""},
            {"name": "Carol Susan Dweck", "tip": "Review material regularly. Connect concepts to real-life situations. Discuss ideas with peers. Stay curious about your students. Be open to learning from them as much as you teach.", "url": "", "designation": ""},
            {"name": "Shiv Visvanathan", "tip": "Making detailed notes. Engaging in group discussions. Always stay curious. Listen to your students. Adapt your teaching to inspire learning.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "actors",
        "unique_qualities": ["Mimicry Impersonation", "Storytelling Expressiveness", "Performance Skills Stage", "Observation Emotional Awareness"],
        "hobbies": ["Sports Outdoor Activities", "Literature", "Performance Theatre Arts", "Observation Exploration"],
        "books": ["An Actor Prepares", "Hamlet", "Plays from Shakespeare"],
        "authors": ["Constantin Stanislavsky", "William Shakespeare", "Tennessee Williams"],
        "communication_activities": ["Dramatics", "Debate", "Public Speaking"],
        "public_service": ["Community Drives General Volunteering", "Charity", "Educational Camps", "Environmental Campaigns"],
        "secondary_domain": ["Acting", "Writing", "Directing", "Film Making"],
        "analytical_activities": ["Story Writing"],
        "favourite_subjects": ["English", "History"],
        "suggestions": [
            {"name": "Aamir Khan", "tip": "Be sincere in your craft; Always strive to understand the character you are portraying.", "url": "", "designation": ""},
            {"name": "Adam Douglas Driver", "tip": " Stay patient. Stay persistent. Develop your craft. Make your mark.", "url": "", "designation": ""},
            {"name": "Benjamin Geza Affleck", "tip": "Stay true to yourself, work hard, never give up.", "url": "", "designation": ""},
            {"name": "William Bradley Pitt", "tip": "Be patient and persistent. Acting is a craft that needs time and effort to master. Always be open to learning. Always be open to evolving.", "url": "", "designation": ""}
        ]
    },
   
    {
        "leadership_trait_name": "writer",
        "unique_qualities": ["Imagination Creativity", "Storytelling Expressiveness", "Reading Writing Habit", "Exploring different cultures"],
        "hobbies": ["Reading and Writing", "Performance Theatre Arts", "Observation Exploration"],
        "books": ["On Writing: A Memoir of the Craft", "To Kill a Mockingbird", "The House of the Spirits", "Bird by Bird"],
        "authors": ["Stephen King", "Harper Lee", "Isabel Allende", "Anne Lamott"],
        "communication_activities": ["Debate", "Story Telling"],
        "public_service": ["Community Drives and General Volunteering", "Educational Camps", "Literature and Poetry-related Events"],
        "secondary_domain": ["Psychology", "Media and Social issues", "Film Industry", "Teaching"],
        "analytical_activities": [],
        "favourite_subjects": ["English", "History"],
        "suggestions": [
            {"name": "Alice Munro", "tip": "Write consistently. Read widely to develop your unique voice. Develop your understanding of different writing styles.", "url": "", "designation": ""},
            {"name": "Nikita Singh", "tip": "Focus on telling a compelling story that resonates with your audience. Don't be afraid to draw from your own experiences and observations.", "url": "", "designation": ""},
            {"name": "Margaret Atwood", "tip": "Focus on consistency in your writing. Focus on authenticity in your writing. Embrace your unique voice.", "url": "", "designation": ""},
            {"name": "Yashica Dutt", "tip": "Find your unique voice. Don't be afraid to share your authentic story, even if it challenges norms or traditions.", "url": "", "designation": ""},
            {"name": "Urja Joshi", "tip": "Breaking down complex topics into smaller, manageable parts. Using visual aids like mind maps.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "administrative",
        "unique_qualities": ["Sense Of Justice Fairness", "Organizational Skills", "Problem Solving", "Persistence Determination", "Sense of Responsibility"],
        "hobbies": ["Current Affairs", "Debate Discussions Argumentation", "Literature", "Problem Solving Puzzles Strategy-games"],
        "books": ["India After Gandhi", "Good to Great", "The Art of Public Strategy"],
        "authors": ["Ramachandra Guha", "Jim Collins", "Geoff Mulgan"],
        "communication_activities": ["Debate", "Oratory"],
        "public_service": ["Environmental Campaigns Drives", "Community Drives And General Volunteering", "Charity"],
        "secondary_domain": ["International Relations", "Governance", "Public Policy", "Social Work"],
        "analytical_activities": ["Quiz", "Chess", "Puzzle"],
        "favourite_subjects": ["English", "History"],
        "suggestions": [
            {"name": "Abhishek Singh", "tip": "Stay curious. Be patient. Focus on consistent effort. Success comes from resilience. Have a genuine desire to help others.", "url": "", "designation": ""},
            {"name": "Andrew Turnbull", "tip": "Stay curious. Be ethical. Learn to adapt quickly to changing situations.", "url": "", "designation": ""},
            {"name": "Ajit Kumar Doval", "tip": "Stay committed to your values. Work hard. Always put the nation’s interests before personal gain.", "url": "", "designation": ""},
            {"name": "D. Roopa Moudgil", "tip": "Stay committed. Cultivate a strong sense of ethics. Never stop learning.", "url": "", "designation": ""},
            {"name": "Durga Shakti Nagpal", "tip": "Stay true to your values. Keep learning. Be prepared for challenges. Perseverance and integrity are key.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "business_executive",
        "unique_qualities": ["Organizational Skills", "Persistence Determination", "Analytical Logical Thinking", "Initiative Drive"],
        "hobbies": ["Research", "Building Making Tinkering", "Literature", "Observation Exploration", "Debate Discussions Argumentation"],
        "books": ["Good to Great", "The Lean Startup", "Lean In", "Zero to One"],
        "authors": ["Jim Collins", "Eric Ries", "Sheryl Sandberg", "Peter Thiel"],
        "communication_activities": ["Debate", "Discussion", "Presentation", "Public Speaking"],
        "public_service": ["Science Fairs", "Community Drives General Volunteering", "Health Awareness Programs", "School Exhibitions"],
        "secondary_domain": ["Technology", "Public Service", "Teaching", "Business"],
        "analytical_activities": ["Puzzle", "Tinkering with Gadgets", "Strategic Games", "Chess"],
        "favourite_subjects": ["Mathematics", "Science", "History"],
        "suggestions": [
            {"name": "Abigail Johnson", "tip": "Stay curious. Never stop learning. Prioritize integrity in all your decisions.", "url": "", "designation": ""},
            {"name": "Azim Hashim Premji", "tip": "Always act with integrity. Stay adaptable. Focus on creating value for society, not just profit.", "url": "", "designation": ""},
            {"name": "Indra Nooyi", "tip": "Stay curious; Be willing to learn continuously. Always act with integrity.", "url": "", "designation": ""},
            {"name": "Harsh Mariwala", "tip": "Always be open to learning; Embrace failures as stepping stones; Focus on creating long-term value rather than chasing short-term gains.", "url": "", "designation": ""},
            {"name": "Tim Cook", "tip": "Be authentic. Stay curious. Always put people first. Lead with integrity and empathy.", "url": "", "designation": ""}
        ]
    },
    {
        "leadership_trait_name": "computer_science",
        "unique_qualities": ["Analytical Logical Thinking", "Problem Solving", "Numerical Ability", "Curiosity"],
        "hobbies": ["Building Making Tinkering", "Problem Solving Puzzles Strategy-games", "Research"],
        "books": ["Introduction to Algorithms", "Artificial Intelligence: A Modern Approach"],
        "authors": ["Coreman", "Russell and Norvig"],
        "communication_activities": ["Debate", "Discussion", "Presentation", "Oratory Competition"],
        "public_service": ["Environmental Campaigns Drive", "Community Drives General Volunteering", "Educational Camps", "Science Fairs"],
        "secondary_domain": ["Technology", "Engineering", "Teaching"],
        "analytical_activities": ["Chess", "Puzzles", "Strategic Games", "Tinkering with Gadgets"],
        "favourite_subjects": ["Mathematics", "Physics"],
        "suggestions": [
            {"name": "Abhijit Das", "tip": "Keep learning and adapting, as technology changes rapidly. Don’t be afraid to experiment and make mistakes— They are often the best teachers.", "url": "", "designation": ""},
            {"name": "Adi Shamir", "tip": "Focus on understanding the fundamentals deeply. A strong theoretical background will help you adapt to new challenges throughout your career.", "url": "", "designation": ""},
            {"name": "Alan Curtis Kay", "tip": "Stay curious and never stop learning. Focus on understanding the big ideas behind computing, not just the current tools or languages.", "url": "", "designation": ""},
            {"name": "Alok Aggarwal", "tip": "Stay curious and never stop learning. Focus on fundamentals. Don’t hesitate to explore interdisciplinary fields that intersect with computer science.", "url": "", "designation": ""}
        ]
    }
]

def populate_traits():
    """
    Creates or updates LeadershipTrait records in the database.
    
    This function iterates through the `traits` list and uses Django's
    `update_or_create` method to ensure the database reflects the data
    defined in this script. It logs whether each trait was created or updated.
    """
    created_count = 0
    updated_count = 0

    print("🚀 Starting leadership trait population...")
    for trait_data in traits:
        
        lookup_key = trait_data["leadership_trait_name"]
        defaults = {k: v for k, v in trait_data.items() if k != "leadership_trait_name"}
        
        obj, created = LeadershipTrait.objects.update_or_create(
            leadership_trait_name=lookup_key,
            defaults=defaults
        )
        
        if created:
            created_count += 1
            print(f"✅ Created: {obj.leadership_trait_name}")
        else:
            updated_count += 1
            print(f"🔄 Updated: {obj.leadership_trait_name}")
    
    print("\n--- Summary ---")
    print(f"Traits created: {created_count}")
    print(f"Traits updated: {updated_count}")
    print(f"Total traits in DB: {LeadershipTrait.objects.count()}")
    print("✨ Population complete.")

if __name__ == "__main__":
    populate_traits()
