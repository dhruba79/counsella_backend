import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')  # Replace if your project name is different
django.setup()

from school.models import FeedbackSubmission
from django.db.models import Count

duplicates = (
    FeedbackSubmission.objects
    .values('user_id', 'fid')
    .annotate(count=Count('id'))
    .filter(count__gt=1)
)

for entry in duplicates:
    user_id = entry['user_id']
    fid = entry['fid']

    submissions = FeedbackSubmission.objects.filter(user_id=user_id, fid=fid).order_by('-submitted_at')
    
    for submission in submissions[1:]:  # Keep the latest one
        print(f"Deleting: user_id={user_id}, fid={fid}, id={submission.id}")
        submission.delete()

print("Duplicate submissions cleaned.")
