# import os
# from openai import OpenAI
# import openai

# client = OpenAI(
#     api_key=os.environ.get("OPENAI_API_KEY"),
# )

# user_prompt = "What is the capital of France?"

# chat_completion = client.chat.completions.create(
#     messages=[
#         {
#             "role": "user",
#             "content": user_prompt,
#         }
#     ],
#     model="gpt-4-turbo",
# )

# print (chat_completion)
import os
from openai import OpenAI

# client = OpenAI()
client = OpenAI(
    api_key='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',
)

stream = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Say this is a test"}],
    stream=True,
)
for chunk in stream:
    if chunk.choices[0].delta.content is not None:
        print(chunk.choices[0].delta.content, end="")