
# Career Profile Generator

This Python script automates the generation of career profiles for individuals based on their profession and a set of predefined questions. It leverages the OpenAI API to generate realistic and concise answers, formatted specifically for career guidance for school children.

## Features

* **Dynamic Question Loading**: Extracts questions from profession-specific DOCX files.
* **Name-Profession Pairing**: Processes lists of names associated with specific professions.
* **OpenAI API Integration**: Uses `gpt-4.1` (or specified model) to generate personalized career profiles.
* **Structured Output**: Generates output in a consistent, easy-to-read format, mimicking a survey response.
* **Organized Output**: Saves generated profiles into profession-specific subdirectories.

## Getting Started

Follow these steps to set up and run the script.

### Prerequisites

* Python 3.7+
* `pip` (Python package installer)

### Installation

1.  **Clone the repository (or download the script):**
    
    git clone <repository_url>
    cd <repository_name>
    
    (Note: Replace `<repository_url>` and `<repository_name>` with your actual repository details if applicable. If you've just been provided the script, save it as `synthetic_data_gen.py`.)

2.  **Install the required Python packages:**
    
    pip install openai python-dotenv python-docx
    

### OpenAI API Key

1.  **Obtain an OpenAI API Key**: If you don't have one, register on the [OpenAI platform](https://platform.openai.com/) and generate a new secret key.

2.  **Set up environment variable**: Create a `.env` file in the same directory as the script and add your API key:

    OPENAI_API_KEY="sk-proj-YOUR_API_KEY_HERE"
    
    * (Note: The provided script directly includes an API key for demonstration purposes (`sk-proj-xxxxxx`). It's highly recommended to use a `.env` file for security in a production environment.) *

## Usage

### Directory Structure

Before running the script, ensure you have the following directory structure:

├── synthetic_data_gen.py
├── .env                  (if using environment variables for API key)
├── ques_career_wise/
│   ├── profession1.docx
│   ├── profession2.docx
│   └── ...
├── input_names/
│   ├── profession1.txt
│   ├── profession2.txt
│   └── ...
└── outputs/              (This directory will be created by the script)
    ├── profession1/
    │   ├── name1_profession1.txt
    │   └── name2_profession1.txt
    └── profession2/
        ├── name3_profession2.txt
        └── ...


* **`ques_career_wise/`**: This directory should contain DOCX files, where each file name corresponds to a profession (e.g., `engineer.docx`, `doctor.docx`). Each DOCX file should contain numbered questions.
* **`input_names/`**: This directory should contain text files, where each file name corresponds to a profession (e.g., `engineer.txt`, `doctor.txt`). Each file should contain a list of names, one name per line, for that profession.
* **`outputs/`**: This directory will be automatically created by the script. Generated profiles will be saved here, organized into subdirectories by profession.

### Running the Script

Execute the script from your terminal:

python synthetic_data_gen.py

The script will:
1.  Iterate through each profession defined by the text files in `input_names/`.
2.  For each profession, it will load the corresponding questions from `ques_career_wise/`.
3.  Then, for each name in the profession's name list, it will call the OpenAI API to generate a personalized career profile.
4.  Finally, it will save the generated profile to a text file within the `outputs/` directory, structured by profession.

### Example `profession.docx` content:


1. What inspired you to pursue this career?
2. What are the key responsibilities of your role?
3. What educational path did you take?
4. What challenges have you faced in your career?
5. What advice would you give to aspiring professionals in this field?


### Example `profession.txt` content:

```
John Doe
Jane Smith
Michael Brown
```

## Output Format

Each generated profile will follow this strict format:

```
 Full Name : [Your full name]
 Phone: 9876543210
 Email : survey_entry_mail@yahoo.com
 Qualification : [Your highest educational qualification]
 Specialization : [Profession.title()]
 Passout Year : [Your graduation or last education year]

 [Question 1 without numbering]?: [Answer in 2-4 sentences]

 [Question 2 without numbering]?: [Answer in 2-4 sentences]

 [...Continue for all questions...]
```

## Configuration

* **`QUESTIONS_DIR`**: Root directory for DOCX files containing questions (default: `ques_career_wise`).
* **`NAMES_DIR`**: Root directory for text files containing names (default: `input_names`).
* **`OUTPUT_ROOT`**: Root directory where generated profiles will be saved (default: `outputs`).
* **OpenAI Model**: The script uses `gpt-4.1` by default. This can be changed within the `call_openai_api_optimized` function.
* **Temperature**: The `temperature` parameter for the OpenAI API call is set to `0.7`.
* **Max Tokens**: The `max_tokens` parameter for the OpenAI API call is set to `4000`.
* **Sleep Interval**: A `2-second` delay is introduced between API calls for different names to avoid hitting rate limits.

## Error Handling

The script includes basic error handling for OpenAI API calls. If an error occurs during generation for a specific profile, an error message will be recorded instead of the profile content.
