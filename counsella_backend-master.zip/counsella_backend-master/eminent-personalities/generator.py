import os
import re
import sys
import random
import docx
import json
import openai
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Any

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configure OpenAI API
openai.api_key = ""  # Replace with your actual API key
MODEL = "gpt-4o-mini"  # You can change to gpt-3.5-turbo for lower cost or other available models

class CareerResponseGenerator:
    def __init__(self, base_dir: str, output_dir: str = None):
        """
        Initialize with the base directory containing the career folders.
        
        Args:
            base_dir (str): Directory containing the .docx files
            output_dir (str, optional): Directory where generated responses will be saved.
                                       If None, creates a 'generated_responses' folder in current directory.
        """
        self.base_dir = Path(base_dir)
        
        # Set output directory
        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            self.output_dir = Path("generated_responses")
            
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        logger.info(f"Output directory set to: {self.output_dir.absolute()}")
        
        # Cache for storing generated identities to avoid duplicates
        self.generated_identities: Dict[str, Dict[str, str]] = {}
        
        # Load first and last names for generating identities
        self.first_names = self._load_names("first_names.txt")
        self.last_names = self._load_names("last_names.txt")
        
        if not self.first_names or not self.last_names:
            # Fallback names if files aren't available
            self.first_names = [
                        "Aarav", "Aditi", "Aditya", "Alok", "Ananya", "Aniket", "Arjun", "Bhavya", "Chaitanya", "Devansh",
                        "Dhruv", "Ekta", "Esha", "Gaurav", "Harsh", "Isha", "Jatin", "Kavya", "Kartik", "Kiran",
                        "Lakshya", "Manish", "Meera", "Mihir", "Nandini", "Neha", "Nikhil", "Omkar", "Parth", "Pooja",
                        "Pranav", "Priya", "Rahul", "Rajesh", "Rakesh", "Reema", "Rohan", "Sakshi", "Sanjay", "Sanjana",
                        "Shreya", "Siddharth", "Sneha", "Suman", "Tanmay", "Tanya", "Tarun", "Tejas", "Ujjwal", "Varun"
                    ]            
            self.last_names = [
                        "Agarwal", "Bansal", "Bhattacharya", "Choudhury", "Desai", "Ghosh", "Gupta", "Iyer", "Jha", "Joshi",
                        "Kapoor", "Kashyap", "Khanna", "Kulkarni", "Malhotra", "Menon", "Mishra", "Mukherjee", "Nair", "Pandey",
                        "Patel", "Reddy", "Sharma", "Srinivasan", "Verma"
                    ]
    
    def _load_names(self, filename: str) -> List[str]:
        """Load names from a file if available."""
        try:
            with open(filename, 'r') as f:
                return [name.strip() for name in f.readlines() if name.strip()]
        except FileNotFoundError:
            logger.warning(f"Name file {filename} not found. Using default names.")
            return []
    
    def find_all_docx_files(self) -> List[Path]:
        """Find all .docx files in the directory structure."""
        docx_files = list(self.base_dir.glob("**/*.docx"))
        logger.info(f"Found {len(docx_files)} .docx files")
        return docx_files
    
    def extract_questions(self, docx_path: Path) -> List[str]:
        """Extract questions from a .docx file."""
        doc = docx.Document(docx_path)
        questions = []
        current_question = ""
        
        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if not text:
                continue
                
            # Look for numbered questions (e.g., "1.", "2.", etc.)
            if re.match(r'^\d+\.', text):
                if current_question:
                    questions.append(current_question)
                current_question = text
            else:
                # If it's a continuation of the current question
                if current_question:
                    current_question += " " + text
                else:
                    # Handle section headers and non-numbered questions
                    if text.endswith('?'):
                        questions.append(text)
                    elif "**" in text:  # Section header
                        current_question = ""
        
        # Add the last question if it exists
        if current_question:
            questions.append(current_question)
            
        logger.info(f"Extracted {len(questions)} questions from {docx_path.name}")
        return questions
    
    def determine_career_type(self, docx_path: Path) -> str:
        """Determine the career type from the file path."""
        parts = str(docx_path).split(os.sep)
        
        # Handle special cases for nested directories
        if "Other Engineering" in parts:
            for engineering_type in ["Chemical", "Civil", "Electrical", "Mechanical", "Petroleum", "Spatial Architecture"]:
                if engineering_type in parts:
                    return f"{engineering_type} Engineer"
        
        if "Bio professions" in parts:
            if "Bio Technology" in parts:
                return "Biotechnologist"
            elif "Clinical Research" in parts:
                return "Clinical Researcher"
            elif "Medicine" in parts and "surgery" in parts:
                return "Surgeon"
            elif "Medicine" in parts:
                return "Medical Doctor"
        
        # Handle main career folders
        career_mapping = {
            "Computer_science": "Computer Scientist",
            "Enterprenur": "Entrepreneur",
            "Fashion_Designer": "Fashion Designer",
            "IAS IPS Administrative Service": "Administrative Officer",
            "Investment Banker": "Investment Banker",
            "Law": "Lawyer",
            "Management": "Management Professional",
            "Politician and Social Worker": "Politician and Social Worker",
            "Sales_Professional": "Sales Professional",
            "Teaching Profession": "Teacher",
            "Writer": "Writer"
        }
        
        for folder, career in career_mapping.items():
            if folder in parts:
                return career
        
        # Fallback: use filename without extension
        return docx_path.stem.replace("_", " ")
    
    def generate_identity(self, career_type: str) -> Dict[str, str]:
        """Generate a fictional identity for a specified career."""
        # Check if we already generated an identity for this career
        if career_type in self.generated_identities:
            return self.generated_identities[career_type]
        
        # Generate name
        first_name = random.choice(self.first_names)
        middle_initial = random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        last_name = random.choice(self.last_names)
        full_name = f"{first_name} {middle_initial}. {last_name}"
        
        # Generate email (different formats)
        email_formats = [
            f"{first_name.lower()}.{last_name.lower()}@gmail.com",
            f"{first_name.lower()}_{last_name.lower()}@yahoo.com",
            f"{last_name.lower()}{first_name[0].lower()}@outlook.com",
            f"{first_name.lower()}{last_name.lower()}@hotmail.com",
            f"{first_name.lower()}.{last_name.lower()}@professional.com"
        ]
        email = random.choice(email_formats)
        
        # Generate phone number
        phone = f"{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
        
        # Career-specific qualifications and specializations
        qualifications_by_career: Dict[str, List[str]] = {
            "Computer Scientist": ["PhD in Computer Science", "MSc in Computer Science", "BSc in Computer Engineering"],
            "Investment Banker": ["MBA Finance", "MSc in Finance", "Bachelor of Finance"],
            "Lawyer": ["Juris Doctor (JD)", "LLB", "Master of Laws (LLM)"],
            "Medical Doctor": ["MD", "MBBS", "Doctor of Medicine"],
            "Surgeon": ["MD", "MS in Surgery", "FRCS"],
            "Teacher": ["PhD in Education", "Master of Education", "Bachelor of Education"],
            "Writer": ["MFA in Creative Writing", "BA in English Literature", "MA in Journalism"],
            "Fashion Designer": ["BFA in Fashion Design", "MFA in Fashion", "Diploma in Fashion Technology"]
        }
        
        # Default qualifications if career not in dictionary
        default_qualifications = [
            "PhD", "Master's Degree", "Bachelor's Degree", "Professional Certification"
        ]
        
        qualification = random.choice(qualifications_by_career.get(career_type, default_qualifications))
        
        # Generate specialization based on career
        specializations_by_career: Dict[str, List[str]] = {
            "Computer Scientist": ["Artificial Intelligence Researcher", "Software Architect", "Data Science Expert"],
            "Investment Banker": ["Mergers & Acquisitions Specialist", "Capital Markets Advisor", "Corporate Finance Expert"],
            "Lawyer": ["Corporate Law Specialist", "Criminal Defense Attorney", "Intellectual Property Lawyer"],
            "Medical Doctor": ["Family Physician", "Internist", "Pediatrician"],
            "Surgeon": ["Neurosurgeon", "Cardiac Surgeon", "Orthopedic Surgeon"],
            "Teacher": ["Educational Technology Expert", "Curriculum Developer", "Special Education Specialist"],
            "Writer": ["Novelist", "Screenwriter", "Journalist"],
            "Fashion Designer": ["Haute Couture Designer", "Sustainable Fashion Designer", "Costume Designer"]
        }
        
        default_specializations = [
            "Industry Expert", "Renowned Professional", "Specialist", "Thought Leader"
        ]
        
        specialization = random.choice(specializations_by_career.get(career_type, default_specializations))
        
        # Generate random passout year (between 5-30 years ago)
        current_year = 2025  # Assuming current year
        years_ago = random.randint(5, 30)
        passout_year = str(current_year - years_ago)
        
        # Create identity dictionary
        identity = {
            "full_name": full_name,
            "phone": phone,
            "email": email,
            "qualification": qualification,
            "specialization": specialization,
            "passout_year": passout_year,
            "career_type": career_type
        }
        
        # Cache the identity
        self.generated_identities[career_type] = identity
        return identity
    
    def create_prompt(self, questions: List[str], identity: Dict[str, str]) -> str:
        """Create a detailed prompt for the ChatGPT API."""
        career = identity["career_type"]
        
        prompt = f"""You are an eminent {career} named {identity['full_name']}. You need to answer interview questions about your career path and childhood experiences as if you are this person.

DO NOT mention that you are an AI or language model. Respond as if these are your genuine experiences and memories. Keep responses concise but insightful (2-4 sentences per question).

Here is your background information:
- Full Name: {identity['full_name']}
- Qualification: {identity['qualification']}
- Specialization: {identity['specialization']}
- Passout Year: {identity['passout_year']}

You come from a middle to upper-middle-class family background with a good education. You've had a successful career with notable achievements in your field. You've faced challenges but overcame them with determination and hard work.

Please answer EACH of the following questions IN ORDER, using first-person perspective as if these are your own experiences:

"""
        # Add all questions to the prompt
        for i, question in enumerate(questions, 1):
            prompt += f"{question}\n\n"
        
        prompt += """
Format your answers by repeating the question followed by your answer.

Example format:
Question: What inspired you to choose this career?
Answer: My inspiration came from...

Use a conversational, first-person tone throughout. Be specific and personal in your answers while remaining professional. Include some specific details, anecdotes, or examples to make your responses authentic.
"""
        return prompt
    
    def get_chatgpt_response(self, prompt: str) -> str:
        """Get response from ChatGPT API."""
        try:
            # Updated for the current OpenAI API (post March 2023)
            response = openai.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant creating synthetic career interview data."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=4000
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error calling ChatGPT API: {e}")
            return f"API Error: {e}"
    
    def parse_chatgpt_response(self, response: str) -> List[Tuple[str, str]]:
        """Parse the ChatGPT response into question-answer pairs."""
        qa_pairs = []
        current_question = ""
        current_answer = ""
        
        # Split the response by lines
        lines = response.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith("Question:"):
                # Save the previous Q&A pair if it exists
                if current_question and current_answer:
                    qa_pairs.append((current_question, current_answer))
                    
                # Start a new question
                current_question = line[len("Question:"):].strip()
                current_answer = ""
            elif line.startswith("Answer:"):
                current_answer = line[len("Answer:"):].strip()
            else:
                # If it's a continuation of the answer
                if current_answer:
                    current_answer += " " + line
                # If it might be a standalone question without the "Question:" prefix
                elif "?" in line and not current_question:
                    current_question = line
        
        # Add the last Q&A pair
        if current_question and current_answer:
            qa_pairs.append((current_question, current_answer))
            
        return qa_pairs
    
    def format_output(self, identity: Dict[str, str], qa_pairs: List[Tuple[str, str]]) -> str:
        """Format the output as specified."""
        output = f" Full Name : {identity['full_name']}\n\n"
        output += f" Phone: {identity['phone']}\n\n"
        output += f" Email: {identity['email']}\n\n"
        output += f" Qualification: {identity['qualification']}\n\n"
        output += f" Specialization: {identity['specialization']}\n\n"
        output += f" Passout Year: {identity['passout_year']}\n\n"
        
        # Add questions and answers
        for question, answer in qa_pairs:
            # Clean up question (remove numbers at the beginning if present)
            clean_question = re.sub(r'^\d+\.\s*', '', question)
            output += f" {clean_question}: {answer}\n\n"
            
        return output
    
    def process_file(self, docx_path: Path) -> None:
        """Process a single .docx file and generate a response."""
        try:
            # Determine career type
            career_type = self.determine_career_type(docx_path)
            logger.info(f"Processing {docx_path.name} for career: {career_type}")
            
            # Extract questions
            questions = self.extract_questions(docx_path)
            if not questions:
                logger.warning(f"No questions found in {docx_path.name}")
                return
                
            # Generate identity
            identity = self.generate_identity(career_type)
            
            # Create prompt
            prompt = self.create_prompt(questions, identity)
            
            # Get response from ChatGPT
            logger.info(f"Sending request to ChatGPT API for {identity['full_name']}")
            response = self.get_chatgpt_response(prompt)
            
            # Parse response
            qa_pairs = self.parse_chatgpt_response(response)
            
            # Format output
            output = self.format_output(identity, qa_pairs)
            
            # Save to file
            formatted_name = identity['full_name'].replace(" ", "_")
            output_path = self.output_dir / f"{career_type.replace(' ', '_')}_{formatted_name}.txt"
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(output)
                
            logger.info(f"Generated response saved to {output_path}")
            
        except Exception as e:
            logger.error(f"Error processing {docx_path.name}: {e}")
    
    def run(self):
        """Run the generator on all .docx files."""
        docx_files = self.find_all_docx_files()
        for docx_path in docx_files:
            self.process_file(docx_path)
        
        logger.info("Processing complete!")

if __name__ == "__main__":
    import argparse
    
    # Create argument parser
    parser = argparse.ArgumentParser(description="Generate synthetic career interview responses")
    parser.add_argument("input_dir", help="Directory containing career .docx files")
    parser.add_argument("-o", "--output", help="Directory where responses should be saved (default: ./generated_responses)")
    
    args = parser.parse_args()
    
    # Initialize generator with input and output directories
    generator = CareerResponseGenerator(args.input_dir, args.output)
    generator.run()
