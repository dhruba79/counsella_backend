import os
import time
import re
from pathlib import Path
import openai
from docx import Document
from dotenv import load_dotenv

# 🔐 Load environment variables
load_dotenv()
client = openai.OpenAI(api_key="sk-proj-xxxx") 


# 📁 Root Directories
QUESTIONS_DIR = Path("ques_career_wise")
NAMES_DIR = Path("input_names")
OUTPUT_ROOT = Path("outputs")

# 🧠 Extract questions from DOCX file
def extract_questions_from_docx(docx_path):
    doc = Document(docx_path)
    questions = []
    for para in doc.paragraphs:
        line = para.text.strip()
        if re.match(r"^\d+\.\s*", line):
            questions.append(line)
    return questions

# 🔢 Remove numbering from question
def remove_numbering(question):
    return re.sub(r"^\d+\.\s*", "", question).strip()

# 🤖 Generate full profile from single API call
def call_openai_api_optimized(name, profession, questions):
    print(f"\n🤖 Generating profile for: {name} ({profession})")
    clean_questions = [remove_numbering(q) for q in questions]
    questions_text = "\n".join([f"{i+1}. {q}" for i, q in enumerate(clean_questions)])

    prompt = f"""
Please provide one-two line, very crisp, and useful information that covers key details. 
This data is for career guidance of school children, so the answers should be very specific, to the point, and easy to understand, 
helping future generations learn about this persons career path and achievements.
Generate the responses as if you, yourself are {name}. Respond to this questionnaire as if you are personally answering it.
Be thoughtful and realistic, not idealized as if a real person is answering these survey questions.
Respond in clear, concise, and grammatically correct modern English, avoiding archaic, poetic, or overly stylized language.\n

IMPORTANT: Follow this EXACT output format STRICTLY and dont include any other extra lines :

 Full Name : [Your full name]
 Phone: 9876543210
 Email : survey_entry_mail@yahoo.com
 Qualification : [Your highest educational qualification]
 Specialization : {profession.title()}
 Passout Year : [Your graduation or last education year]

 [Question 1 without numbering]?: [Answer in 2-4 sentences]

 [Question 2 without numbering]?: [Answer in 2-4 sentences]

 [..Continue for all questions..]
 
 Questions:
 {questions_text}

Now, generate the full response in the EXACT format above.
 """
    
    try:
        print("   ⏳ Generating...", end="", flush=True)
        response = client.chat.completions.create(
            model="gpt-4.1",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=4000
        )
        print(" ✅")
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f" ❌ Error: {e}")
        return f"[Error generating profile for {name}: {e}]"

# 💾 Save output

def write_output(name, profession, complete_response):
    OUTPUT_DIR = OUTPUT_ROOT / profession.lower()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    formatted_name = name.lower().replace(" ", "_")
    filename = f"{formatted_name}_{profession.lower()}.txt"
    file_path = OUTPUT_DIR / filename
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(complete_response)

# 🚀 Main

def main():
    print("\n🚀 Starting generalized questionnaire generation...\n")

    name_files = list(NAMES_DIR.glob("*.txt"))
    for name_file in name_files:
        profession = name_file.stem
        questions_file = QUESTIONS_DIR / f"{profession}.docx"

        if not questions_file.exists():
            print(f"⚠️ Skipping {profession}: questions file not found.")
            continue

        print(f"📚 Processing profession: {profession}")
        questions = extract_questions_from_docx(questions_file)
        print(f"   📋 Loaded {len(questions)} questions")

        with open(name_file, "r", encoding="utf-8") as f:
            names = [line.strip() for line in f if line.strip()]

        print(f"   👤 Found {len(names)} names")

        for i, name in enumerate(names, 1):
            print(f"   [{i}/{len(names)}]", end=" ")
            complete_response = call_openai_api_optimized(name, profession, questions)
            write_output(name, profession, complete_response)
            if i < len(names):
                time.sleep(2)

    print("\n✅ All profession profiles generated!")
    print(f"📁 Check outputs in: {OUTPUT_ROOT}\n")

# 🔧 Run
if __name__ == "__main__":
    main()
