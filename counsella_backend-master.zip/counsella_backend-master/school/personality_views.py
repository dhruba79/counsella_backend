# Add to school/personality_views.py or similar

from django.shortcuts import get_object_or_404
from django.utils.timezone import now
from django.core.files.base import ContentFile
import json

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from storage_backends import AzureMediaStorage
from .models import (
    Student, PersonalityTestQuestion, PersonalityTestSession, PersonalityTestResponse
)
from .permissions import IsSchoolStudent
from .personality_serializers import (
    PersonalityTestQuestionSerializer, PersonalityTestSessionSerializer,
    PersonalityTestResponseSerializer, PersonalityTestReportSerializer
)
from api.renderers import ResponseRenderer

class PersonalityTestView(APIView):
    """Main API view for personality tests"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request):
        """
        GET method with two behaviors:
        1. If session_id is provided: Return current state of session
        2. If no session_id: Return all of user's sessions
        """
        student = request.user.student_profile
        session_id = request.query_params.get('session_id')
        
        if session_id:
            # Get specific session
            try:
                session = PersonalityTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
                
                # Get current question if session is active
                if session.is_active:
                    next_question = session.get_next_question()
                    
                    if next_question:
                        total_questions = PersonalityTestQuestion.objects.count()
                        question_serializer = PersonalityTestQuestionSerializer(next_question)
                        
                        return Response({
                            'session_id': session.session_id,
                            'is_active': session.is_active,
                            'created_at': session.created_at,
                            'question': question_serializer.data,
                            'progress': {
                                'completed': session.current_question_number - 1,
                                'total': total_questions
                            }
                        })
                    else:
                        # No more questions - session should be completed
                        if not session.completed_at:
                            session.completed_at = now()
                            session.is_active = False
                            session.calculate_result()
                            session.save()
                        
                        return Response({
                            'session_id': session.session_id,
                            'is_active': False,
                            'is_complete': True,
                            'personality_type': session.personality_type,
                            'message': 'You have completed the personality test!',
                            'report_url': f'/api/school/student/personality-test/report/?session_id={session.session_id}'
                        })
                else:
                    # Completed session
                    return Response({
                        'session_id': session.session_id,
                        'is_active': False,
                        'is_complete': True,
                        'personality_type': session.personality_type,
                        'message': 'You have already completed this test.',
                        'report_url': f'/api/school/student/personality-test/report/?session_id={session.session_id}'
                    })
            except PersonalityTestSession.DoesNotExist:
                return Response(
                    {"error": "Test session not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
        else:
            # List all sessions for this student
            sessions = PersonalityTestSession.objects.filter(student=student).order_by('-created_at')
            serializer = PersonalityTestSessionSerializer(sessions, many=True)
            return Response(serializer.data)
    
    def post(self, request):
        """
        POST method with two behaviors:
        1. If message='start': Create a new session
        2. If session_id provided: Submit an answer
        """
        student = request.user.student_profile
        message = request.data.get('message')
        session_id = request.data.get('session_id')
        
        # Create new session
        if message == 'start' and not session_id:
            session = PersonalityTestSession.objects.create(
                student=student,
                is_active=True
            )
            
            # Get first question
            first_question = PersonalityTestQuestion.objects.order_by('dimension', 'question_number').first()
            
            if not first_question:
                return Response(
                    {"error": "No questions available"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Count total questions
            total_questions = PersonalityTestQuestion.objects.count()
            
            # Serialize first question
            question_serializer = PersonalityTestQuestionSerializer(first_question)
            
            return Response({
                'session_id': session.session_id,
                'is_active': True,
                'created_at': session.created_at,
                'message': 'Welcome to your personality test! This test will help determine your personality type based on your preferences and tendencies.',
                'question': question_serializer.data,
                'progress': {
                    'completed': 0,
                    'total': total_questions
                }
            }, status=status.HTTP_201_CREATED)
        
        # Submit answer
        elif session_id and message:
            try:
                session = PersonalityTestSession.objects.get(
                    session_id=session_id,
                    student=student,
                    is_active=True
                )
            except PersonalityTestSession.DoesNotExist:
                return Response(
                    {"error": "Invalid or inactive test session"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get current question
            current_question = session.get_next_question()
            
            if not current_question:
                return Response(
                    {"error": "No more questions available"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Validate answer (should be A or B)
            if message not in ['A', 'B', 'a', 'b']:
                return Response(
                    {"error": "Invalid answer. Please select A or B."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Normalize answer
            selected_option = message.upper()
            
            # Save response
            PersonalityTestResponse.objects.create(
                session=session,
                question=current_question,
                selected_option=selected_option
            )
            
            # Get next question
            next_question = session.get_next_question()
            total_questions = PersonalityTestQuestion.objects.count()
            
            if next_question:
                # There are more questions
                question_serializer = PersonalityTestQuestionSerializer(next_question)
                
                return Response({
                    'answer_saved': True,
                    'session_id': session.session_id,
                    'is_complete': False,
                    'question': question_serializer.data,
                    'progress': {
                        'completed': session.current_question_number - 1,
                        'total': total_questions
                    }
                })
            else:
                # Test is complete
                session.completed_at = now()
                session.is_active = False
                results = session.calculate_result()
                
                return Response({
                    'answer_saved': True,
                    'session_id': session.session_id,
                    'is_complete': True,
                    'message': 'Thank you for completing the personality test! Your results are ready.',
                    'personality_type': results['personality_type'],
                    'report_url': f'/api/school/student/personality-test/report/?session_id={session.session_id}'
                })
        
        # Invalid request
        else:
            return Response(
                {"error": "Invalid request. Please provide either 'message=start' to create a session, or 'session_id' and 'message' to submit an answer."},
                status=status.HTTP_400_BAD_REQUEST
            )

class PersonalityTestReportView(APIView):
    """API view for personality test reports"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request):
        """Get report for a specific session"""
        student = request.user.student_profile
        session_id = request.query_params.get('session_id')
        
        if not session_id:
            return Response(
                {"error": "Please provide a session_id"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            session = PersonalityTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except PersonalityTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Ensure results are calculated
        if not session.personality_type or not session.dimension_scores:
            session.calculate_result()
        
        # Generate report
        report = self._generate_report(session, student)
        
        # Store report in Azure
        storage_info = self._store_report(
            session_id=session.session_id,
            student_id=student.id,
            report_data=report
        )
        
        # Return report with storage URLs
        response_data = {
            **report,
            'file': storage_info
        }
        
        return Response(response_data)
    
    def _generate_report(self, session, student):
        """Generate personality test report"""
        # Get the school
        school = student.school
        
        # Format dimensions for UI display
        dimensions = []
        for name, values in session.dimension_scores.items():
            dimension_data = {
                'name': name
            }
            
            if name == 'Extraversion_Introversion':
                dimension_data['left_label'] = 'Introvert'
                dimension_data['left_percentage'] = values['Introversion']
                dimension_data['right_label'] = 'Extrovert'
                dimension_data['right_percentage'] = values['Extraversion']
                dimension_data['left_description'] = ''
                dimension_data['right_description'] = ''
            elif name == 'Sensing_Intuition':
                dimension_data['left_label'] = 'Sensing'
                dimension_data['left_percentage'] = values['Sensing']
                dimension_data['right_label'] = 'iNtuitive'
                dimension_data['right_percentage'] = values['Intuition']
                dimension_data['left_description'] = '(Observant)'
                dimension_data['right_description'] = '(Futuristic)'
            elif name == 'Thinking_Feeling':
                dimension_data['left_label'] = 'Thinking'
                dimension_data['left_percentage'] = values['Thinking']
                dimension_data['right_label'] = 'Feeling'
                dimension_data['right_percentage'] = values['Feeling']
                dimension_data['left_description'] = ''
                dimension_data['right_description'] = ''
            elif name == 'Judging_Perceiving':
                dimension_data['left_label'] = 'Judging'
                dimension_data['left_percentage'] = values['Judging']
                dimension_data['right_label'] = 'Perceiving'
                dimension_data['right_percentage'] = values['Perceiving']
                dimension_data['left_description'] = '(Organized)'
                dimension_data['right_description'] = '(Spontaneous)'
            
            dimensions.append(dimension_data)
        
        # Format complete report
        report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school.name,
            'personality_type': session.personality_type,
            'dimensions': dimensions,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat()
        }
        
        return report
    
    def _store_report(self, session_id, student_id, report_data):
        """Store the personality test report in Azure Blob Storage"""
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"personality_reports/student_{student_id}/{session_id}/report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }

class StudentPersonalityReportView(APIView):
    """API view for getting personality test report by student ID"""
    permission_classes = [IsAuthenticated]  # Both students and admins
    renderer_classes = [ResponseRenderer]
    
    def get(self, request):
        """
        Get report for a student
        - If student_id is provided: Get that student's report (admin only)
        - If no student_id: Get current user's report
        """
        student_id = request.query_params.get('student_id')
        
        # Determine which student to use
        if student_id is None:
            # Use current user's profile
            if hasattr(request.user, 'student_profile'):
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "When no student ID is provided, you must be logged in as a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            # Student ID provided - verify permissions
            if hasattr(request.user, 'school_admin'):
                # School admin can access any student's report
                school = request.user.school_admin
                student = get_object_or_404(Student, id=student_id, school=school)
            elif hasattr(request.user, 'student_profile'):
                # Students can only access their own reports
                if int(student_id) != request.user.student_profile.id:
                    return Response(
                        {"error": "You can only access your own reports"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "User is neither a school admin nor a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        
        # Find the latest test session for this student
        latest_session = PersonalityTestSession.objects.filter(
            student=student,
            completed_at__isnull=False  # Only include completed sessions
        ).order_by('-completed_at').first()
        
        if not latest_session:
            return Response(
                {"error": "No completed personality test sessions found for this student"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Ensure results are calculated
        if not latest_session.personality_type or not latest_session.dimension_scores:
            latest_session.calculate_result()
        
        # Generate report
        report_view = PersonalityTestReportView()
        report = report_view._generate_report(latest_session, student)
        
        # Check if report was already stored
        try:
            azure_storage = AzureMediaStorage()
            report_path_pattern = f"personality_reports/student_{student.id}/{latest_session.session_id}/report_"
            
            # Try to find existing reports
            try:
                storage_files = [f for f in azure_storage.listdir(f"personality_reports/student_{student.id}/{latest_session.session_id}/")[1] 
                               if f.startswith(report_path_pattern.split('/')[-1])]
                
                if storage_files:
                    # Use the latest existing report
                    latest_file = sorted(storage_files, reverse=True)[0]
                    existing_report_path = f"personality_reports/student_{student.id}/{latest_session.session_id}/{latest_file}"
                    existing_report_url = azure_storage.url(existing_report_path)
                    
                    storage_info = {
                        'file_path': existing_report_path,
                        'file_url': existing_report_url
                    }
                else:
                    # Store a new report
                    storage_info = report_view._store_report(
                        session_id=latest_session.session_id,
                        student_id=student.id,
                        report_data=report
                    )
            except:
                # If listing fails, store a new report
                storage_info = report_view._store_report(
                    session_id=latest_session.session_id,
                    student_id=student.id,
                    report_data=report
                )
        except Exception as e:
            print(f"Error with report storage: {str(e)}")
            # Store a new report
            storage_info = report_view._store_report(
                session_id=latest_session.session_id,
                student_id=student.id,
                report_data=report
            )
        
        # Return report with storage information
        response_data = {
            **report,
            'file': storage_info,
            'student_id': student.id
        }
        
        return Response(response_data)