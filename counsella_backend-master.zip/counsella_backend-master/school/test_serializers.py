from rest_framework import serializers
from .models import (
    AdaptiveTestQuestion, 
    AdaptiveTestSession, 
    AdaptiveTestResponse, 
    AdaptiveTestChatMessage
)

class TestQuestionSerializer(serializers.ModelSerializer):
    """Serializer for test questions"""
    image_url = serializers.SerializerMethodField()
    question_id = serializers.IntegerField(source='id')  # Add explicit question_id field
    
    class Meta:
        model = AdaptiveTestQuestion
        fields = [
            'question_id',  # Make the ID more explicit
            'id',           # Include both for backward compatibility
            'category', 
            'question_text', 
            'difficulty', 
            'options', 
            'correct_answer', 
            'explanation', 
            'image', 
            'image_url'
        ]
        extra_kwargs = {
            'correct_answer': {'write_only': True},
            'explanation': {'write_only': True}
        }
    
    def get_image_url(self, obj):
        if not obj.image:
            return None
        request = self.context.get('request')
        if not request:
            return None
        return request.build_absolute_uri(f'/media/patterns/{obj.image}')

class TestCategorySerializer(serializers.Serializer):
    """Serializer for test categories"""
    id = serializers.CharField()
    name = serializers.CharField()

class TestSessionSerializer(serializers.ModelSerializer):
    """Serializer for test sessions"""
    
    class Meta:
        model = AdaptiveTestSession
        fields = [
            'id', 'session_id', 'student', 'created_at', 
            'completed_at', 'is_active', 'current_category', 'metrics'
        ]
        read_only_fields = [
            'id', 'session_id', 'created_at', 'completed_at', 'metrics'
        ]

class TestResponseSerializer(serializers.ModelSerializer):
    """Serializer for test responses"""
    
    class Meta:
        model = AdaptiveTestResponse
        fields = [
            'id', 'session', 'question', 'student_answer',
            'corrected_answer', 'is_correct', 'response_time', 'answered_at'
        ]
        read_only_fields = [
            'id', 'is_correct', 'corrected_answer', 'answered_at'
        ]

class TestChatMessageSerializer(serializers.ModelSerializer):
    """Serializer for chat messages"""
    options = serializers.SerializerMethodField()
    image_url = serializers.SerializerMethodField()
    
    class Meta:
        model = AdaptiveTestChatMessage
        fields = [
            'id', 'session', 'sender', 'content', 'timestamp', 
            'message_type', 'options', 'image_url'
        ]
        read_only_fields = ['id', 'timestamp']
    
    def get_options(self, obj):
        if obj.metadata and 'options' in obj.metadata:
            return obj.metadata['options']
        return None
    
    def get_image_url(self, obj):
        if not obj.metadata or 'image' not in obj.metadata or not obj.metadata['image']:
            return None
        request = self.context.get('request')
        if not request:
            return None
        return request.build_absolute_uri(f'/media/patterns/{obj.metadata["image"]}')

class SubmitAnswerSerializer(serializers.Serializer):
    """Serializer for submitting an answer"""
    question_id = serializers.IntegerField(required=True)
    answer = serializers.CharField(required=True)
    response_time = serializers.FloatField(required=False, default=0)

class CategorySelectionSerializer(serializers.Serializer):
    """Serializer for selecting a test category"""
    category = serializers.CharField(required=True)

class ChatMessageCreateSerializer(serializers.Serializer):
    """Serializer for creating a chat message"""
    message = serializers.CharField(required=True)

class TestReportSerializer(serializers.Serializer):
    """Serializer for test reports"""
    session_id = serializers.UUIDField()
    student = serializers.DictField()
    test_details = serializers.DictField()
    performance = serializers.DictField()
    detailed_responses = serializers.ListField()
    career_recommendations = serializers.ListField(required=False)