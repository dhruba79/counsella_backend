import os
import csv
from django.core.management.base import BaseCommand
from django.conf import settings
from school.models import Career, CareerStatistic, CareerInfo

class Command(BaseCommand):
    help = 'Import career data from CSV files'

    def add_arguments(self, parser):
        parser.add_argument('--data-dir', type=str, help='Directory containing career data folders')

    def handle(self, *args, **options):
        data_dir = options.get('data_dir')
        if not data_dir:
            data_dir = os.path.join(settings.BASE_DIR, 'data', 'careers')
        
        if not os.path.exists(data_dir):
            self.stdout.write(self.style.ERROR(f'Directory {data_dir} does not exist'))
            return
        
        for career_folder in os.listdir(data_dir):
            folder_path = os.path.join(data_dir, career_folder)
            if os.path.isdir(folder_path):
                # Find CSV file in folder
                csv_files = [f for f in os.listdir(folder_path) 
                             if f.endswith('_CSV.csv') or f.endswith('.csv')]
                
                if csv_files:
                    csv_file = os.path.join(folder_path, csv_files[0])
                    
                    # Create or get career
                    career_name = ' '.join(word.capitalize() for word in career_folder.replace('_', ' ').split())
                    career_value = career_folder.lower()
                    
                    career, created = Career.objects.update_or_create(
                        value=career_value,
                        defaults={'name': career_name}
                    )
                    
                    # Process data from CSV
                    self.process_csv_data(career, csv_file)
                    
                    self.stdout.write(
                        self.style.SUCCESS(f'Successfully processed {career_name}')
                    )
    
    def process_csv_data(self, career, csv_file):
        records = []
        
        with open(csv_file, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append(row)
        
        if not records:
            return
        
        total_records = len(records)
        
        # Process all existing statistic categories
        self.process_career_choice(career, records, total_records)
        self.process_time_for_career_choice(career, records, total_records)
        self.process_family_influence(career, records, total_records)
        self.process_reading_habits(career, records, total_records)
        self.process_music(career, records, total_records)
        self.process_arts_and_craft(career, records, total_records)
        self.process_public_service(career, records, total_records)
        self.process_leadership_ability(career, records, total_records)
        self.process_economic_class(career, records, total_records)
        self.process_personality(career, records, total_records)
        self.process_is_organized(career, records, total_records)
        self.process_meet_new_friends(career, records, total_records)
        self.process_friend_cycles(career, records, total_records)
        self.process_subject_results(career, records, total_records)
        self.process_sports(career, records, total_records)
        
        # Process all binary attributes as statistics
        binary_fields = [
            ('is_nervous', 'Is Nervous'),
            ('under_control', 'Under Control'),
            ('has_negotiation_skill', 'Has Negotiation Skill'),
            ('is_under_time_pressure', 'Under Time Pressure'),
            ('is_under_control', 'Is Under Control'),
            ('is_analytical_activity', 'Has Analytical Activities'),
            ('is_communication_activity', 'Has Communication Activities'),
            ('is_outside_academic', 'Outside Academic Activities'),
            ('public_event_participated', 'Public Event Participation'),
            ('good_in_some_subjects', 'Good in Some Subjects'),
            ('good_in_all_subject', 'Good in All Subjects'),
            ('good_in_no_subjects', 'Good in No Subjects')
        ]
        
        for field, display_name in binary_fields:
            self.process_binary_attribute(career, records, field, display_name)
        
        # Process list data for career info
        self.process_career_info(career, records)
    
    def process_binary_attribute(self, career, records, field_name, display_name):
        """Process a yes/no field into a statistic"""
        if not records:
            return
            
        total_records = len(records)
        
        # Count "Yes" responses
        yes_count = sum(1 for record in records if field_name in record and 
                       record[field_name].lower() == 'yes')
        
        # Calculate percentages
        yes_percentage = round((yes_count / total_records) * 100, 1)
        no_percentage = 100 - yes_percentage
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category=display_name,
            defaults={
                'labels': ['Yes', 'No'],
                'values': [yes_percentage, no_percentage]
            }
        )
    
    def process_career_choice(self, career, records, total_records):
        labels = ['Passion', 'Money', 'Nothing']
        values = [
            self.calculate_percentage(records, 'career_choice_for_passion', 'Yes', total_records),
            self.calculate_percentage(records, 'career_choice_for_money', 'Yes', total_records),
            self.calculate_percentage(records, 'career_choice_for_nothing', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Career Choice',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_time_for_career_choice(self, career, records, total_records):
        labels = ['School', 'College', 'University', 'After Education']
        values = [
            self.calculate_percentage(records, 'career_choice_in_school', 'Yes', total_records),
            self.calculate_percentage(records, 'career_choice_in_college', 'Yes', total_records),
            self.calculate_percentage(records, 'career_choice_in_univ', 'Yes', total_records),
            self.calculate_percentage(records, 'career_choice_after_education', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Time for Career Choice',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_family_influence(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'is_family_member', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'is_family_member', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Family Influence',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_reading_habits(self, career, records, total_records):
        labels = ['Newspaper', 'Magazine', 'Books', 'Nothing']
        values = [
            self.calculate_percentage(records, 'newspaper', 'Yes', total_records),
            self.calculate_percentage(records, 'magazine', 'Yes', total_records),
            self.calculate_percentage(records, 'book', 'Yes', total_records),
            100 - max(
                self.calculate_percentage(records, 'newspaper', 'Yes', total_records),
                self.calculate_percentage(records, 'magazine', 'Yes', total_records),
                self.calculate_percentage(records, 'book', 'Yes', total_records)
            )
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Reading Habits',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_music(self, career, records, total_records):
        labels = ['Vocal', 'Instrumental', 'Nothing']
        values = [
            self.calculate_percentage(records, 'vocal', 'Yes', total_records),
            self.calculate_percentage(records, 'instrumental', 'Yes', total_records),
            100 - max(
                self.calculate_percentage(records, 'vocal', 'Yes', total_records),
                self.calculate_percentage(records, 'instrumental', 'Yes', total_records)
            )
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Music',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_arts_and_craft(self, career, records, total_records):
        labels = ['Drawing and Painting', 'Crafts', 'Nothing']
        values = [
            self.calculate_percentage(records, 'drawing_painting', 'Yes', total_records),
            self.calculate_percentage(records, 'building_things', 'Yes', total_records),
            100 - max(
                self.calculate_percentage(records, 'drawing_painting', 'Yes', total_records),
                self.calculate_percentage(records, 'building_things', 'Yes', total_records)
            )
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Arts and Craft',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_public_service(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'public_service', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'public_service', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Public Service',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_leadership_ability(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'is_leadership', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'is_leadership', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Leadership Ability',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_economic_class(self, career, records, total_records):
        # Print unique values for debugging
        unique_values = set()
        for record in records:
            if 'economic_standard' in record:
                unique_values.add(record['economic_standard'])
        print(f"Economic standard values found: {unique_values}")
        
        # Count occurrences of each economic class
        upper_count = sum(1 for record in records if 'economic_standard' in record and 
                        record['economic_standard'].lower() in ['upper', 'upper class', 'upper-class', 'high'])
        
        middle_count = sum(1 for record in records if 'economic_standard' in record and 
                        record['economic_standard'].lower() in ['middle', 'middle class', 'middle-class', 'medium'])
        
        lower_count = sum(1 for record in records if 'economic_standard' in record and 
                        record['economic_standard'].lower() in ['lower', 'lower class', 'lower-class', 'low'])
        
        print(f"Counts - Upper: {upper_count}, Middle: {middle_count}, Lower: {lower_count}")
        
        # Calculate percentages
        if total_records > 0:
            upper_percentage = round((upper_count / total_records) * 100, 1)
            middle_percentage = round((middle_count / total_records) * 100, 1)
            lower_percentage = round((lower_count / total_records) * 100, 1)
            
            print(f"Percentages - Upper: {upper_percentage}%, Middle: {middle_percentage}%, Lower: {lower_percentage}%")
            
            # If percentages don't add up to 100%, adjust
            total_percentage = upper_percentage + middle_percentage + lower_percentage
            if total_percentage < 100:
                # Distribute the remainder to the largest category
                remainder = 100 - total_percentage
                max_percentage = max(upper_percentage, middle_percentage, lower_percentage)
                
                if upper_percentage == max_percentage:
                    upper_percentage += remainder
                elif middle_percentage == max_percentage:
                    middle_percentage += remainder
                else:
                    lower_percentage += remainder
        else:
            upper_percentage = middle_percentage = lower_percentage = 0
        
        labels = ['Upper Class', 'Middle Class', 'Lower Class']
        values = [upper_percentage, middle_percentage, lower_percentage]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Economic Class',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_personality(self, career, records, total_records):
        labels = ['Extrovert', 'Introvert', 'Ambivalent']
        
        extrovert_percentage = self.calculate_percentage(records, 'extrovert', 'Yes', total_records)
        introvert_percentage = self.calculate_percentage(records, 'introvert', 'Yes', total_records)
        
        # Calculate ambivalent as the remainder or from 'ambivert' column if it exists
        ambivert_percentage = 0
        for record in records:
            if 'ambivert' in record and record['ambivert'].lower() == 'yes':
                ambivert_percentage += 1
        
        if ambivert_percentage > 0:
            ambivert_percentage = round((ambivert_percentage / total_records) * 100, 1)
        else:
            # If no direct ambivalent data, calculate as remainder up to 100%
            direct_total = extrovert_percentage + introvert_percentage
            if direct_total < 100:
                ambivert_percentage = 100 - direct_total
            else:
                # If total exceeds 100%, normalize
                ambivert_percentage = 0
                scale_factor = 100 / direct_total
                extrovert_percentage = round(extrovert_percentage * scale_factor, 1)
                introvert_percentage = round(introvert_percentage * scale_factor, 1)
        
        values = [extrovert_percentage, introvert_percentage, ambivert_percentage]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Personality',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_is_organized(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'is_organized', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'is_organized', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Is Organized',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_meet_new_friends(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'meet_new_people', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'meet_new_people', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Meet new friends',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_friend_cycles(self, career, records, total_records):
        labels = ['Many Friends', 'Selected Friends', 'No Friend']
        values = [
            self.calculate_percentage(records, 'many_friend', 'Yes', total_records),
            self.calculate_percentage(records, 'selected_friends', 'Yes', total_records),
            self.calculate_percentage(records, 'no_friend', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Friend Cycles',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_subject_results(self, career, records, total_records):
        labels = ['Good in All Subjects', 'Good in Selected Subjects', 'Good in No Subjects']
        
        # Calculate percentages
        all_subjects = self.calculate_percentage(records, 'good_in_all_subject', 'Yes', total_records)
        
        # For selected subjects, need to check if they have specified subjects
        has_selected = 0
        for record in records:
            if (record.get('good_in_some_subjects', '').lower() == 'yes' or 
                record.get('list_of_subjects_in_school_1', '') or 
                record.get('list_of_subject_in_highschool_1', '')):
                has_selected += 1
        
        selected_subjects = round((has_selected / total_records) * 100, 1) if total_records > 0 else 0
        
        # No subjects is the remainder, ensuring percentages add up to 100%
        no_subjects = max(0, 100 - all_subjects - selected_subjects)
        
        values = [all_subjects, selected_subjects, no_subjects]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Subject Performance',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_sports(self, career, records, total_records):
        labels = ['Yes', 'No']
        values = [
            self.calculate_percentage(records, 'is_interested_in_sport', 'Yes', total_records),
            100 - self.calculate_percentage(records, 'is_interested_in_sport', 'Yes', total_records)
        ]
        
        CareerStatistic.objects.update_or_create(
            career=career,
            category='Sports',
            defaults={
                'labels': labels,
                'values': values
            }
        )
    
    def process_career_info(self, career, records):
        # Helper function to check if a value is meaningful
        def is_meaningful_value(value):
            if not value:  # Skip empty values
                return False
                
            # Skip common "no data" indicators
            skip_values = ['no', 'none', 'n/a', 'nil', 'null', 'undefined', '-']
            return value.strip().lower() not in skip_values
        
        # Helper function to process list fields
        def process_list_field(field_names):
            items = []
            for record in records:
                for field in field_names:
                    if field in record and record[field] and is_meaningful_value(record[field]):
                        items.append(record[field].strip())
            
            # Count and sort items
            item_counts = {}
            for item in items:
                item_counts[item] = item_counts.get(item, 0) + 1
            
            top_items = sorted(item_counts.items(), key=lambda x: x[1], reverse=True)
            return [item[0] for item in top_items[:3]]  # Get top 3 items
        
        # Process each list field
        unique_qualities = process_list_field(['quality_1', 'quality_2', 'quality_3'])
        demanded_qualities = process_list_field([
            'qualities_demanded_in_career_1', 'qualities_demanded_in_career_2', 
            'qualities_demanded_in_career_3', 'qualities_demanded_in_career_4',
            'qualities_demanded_in_career_5', 'qualities_demanded_in_career_6',
            'qualities_demanded_in_career_7'
        ])
        favorite_subjects = process_list_field([
            'list_of_subjects_in_school_1', 'list_of_subjects_in_school_2', 
            'list_of_subjects_in_school_3', 'list_of_subject_in_highschool_1', 
            'list_of_subject_in_highschool_2', 'list_of_subject_in_highschool_3'
        ])
        hobbies = process_list_field(['hobby_1', 'hobby_2', 'hobby_3'])
        suggested_books = process_list_field(['list_of_books_1', 'list_of_books_2'])
        suggested_authors = process_list_field(['list_of_authors_1', 'list_of_authors_2'])
        analytical_skills = process_list_field(['analytical_activities_1', 'analytical_activities_2'])
        communication_skills = process_list_field([
            'communication_activities_1', 'communication_activities_2', 'communication_activities_3'
        ])
        nature_of_service = process_list_field([
            'nature_of_service_1', 'nature_of_service_2', 'nature_of_service_3'
        ])
        sports_activities = process_list_field(['list_of_sports_1', 'list_of_sports_2'])
        public_events = process_list_field(['list_of_events_1', 'list_of_events_2'])
        secondary_domains = process_list_field([
            'secondary_domain_1', 'secondary_domain_2', 
            'secondary_domain_3', 'secondary_domain_4'
        ])
        
        # Create or update career info with all fields
        CareerInfo.objects.update_or_create(
            career=career,
            defaults={
                'unique_qualities': unique_qualities,
                'favorite_subjects': favorite_subjects,
                'hobbies': hobbies,
                'demanded_qualities': demanded_qualities,
                'suggested_books': suggested_books,
                'suggested_authors': suggested_authors,
                'analytical_skills': analytical_skills,
                'communication_skills': communication_skills,
                'nature_of_service': nature_of_service,
                'sports_activities': sports_activities,
                'public_events': public_events,
                'secondary_domains': secondary_domains
            }
        )
    
    def calculate_percentage(self, records, field, value, total):
        """Calculate percentage of records where field equals value"""
        if total == 0:
            return 0
        
        count = sum(1 for record in records if field in record and 
                    record[field].lower() == value.lower())
        
        return round((count / total) * 100, 1)