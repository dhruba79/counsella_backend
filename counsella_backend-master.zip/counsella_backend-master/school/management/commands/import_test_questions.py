import json
import os
from django.core.management.base import BaseCommand
from school.models import AdaptiveTestQuestion

class Command(BaseCommand):
    help = 'Import questions from JSON files to the database and update existing image paths'

    def add_arguments(self, parser):
        parser.add_argument('dir_path', type=str, help='Path to the directory containing question JSON files')
        parser.add_argument('--update-images', action='store_true', help='Update image extensions for existing questions')
        parser.add_argument('--force', action='store_true', help='Force update all fields for matching questions')

    def handle(self, *args, **options):
        dir_path = options['dir_path']
        update_images = options['update_images']
        force_update = options['force']
        
        if not os.path.exists(dir_path):
            self.stdout.write(self.style.ERROR(f'Directory {dir_path} does not exist'))
            return
        
        json_files = [f for f in os.listdir(dir_path) if f.endswith('.json')]
        
        if not json_files:
            self.stdout.write(self.style.ERROR(f'No JSON files found in {dir_path}'))
            return
        
        total_imported = 0
        total_updated = 0
        
        for json_file in json_files:
            file_path = os.path.join(dir_path, json_file)
            category = json_file.replace('.json', '')
            
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                if 'questions' not in data:
                    self.stdout.write(self.style.WARNING(f'No questions found in {json_file}'))
                    continue
                
                questions_imported = 0
                questions_updated = 0
                
                for question_data in data['questions']:
                    # Check if question already exists
                    existing_questions = AdaptiveTestQuestion.objects.filter(
                        category=category,
                        question_text=question_data['question'],
                        difficulty=question_data['difficulty']
                    )
                    
                    image_path = question_data.get('image')
                    
                    # Fix image extension (if needed)
                    if image_path and image_path.endswith('.jpg'):
                        # Change extension from .jpg to .png
                        image_path = image_path.replace('.jpg', '.png')
                        question_data['image'] = image_path
                    
                    if existing_questions.exists():
                        if update_images or force_update:
                            # Update existing question
                            existing = existing_questions.first()
                            
                            # Update image path or all fields based on force_update
                            if force_update:
                                existing.question_text = question_data['question']
                                existing.options = question_data.get('options', {})
                                existing.correct_answer = question_data['correct_answer']
                                existing.explanation = question_data.get('explanation', '')
                            
                            # Always update the image path
                            if image_path:
                                existing.image = image_path
                            
                            existing.save()
                            questions_updated += 1
                            total_updated += 1
                            self.stdout.write(f'Updated question: "{question_data["question"][:50]}..."')
                    else:
                        # Create new question
                        question = AdaptiveTestQuestion(
                            category=category,
                            question_text=question_data['question'],
                            difficulty=question_data['difficulty'],
                            options=question_data.get('options', {}),
                            correct_answer=question_data['correct_answer'],
                            explanation=question_data.get('explanation', ''),
                            image=image_path
                        )
                        question.save()
                        questions_imported += 1
                        total_imported += 1
                        self.stdout.write(f'Imported question: "{question_data["question"][:50]}..."')
                
                self.stdout.write(self.style.SUCCESS(
                    f'Processed {json_file}: imported {questions_imported} questions, updated {questions_updated} questions'
                ))
                
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error processing {json_file}: {str(e)}'))
        
        self.stdout.write(self.style.SUCCESS(
            f'Process complete: imported {total_imported} new questions, updated {total_updated} existing questions'
        ))