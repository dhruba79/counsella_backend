import json
import os
from django.core.management.base import BaseCommand
from school.models import PersonalityTestQuestion

class Command(BaseCommand):
    help = 'Import personality test questions from JSON file'
    
    def add_arguments(self, parser):
        parser.add_argument('--file', type=str, help='Path to JSON file')
    
    def handle(self, *args, **options):
        file_path = options.get('file')
        
        if not file_path:
            file_path = os.path.join('personality-test-questions', 'personality-test-questions.json')
        
        if not os.path.exists(file_path):
            self.stdout.write(self.style.ERROR(f'File not found: {file_path}'))
            return
        
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Count existing questions
        existing_count = PersonalityTestQuestion.objects.count()
        if existing_count > 0:
            if input(f"Found {existing_count} existing questions. Delete them? (y/n): ").lower() == 'y':
                PersonalityTestQuestion.objects.all().delete()
                self.stdout.write(self.style.SUCCESS(f'Deleted {existing_count} existing questions'))
            else:
                self.stdout.write(self.style.WARNING('Import cancelled'))
                return
        
        # Process dimensions and questions
        question_count = 0
        for dimension_data in data.get('dimensions', []):
            dimension_name = dimension_data.get('name', '')
            dimension_code = self._get_dimension_code(dimension_name)
            
            for i, question_data in enumerate(dimension_data.get('questions', []), 1):
                # Get option texts
                option_keys = list(question_data.keys())
                if len(option_keys) != 2:
                    self.stdout.write(self.style.WARNING(f'Skipping malformed question: {question_data}'))
                    continue
                
                # Create question object
                PersonalityTestQuestion.objects.create(
                    dimension=dimension_code,
                    question_number=i,
                    option_a_text=question_data.get(option_keys[0], ''),
                    option_b_text=question_data.get(option_keys[1], '')
                )
                question_count += 1
        
        self.stdout.write(self.style.SUCCESS(f'Successfully imported {question_count} questions'))
    
    def _get_dimension_code(self, dimension_name):
        """Extract dimension code from name"""
        if 'Extraversion' in dimension_name and 'Introversion' in dimension_name:
            return 'E_I'
        elif 'Sensing' in dimension_name and 'Intuition' in dimension_name:
            return 'S_N'
        elif 'Thinking' in dimension_name and 'Feeling' in dimension_name:
            return 'T_F'
        elif 'Judging' in dimension_name and 'Perceiving' in dimension_name:
            return 'J_P'
        return dimension_name