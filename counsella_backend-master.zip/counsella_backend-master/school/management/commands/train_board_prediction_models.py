import os
import pandas as pd
import logging
from django.core.management.base import BaseCommand
from django.conf import settings
from scripts.data_science.board_results_prediction import (
    process_csv_file, create_combined_dataset, 
    train_subject_models, save_models
)
from school.models import SchoolStudentResults, School

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Train board result prediction models using historical data'

    def add_arguments(self, parser):
        parser.add_argument('--school_id', type=int, help='ID of the school to train models for')
        parser.add_argument('--years', nargs='+', type=int, help='Academic years to use for training, e.g., 2022 2023')
        parser.add_argument('--manual_files', nargs='+', type=str, 
                           help='Manual file paths if not using school database records')
        parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')

    def handle(self, *args, **options):
        school_id = options.get('school_id')
        years = options.get('years')
        manual_files = options.get('manual_files')
        verbose = options.get('verbose', False)
        
        if verbose:
            # Configure more detailed logging
            logging.basicConfig(level=logging.INFO)
        
        if school_id:
            try:
                school = School.objects.get(id=school_id)
                self.stdout.write(self.style.SUCCESS(f"Training models for school: {school.name}"))
            except School.DoesNotExist:
                self.stderr.write(self.style.ERROR(f"School with ID {school_id} not found"))
                return
        else:
            self.stdout.write(self.style.WARNING("No school_id provided, training global models"))
            
        if manual_files:
            self.train_with_manual_files(manual_files, school_id, verbose=verbose)
        elif years:
            self.train_with_school_data(school_id, years, verbose=verbose)
        else:
            self.stderr.write(self.style.ERROR("Please provide either --years or --manual_files"))
            return
    
    def train_with_school_data(self, school_id, years, verbose=False):
        """Train models using data from the school database"""
        self.stdout.write(f"Training with school data for years: {years}")
        
        # Implementation for database records...
    
    def train_with_manual_files(self, manual_files, school_id, verbose=False):
        """Train models using manually specified files"""
        self.stdout.write(f"Training with manual files: {manual_files}")
        
        if len(manual_files) < 8:
            self.stderr.write(self.style.ERROR(
                "Need 8 files: half_yearly1, pretest1_1, pretest2_1, board1, "
                "half_yearly2, pretest1_2, pretest2_2, board2"
            ))
            return
        
        try:
            # Process files with absolute paths
            fixed_files = []
            for file_path in manual_files:
                # Check if it's already an absolute path
                if os.path.isabs(file_path):
                    fixed_files.append(file_path)
                else:
                    # Make it absolute by joining with MEDIA_ROOT
                    fixed_files.append(os.path.join(settings.MEDIA_ROOT, file_path))
            
            # Process first year
            self.stdout.write("Processing files for first year...")
            half_data1 = pd.read_csv(fixed_files[0])
            pretest1_data1 = pd.read_csv(fixed_files[1])
            pretest2_data1 = pd.read_csv(fixed_files[2])
            board_data1 = pd.read_csv(fixed_files[3])
            
            if verbose:
                self.stdout.write(f"  Half-yearly: {len(half_data1)} rows")
                self.stdout.write(f"  Pretest1: {len(pretest1_data1)} rows")
                self.stdout.write(f"  Pretest2: {len(pretest2_data1)} rows")
                self.stdout.write(f"  Board: {len(board_data1)} rows")
                
                # Check common records between half-yearly and pretest1
                common = pd.merge(
                    half_data1[['Name', 'Roll Number']], 
                    pretest1_data1[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                self.stdout.write(f"  Common records (half & pretest1): {len(common)}")
                
                # Check common records with pretest2
                common = pd.merge(
                    common, 
                    pretest2_data1[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                self.stdout.write(f"  Common records (half, pretest1, pretest2): {len(common)}")
                
                # Check common records with board
                common = pd.merge(
                    common, 
                    board_data1[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                self.stdout.write(f"  Common records (all first year): {len(common)}")
            
            # Process second year
            self.stdout.write("Processing files for second year...")
            half_data2 = pd.read_csv(fixed_files[4])
            pretest1_data2 = pd.read_csv(fixed_files[5])
            pretest2_data2 = pd.read_csv(fixed_files[6])
            board_data2 = pd.read_csv(fixed_files[7])
            
            if verbose:
                self.stdout.write(f"  Half-yearly: {len(half_data2)} rows")
                self.stdout.write(f"  Pretest1: {len(pretest1_data2)} rows")
                self.stdout.write(f"  Pretest2: {len(pretest2_data2)} rows")
                self.stdout.write(f"  Board: {len(board_data2)} rows")
                
                # Check common records for second year
                common = pd.merge(
                    half_data2[['Name', 'Roll Number']], 
                    pretest1_data2[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                common = pd.merge(
                    common, 
                    pretest2_data2[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                common = pd.merge(
                    common, 
                    board_data2[['Name', 'Roll Number']], 
                    on=['Name', 'Roll Number'], 
                    how='inner'
                )
                self.stdout.write(f"  Common records (all second year): {len(common)}")
            
            # Directly use pandas to create training data for year 1
            self.stdout.write("Creating combined dataset for first year...")
            
            # Get list of common subjects across all datasets
            subjects = [
                'Literature', 'Grammer', 'History', 'Geography', 
                'Math', 'Biology', 'Physics', 'Chemistry'
            ]
            
            # Student identifier columns
            id_cols = ['Name', 'Roll Number']
            
            # Create training dataset for first year
            try:
                # Merge datasets for first year
                half1 = half_data1[id_cols + subjects].copy()
                half1.columns = id_cols + [f'half_{s}' for s in subjects]
                
                pretest1_1 = pretest1_data1[id_cols + subjects].copy()
                pretest1_1.columns = id_cols + [f'pretest1_{s}' for s in subjects]
                
                data1 = pd.merge(half1, pretest1_1, on=id_cols, how='inner')
                self.stdout.write(f"  After merging half and pretest1: {len(data1)} records")
                
                pretest2_1 = pretest2_data1[id_cols + subjects].copy()
                pretest2_1.columns = id_cols + [f'pretest2_{s}' for s in subjects]
                
                data1 = pd.merge(data1, pretest2_1, on=id_cols, how='inner')
                self.stdout.write(f"  After merging pretest2: {len(data1)} records")
                
                board1 = board_data1[id_cols + subjects].copy()
                board1.columns = id_cols + [f'board_{s}' for s in subjects]
                
                data1 = pd.merge(data1, board1, on=id_cols, how='inner')
                self.stdout.write(f"  Final first year dataset: {len(data1)} records")
                
                # Add features
                for subject in subjects:
                    # Differences
                    data1[f'half_pretest1_diff_{subject}'] = data1[f'half_{subject}'] - data1[f'pretest1_{subject}']
                    data1[f'half_pretest2_diff_{subject}'] = data1[f'half_{subject}'] - data1[f'pretest2_{subject}']
                    
                    # Linear prediction
                    data1[f'linear_pred_{subject}'] = data1[f'half_{subject}'] + 10
                
                # Same for second year
                self.stdout.write("Creating combined dataset for second year...")
                half2 = half_data2[id_cols + subjects].copy()
                half2.columns = id_cols + [f'half_{s}' for s in subjects]
                
                pretest1_2 = pretest1_data2[id_cols + subjects].copy()
                pretest1_2.columns = id_cols + [f'pretest1_{s}' for s in subjects]
                
                data2 = pd.merge(half2, pretest1_2, on=id_cols, how='inner')
                self.stdout.write(f"  After merging half and pretest1: {len(data2)} records")
                
                pretest2_2 = pretest2_data2[id_cols + subjects].copy()
                pretest2_2.columns = id_cols + [f'pretest2_{s}' for s in subjects]
                
                data2 = pd.merge(data2, pretest2_2, on=id_cols, how='inner')
                self.stdout.write(f"  After merging pretest2: {len(data2)} records")
                
                board2 = board_data2[id_cols + subjects].copy()
                board2.columns = id_cols + [f'board_{s}' for s in subjects]
                
                data2 = pd.merge(data2, board2, on=id_cols, how='inner')
                self.stdout.write(f"  Final second year dataset: {len(data2)} records")
                
                # Add features
                for subject in subjects:
                    data2[f'half_pretest1_diff_{subject}'] = data2[f'half_{subject}'] - data2[f'pretest1_{subject}']
                    data2[f'half_pretest2_diff_{subject}'] = data2[f'half_{subject}'] - data2[f'pretest2_{subject}']
                    data2[f'linear_pred_{subject}'] = data2[f'half_{subject}'] + 10
                
                # Combine both years
                combined_data = pd.concat([data1, data2], ignore_index=True)
                self.stdout.write(self.style.SUCCESS(
                    f"Combined data from all years: {len(combined_data)} total records"
                ))
                
                # Train models
                self.stdout.write("Training models...")
                models, metrics, _ = train_subject_models(combined_data, subjects)
                
                # Save models
                timestamp = save_models(models, metrics, subjects, school_id=school_id)
                
                self.stdout.write(self.style.SUCCESS(
                    f"Successfully trained and saved models with timestamp: {timestamp}"
                ))
                
                # Print metrics
                self.stdout.write("Model performance metrics:")
                for subject, metric in metrics.items():
                    self.stdout.write(f"  {subject}: R² = {metric['r2']:.4f}, MSE = {metric['mse']:.4f}")
                    
            except Exception as e:
                self.stderr.write(self.style.ERROR(f"Error creating training dataset: {str(e)}"))
                import traceback
                traceback.print_exc()
                
        except Exception as e:
            self.stderr.write(self.style.ERROR(f"Error training models: {str(e)}"))
            import traceback
            traceback.print_exc()