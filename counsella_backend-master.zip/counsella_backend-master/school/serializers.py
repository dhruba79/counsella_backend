from django.contrib.auth import get_user_model
from rest_framework import serializers
from django.utils.timezone import now

from account.serializers import UserRegistrationSerializer
from .models import CareerCounselingRequest, School, SchoolBoard, Student, SchoolStudentResults, Career, CareerStatistic, CareerInfo, StudentTestResults, StudentTestResultsSummary, TestResultsUploadBatch, FeedbackQuestion, FeedbackSubmission, LeadershipTrait, StudentPercentileMarks


User = get_user_model()


class SchoolBoardSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolBoard
        fields = ['id', 'name', 'is_active', 'created_at', 'updated_at']


class SchoolBoardActivationSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolBoard
        fields = ['is_active']


class SchoolCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = [
            'uid', 'name', 'address', 'school_board', 'registration_no',
            'contact_name', 'contact_no', 'contact_email',
            'is_active', 'is_email_verified', 'is_mobile_verified'
        ]
        read_only_fields = ['uid', 'is_active', 'is_email_verified', 'is_mobile_verified']
    
    def validate(self, data):
        # Check for duplicate email
        if School.objects.filter(contact_email=data.get('contact_email')).exists():
            raise serializers.ValidationError({'contact_email': 'A school with this email already exists.'})
        
        # Check for duplicate contact number
        if School.objects.filter(contact_no=data.get('contact_no')).exists():
            raise serializers.ValidationError({'contact_no': 'A school with this contact number already exists.'})
            
        return data


class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = [
            'uid', 'name', 'address', 'school_board', 'registration_no',
            'contact_name', 'contact_no', 'contact_email',
            'is_active', 'is_email_verified', 'is_mobile_verified', 'created_at', 'updated_at'
        ]


class SchoolUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = [
            'uid', 'name', 'address', 'school_board', 'registration_no',
            'contact_name', 'contact_no', 'contact_email',
            'is_active', 'is_email_verified', 'is_mobile_verified', 'created_at', 'updated_at'
        ]

        read_only_fields = ['uid', 'is_active', 'is_email_verified', 'is_mobile_verified', 'created_at']

    def validate(self, data):
        return data


class SchoolActivationSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = ['is_active']

class SchoolAdminSerializer(serializers.ModelSerializer):
    """Serializer for creating a school admin user"""

    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(style={'input_type': 'password'}, write_only=True)
    contact_number = serializers.CharField()

    class Meta:
        model = User
        fields = ['email', 'name', 'password', 'confirm_password', 'contact_number']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate(self, attrs):
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')

        if password != confirm_password:
            raise serializers.ValidationError('Password and Confirm Password doesn\'t macth')

        return attrs

    def create(self, validated_data):
        """Create the school admin with hashed password"""

        # Check if email already exists
        if User.objects.filter(email=validated_data['email']).exists():
            raise serializers.ValidationError({'email': 'This email address is already in use.'})
        
        # Check if contact number already exists
        if User.objects.filter(contact_number=validated_data['contact_number']).exists():
            raise serializers.ValidationError({'contact_number': 'This contact number is already in use.'})

        user = User.objects.create(
            email=validated_data['email'],
            name=validated_data['name'],
            contact_number=validated_data['contact_number'],
            is_active=True,
            is_school_admin=True
        )
        print (user.is_active)
        user.set_password(validated_data['password'])
        user.save()
        return user

class SchoolWithAdminSerializer(serializers.ModelSerializer):
    """Serializer to create School along with an Admin"""

    admin = SchoolAdminSerializer()

    class Meta:
        model = School
        fields = ['name', 'address', 'contact_no', 'contact_email', 'admin']

    def create(self, validated_data):
        """Override create method to create both School and Admin"""
        admin_data = validated_data.pop('admin')  # Extract admin data
        
        # Create School Admin
        admin = SchoolAdminSerializer().create(admin_data)

        # Create School
        school = School.objects.create(
            **validated_data,
            admin=admin,
            is_active=True  # TODO: make default false in production
        )
        
        school.save()
        return school

class SchoolStudentSerializer(serializers.ModelSerializer):
    """Serializer for registering students"""
    email = serializers.EmailField() 
    student_name = serializers.CharField(source='user.name')
    school_name = serializers.CharField(write_only=True)
    class_ = serializers.CharField(source='student_class')
    mobile_number = serializers.CharField(source='contact_number')
    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model = Student
        fields = [
            'email', 
            'student_name',
            'school_name', 
            'birth_date',
            'class_',
            'mobile_number',
            'address',
            'password',
            'confirm_password'
        ]

    def validate(self, attrs):
        password = attrs.get('password')
        confirm_password = attrs.get('confirm_password')

        # Check if email is already in use
        email = attrs.get('email')
        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError({'email': 'This email address is already in use.'})
        
        # Validate school exists
        school_name = attrs.pop('school_name')
        try:
            self.school = School.objects.get(name=school_name)
        except School.DoesNotExist:
            raise serializers.ValidationError({'school_name': 'School not found'})

        return attrs


    def create(self, validated_data):
        password = validated_data.pop('password')
        validated_data.pop('confirm_password')
        email = validated_data.pop('email')
        
        user_data = validated_data.pop('user')
        student_name = user_data['name']

        # Create User
        user = User.objects.create(
            email=email,
            name=student_name,
            is_school_student=True,
            is_active=True  # TODO: make false in production
        )
        user.set_password(password)
        user.save()

        # Create Student Profile
        student = Student.objects.create(
            user=user,
            school=self.school,
            student_class=validated_data['student_class'],
            contact_number=validated_data['contact_number'],
            birth_date=validated_data['birth_date'],
            address=validated_data['address']
        )
        return student

class SchoolUserLoginSerializer(serializers.ModelSerializer):

    email = serializers.EmailField(max_length=255)
    password = serializers.CharField(style={'input_type': 'password'}, write_only=True)
    class Meta:
        model = User
        fields = ['email', 'password']


class StudentProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['user', 'school', 'student_class', 'section', 'roll_number', 'birth_date', 'registration_no', 'avatar']
        read_only_fields = ['user', 'school']  # Prevent updating these fields

    def get_avatar(self, obj):
        request = self.context.get('request')
        if obj.avatar:
            return request.build_absolute_uri(obj.avatar.url)
        return None


class SchoolResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolStudentResults
        fields = [ 'year', 'pretest1_result', 'pretest2_result', 'half_yearly_result', 'board_result', 'uploaded_at']
        read_only_fields = ['uploaded_at']
    
    def validate(self, data):
        current_year = now().year
        year = data.get('year')
        if year > current_year:
            raise serializers.ValidationError('Year cannot be greater than current year.')
        if year == current_year:
            if 'board_result' in data:
                data.pop('board_result')
        else:
            if not data.get('half_yearly_result'):
                raise serializers.ValidationError('Half Yearly Result is required for previous years.')
            if not data.get('board_result'):
                raise serializers.ValidationError('Board Result is required for previous years.')
        return data

    def create(self, validated_data):
        # Automatically set the school from the request context
        request = self.context.get('request')
        validated_data['school'] = request.user.school_admin
        return super().create(validated_data)
    
class ProcessResultsSerializer(serializers.Serializer):
    # 5MB = 5 * 1024 * 1024 bytes
    MAX_FILE_SIZE = 5 * 1024 * 1024  

    # Keep these exact parameter names to match frontend
    pre_board_1 = serializers.FileField()
    pre_board_2 = serializers.FileField()
    half_yearly = serializers.FileField(required=False)
    board = serializers.FileField(required=False)  # Add board parameter
    academic_year = serializers.IntegerField()
    section = serializers.CharField(max_length=10, required=False, default="A")
    class_number = serializers.IntegerField(min_value=1, max_value=12, required=False, default=10)
    
    def validate_pre_board_1(self, value):
        return self._validate_file(value)
    
    def validate_pre_board_2(self, value):
        return self._validate_file(value)
    
    def validate_half_yearly(self, value):
        if value:
            return self._validate_file(value)
        return value
    
    def validate_board(self, value):  # Add validation for board file
        if value:
            return self._validate_file(value)
        return value
    
    def _validate_file(self, value):
        if not value.name.endswith('.csv'):
            raise serializers.ValidationError("Only CSV files are allowed")
        
        if value.size > self.MAX_FILE_SIZE:
            raise serializers.ValidationError(
                f"File size cannot exceed {self.MAX_FILE_SIZE/1024/1024}MB"
            )
        
        return value

    def validate_academic_year(self, value):
        from django.utils.timezone import now
        current_year = now().year
        if value > current_year:
            raise serializers.ValidationError("Academic year cannot be greater than current year")
        return value

class ResultFilterSerializer(serializers.Serializer):
    exam_type = serializers.ChoiceField(
        choices=['pre_board_1', 'pre_board_2', 'half_yearly', 'board', 'pretest1', 'pretest2'],
        required=False
    )
    academic_year = serializers.IntegerField(required=False)
    section = serializers.CharField(required=False)

class StudentPercentileSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    roll_number = serializers.IntegerField(source='Roll Number')
    name = serializers.CharField(source='Name')
    literature = serializers.FloatField(source='Literature')
    grammer = serializers.FloatField(source='Grammer')
    history = serializers.FloatField(source='History')
    geography = serializers.FloatField(source='Geography')
    math = serializers.FloatField(source='Math')
    biology = serializers.FloatField(source='Biology')
    physics = serializers.FloatField(source='Physics')
    chemistry = serializers.FloatField(source='Chemistry')
    class_field = serializers.IntegerField(source='Class')
    
    class Meta:
        fields = (
            'id', 'roll_number', 'name', 'literature', 'grammer', 'history', 'geography', 
            'math', 'biology', 'physics', 'chemistry', 'class_field'
        )

class StudentGradeSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    roll_number = serializers.IntegerField(source='Roll Number')
    name = serializers.CharField(source='Name')
    literature = serializers.CharField(source='Literature')
    grammer = serializers.CharField(source='Grammer')
    history = serializers.CharField(source='History')
    geography = serializers.CharField(source='Geography')
    math = serializers.CharField(source='Math')
    biology = serializers.CharField(source='Biology')
    physics = serializers.CharField(source='Physics')
    chemistry = serializers.CharField(source='Chemistry')
    class_field = serializers.IntegerField(source='Class')

    class Meta:
        fields = (
            'id', 'roll_number', 'name', 'literature', 'grammer', 'history', 'geography', 
            'math', 'biology', 'physics', 'chemistry', 'class_field'
        )
class StudentResultsListSerializer(serializers.Serializer):
    exam_type = serializers.CharField(read_only=True)
    academic_year = serializers.IntegerField(read_only=True)
    section = serializers.CharField(read_only=True)
    file_path = serializers.CharField(read_only=True)
    
    class Meta:
        fields = ('exam_type', 'academic_year', 'section', 'file_path')

class SubjectSerializer(serializers.Serializer):
    label = serializers.CharField()
    value = serializers.CharField()

class StudentAverageGradesSerializer(serializers.Serializer):
    student_id = serializers.IntegerField()
    student_name = serializers.CharField()
    class_number = serializers.IntegerField(source='class')
    roll_number = serializers.IntegerField(allow_null=True)
    school_name = serializers.CharField()
    academic_year = serializers.IntegerField()
    literature = serializers.CharField(source='subjects.Literature', default='N/A')
    grammar = serializers.CharField(source='subjects.Grammer', default='N/A')
    history = serializers.CharField(source='subjects.History', default='N/A')
    geography = serializers.CharField(source='subjects.Geography', default='N/A')
    math = serializers.CharField(source='subjects.Math', default='N/A')
    biology = serializers.CharField(source='subjects.Biology', default='N/A')
    physics = serializers.CharField(source='subjects.Physics', default='N/A')
    chemistry = serializers.CharField(source='subjects.Chemistry', default='N/A')

class CareerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Career
        fields = ['name', 'value']

class CareerStatisticSerializer(serializers.ModelSerializer):
    class Meta:
        model = CareerStatistic
        fields = ['category', 'labels', 'values']

class CareerInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = CareerInfo
        fields = [
            'unique_qualities', 
            'favorite_subjects', 
            'hobbies',
            'demanded_qualities',
            'suggested_books',
            'suggested_authors',
            'analytical_skills',
            'communication_skills',
            'nature_of_service',
            'sports_activities',
            'public_events',
            'secondary_domains'
        ]

class CareerDetailSerializer(serializers.ModelSerializer):
    statistics = CareerStatisticSerializer(many=True, read_only=True)
    info = CareerInfoSerializer(read_only=True)
    
    class Meta:
        model = Career
        fields = ['name', 'value', 'statistics', 'info']

class StudentAvatarSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['avatar']
        # Add this to bypass Django's default image validation
        extra_kwargs = {
            'avatar': {'required': False, 'allow_null': True, 'use_url': True}
        }
    
    # Remove any custom validation methods for testing
        
    def validate_avatar(self, value):
        # Define maximum file size (e.g., 5MB)
        max_size = 5 * 1024 * 1024  # 5MB in bytes
        
        if value.size > max_size:
            raise serializers.ValidationError(f"Image file too large. Maximum size is {max_size/1024/1024}MB.")
            
        # Check file type
        allowed_types = ['image/jpeg', 'image/png', 'image/gif']
        if value.content_type not in allowed_types:
            raise serializers.ValidationError(f"Invalid image format. Allowed formats: {', '.join(allowed_types)}")
            
        return value

class BoardResultPredictionSerializer(serializers.Serializer):
    # Match frontend parameter names exactly
    pre_board_1 = serializers.FileField(required=True)
    pre_board_2 = serializers.FileField(required=True)
    half_yearly = serializers.FileField(required=False)
    board = serializers.FileField(required=False, help_text="Optional: Provide actual board results for training")
    
    academic_year = serializers.IntegerField(required=True, help_text="Academic year for predictions")
    retrain_model = serializers.BooleanField(default=False, help_text="Whether to retrain the model")
    overwrite_existing = serializers.BooleanField(default=False, help_text="Whether to overwrite existing predictions")
    
    def validate(self, data):
        # Validate academic year is not in the future
        from django.utils.timezone import now
        current_year = now().year
        if data.get('academic_year') > current_year:
            raise serializers.ValidationError("Academic year cannot be in the future")
        
        return data
    
class BoardPredictionSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True, required=False)
    roll_number = serializers.IntegerField(source='Roll Number')
    name = serializers.CharField(source='Name')
    
    # Dynamically create fields for all predicted subjects
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # If instance is provided (when serializing)
        if args and args[0]:
            data = args[0]
            # Check if it's a list
            first_item = data[0] if isinstance(data, list) else data
            
            # Add fields dynamically based on predicted columns
            for key in first_item:
                if key.startswith('predicted_board_'):
                    subject = key.replace('predicted_board_', '').lower()
                    self.fields[subject] = serializers.FloatField(source=key, required=False)

class TestResultsUploadSerializer(serializers.Serializer):
    """Serializer for uploading single student test results"""
    
    # File uploads (at least one required)
    personality_test_file = serializers.FileField(required=False, allow_null=True)
    aptitude_test_file = serializers.FileField(required=False, allow_null=True)
    percentile_results_file = serializers.FileField(required=False, allow_null=True)
    
    # Metadata
    academic_year = serializers.IntegerField()
    section = serializers.CharField(max_length=10, required=False, default="A")
    class_number = serializers.IntegerField(min_value=1, max_value=12, required=False, default=10)
    
    # Processing options (only for admins)
    create_missing_students = serializers.BooleanField(default=True)
    overwrite_existing = serializers.BooleanField(default=True)  # Changed default to True for easier updates
    
    # File size limit (5MB)
    MAX_FILE_SIZE = 5 * 1024 * 1024
    
    def validate(self, data):
        """Validate that at least one file is provided and academic year is valid"""
        files_provided = [
            data.get('personality_test_file'),
            data.get('aptitude_test_file'),
            data.get('percentile_results_file')
        ]
        
        if not any(files_provided):
            raise serializers.ValidationError(
                "At least one test result file must be provided"
            )
        
        # Validate academic year
        current_year = now().year
        if data.get('academic_year') > current_year:
            raise serializers.ValidationError(
                "Academic year cannot be greater than current year"
            )
        
        return data
    
    def validate_personality_test_file(self, value):
        if value:
            return self._validate_file(value, 'personality')
        return value
    
    def validate_aptitude_test_file(self, value):
        if value:
            return self._validate_file(value, 'aptitude')
        return value
    
    def validate_percentile_results_file(self, value):
        if value:
            return self._validate_file(value, 'percentile')
        return value
    
    def _validate_file(self, file, file_type):
        """Common file validation for single student files"""
        # Check file size
        if file.size > self.MAX_FILE_SIZE:
            raise serializers.ValidationError(
                f"File size cannot exceed {self.MAX_FILE_SIZE/1024/1024}MB"
            )
        
        # Check file extension
        if not file.name.lower().endswith('.csv'):
            raise serializers.ValidationError("Only CSV files are allowed")
        
        # Validate CSV structure
        try:
            file.seek(0)
            content = file.read(2048).decode('utf-8')  # Read more content for validation
            file.seek(0)  # Reset file pointer
            
            lines = content.split('\n')
            if len(lines) < 2:
                raise serializers.ValidationError("CSV file must contain a header and at least one data row")
            
            # Check that there's only one data row (plus header)
            data_rows = [line.strip() for line in lines[1:] if line.strip()]
            if len(data_rows) != 1:
                raise serializers.ValidationError(
                    f"CSV file must contain exactly one student record. Found {len(data_rows)} records."
                )
            
            # Validate required columns
            header_line = lines[0] if lines else ""
            required_columns = self._get_required_columns(file_type)
            
            missing_columns = []
            for col in required_columns:
                if col not in header_line:
                    missing_columns.append(col)
            
            if missing_columns:
                raise serializers.ValidationError(
                    f"Missing required columns for {file_type}: {', '.join(missing_columns)}"
                )
                
        except UnicodeDecodeError:
            raise serializers.ValidationError("File must be a valid CSV with UTF-8 encoding")
        except Exception as e:
            if "exactly one student record" in str(e):
                raise e  # Re-raise our custom validation error
            raise serializers.ValidationError(f"Invalid CSV file: {str(e)}")
        
        return file
    
    def _get_required_columns(self, file_type):
        """Get required columns for each file type"""
        base_columns = ['Name', 'Email', 'Roll Number', 'Class']
        
        if file_type == 'personality':
            personality_columns = [
                'Introvert %', 'Extrovert %', 'Total',
                'Sensing %', 'Intuitive %', 'Total.1',
                'Thinking %', 'Feeling %', 'Total.2',
                'Judging %', 'Perceiving %', 'Total'  # Note: Last column might be 'Total' or 'Total.3'
            ]
            return base_columns + personality_columns
            
        elif file_type == 'aptitude':
            aptitude_columns = [
                'Total', 'Numerical Aptitude', 'Verbal Aptitude', 'Logical Aptitude',
                'Abstract Reasoning', 'Spatial Aptitude', 'Mechanical Aptitude',
                'Clerical Aptitude', 'Attention to Details', 'General Knowledge And Awareness',
                'Technical Aptitude', 'Situtational Judgement', 'Memory Retention'
            ]
            return base_columns + aptitude_columns
            
        elif file_type == 'percentile':
            percentile_columns = [
                'Literature', 'Grammer', 'History', 'Geography',
                'Math', 'Biology', 'Physics', 'Chemistry'
            ]
            return base_columns + percentile_columns
        
        return base_columns

class StudentTestResultsSerializer(serializers.ModelSerializer):
    """Serializer for StudentTestResults model with safe Azure URLs"""
    student_name = serializers.CharField(source='student.user.name', read_only=True)
    student_email = serializers.CharField(source='student.user.email', read_only=True)
    school_name = serializers.CharField(source='student.school.name', read_only=True)
    
    # Add URL fields
    personality_test_url = serializers.SerializerMethodField()
    aptitude_test_url = serializers.SerializerMethodField()
    percentile_results_url = serializers.SerializerMethodField()
    
    class Meta:
        model = StudentTestResults
        fields = [
            'id', 'student', 'student_name', 'student_email', 'school_name',
            'academic_year', 'personality_test_file', 'aptitude_test_file',
            'percentile_results_file', 'personality_test_url', 'aptitude_test_url',
            'percentile_results_url', 'uploaded_at', 'updated_at',
            'is_processed', 'processing_errors'
        ]
        read_only_fields = ['uploaded_at', 'updated_at']
    
    def _get_safe_azure_url(self, file_field):
        """Safely get Azure URL without triggering local file access"""
        if not file_field or not file_field.name:
            return None
            
        try:
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            return azure_storage.url(file_field.name)
        except Exception as e:
            print(f"Error getting Azure URL: {e}")
            
            # Fallback: construct URL manually
            try:
                from django.conf import settings
                account_name = getattr(settings, 'AZURE_ACCOUNT_NAME', None)
                container_name = getattr(settings, 'AZURE_CONTAINER', 'media')
                
                if account_name and file_field.name:
                    return f"https://{account_name}.blob.core.windows.net/{container_name}/{file_field.name}"
            except:
                pass
                
            return None
    
    def get_personality_test_url(self, obj):
        return self._get_safe_azure_url(obj.personality_test_file)
    
    def get_aptitude_test_url(self, obj):
        return self._get_safe_azure_url(obj.aptitude_test_file)
    
    def get_percentile_results_url(self, obj):
        return self._get_safe_azure_url(obj.percentile_results_file)

class StudentTestResultsSummarySerializer(serializers.ModelSerializer):
    """Serializer for StudentTestResultsSummary model"""
    student_name = serializers.CharField(source='student_test_results.student.user.name', read_only=True)
    academic_year = serializers.IntegerField(source='student_test_results.academic_year', read_only=True)
    
    class Meta:
        model = StudentTestResultsSummary
        fields = [
            'id', 'student_name', 'academic_year', 'personality_type',
            'personality_dimensions', 'total_aptitude_score', 'aptitude_scores',
            'aptitude_percentiles', 'academic_percentiles', 'overall_academic_percentile',
            'academic_grade', 'school_rank', 'class_rank', 'processed_at', 'updated_at'
        ]

class TestResultsUploadBatchSerializer(serializers.ModelSerializer):
    """Serializer for TestResultsUploadBatch model"""
    school_name = serializers.CharField(source='school.name', read_only=True)
    uploaded_by_name = serializers.CharField(source='uploaded_by.name', read_only=True)
    
    class Meta:
        model = TestResultsUploadBatch
        fields = [
            'id', 'school', 'school_name', 'academic_year', 'upload_type',
            'uploaded_by', 'uploaded_by_name', 'uploaded_at', 'total_records',
            'successful_uploads', 'failed_uploads', 'processing_errors',
            'is_completed', 'success_rate'
        ]
        read_only_fields = ['uploaded_at', 'success_rate']

class CareerCounselingRequestSerializer(serializers.ModelSerializer):
    """Serializer for career counseling requests"""
    
    # Form fields
    name = serializers.CharField(max_length=255, required=True)
    email = serializers.EmailField(required=True)
    phone = serializers.CharField(max_length=20, required=True)
    career = serializers.CharField(source='career_field', max_length=255, required=True)
    file = serializers.FileField(source='pdf_file', required=True)
    
    # Read-only fields for response
    student_name = serializers.CharField(source='student.user.name', read_only=True)
    school_name = serializers.CharField(source='student.school.name', read_only=True)
    
    class Meta:
        model = CareerCounselingRequest
        fields = [
            'id', 'name', 'email', 'phone', 'career', 'file',
            'student_name', 'school_name', 'counselor_email',
            'email_status', 'email_sent_at', 'created_at'
        ]
        read_only_fields = [
            'id', 'student_name', 'school_name', 'counselor_email',
            'email_status', 'email_sent_at', 'created_at'
        ]
    
    def validate_file(self, value):
        """Validate the uploaded PDF file"""
        # File size validation (5MB)
        max_size = 5 * 1024 * 1024  # 5MB in bytes
        
        if value.size > max_size:
            raise serializers.ValidationError(
                f"File size cannot exceed {max_size/1024/1024}MB. Current file size: {value.size/1024/1024:.2f}MB"
            )
        
        # File type validation
        if not value.name.lower().endswith('.pdf'):
            raise serializers.ValidationError("Only PDF files are allowed")
        
        # Content type validation
        if value.content_type != 'application/pdf':
            raise serializers.ValidationError("Invalid file type. Only PDF files are accepted")
        
        return value
    
    def validate_name(self, value):
        """Validate name field"""
        if not value.strip():
            raise serializers.ValidationError("Name cannot be empty")
        return value.strip()
    
    def validate_phone(self, value):
        """Validate phone field"""
        if not value.strip():
            raise serializers.ValidationError("Phone number cannot be empty")
        return value.strip()
    
    def validate_career_field(self, value):
        """Validate career field"""
        if not value.strip():
            raise serializers.ValidationError("Career field cannot be empty")
        return value.strip()

class CareerCounselingRequestResponseSerializer(serializers.ModelSerializer):
    """Serializer for API response after creating a career counseling request"""
    
    student_name = serializers.CharField(source='student.user.name', read_only=True)
    school_name = serializers.CharField(source='student.school.name', read_only=True)
    
    class Meta:
        model = CareerCounselingRequest
        fields = [
            'id', 'student_name', 'school_name', 'name', 'email', 
            'phone', 'career_field', 'counselor_email', 'email_status', 
            'email_sent_at', 'mailchimp_email_id', 'created_at'
        ]
#new api feedback models

class ResponseSerializer(serializers.Serializer):
    qid = serializers.CharField()
    answer = serializers.JSONField()

class FeedbackSubmissionSerializer(serializers.Serializer):
    user_id = serializers.CharField()
    fid = serializers.CharField()
    responses = ResponseSerializer(many=True)
    submitted_at = serializers.DateTimeField(read_only=True)

    def save(self, **kwargs):
        user_id = self.validated_data['user_id'].strip().lower()
        fid = self.validated_data['fid'].strip().lower()
        responses = self.validated_data['responses']

        instance, _ = FeedbackSubmission.objects.update_or_create(
            user_id=user_id,
            fid=fid,
            defaults={
                'responses': responses,
                'submitted_at': now()
            }
        )
        return instance
    

#leadership trait model
class LeadershipTraitSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeadershipTrait
        fields = [
            'leadership_trait_name',
            'unique_qualities',
            'hobbies',
            'books',
            'authors',
            'communication_activities',
            'public_service',
            'secondary_domain',
            'analytical_activities',
            'favourite_subjects',
            'suggestions' ,
        ]

class FeedbackQuestionSerializer(serializers.ModelSerializer):
    """Serializer for feedback questions"""
    
    class Meta:
        model = FeedbackQuestion
        fields = ['fid', 'qid', 'type', 'label', 'options']

class SubjectMarkInputSerializer(serializers.Serializer):
    subject = serializers.CharField()
    full_marks = serializers.IntegerField()
    exam1 = serializers.IntegerField()
    exam2 = serializers.IntegerField()
    exam3 = serializers.IntegerField()

class StudentPercentileMarksSerializer(serializers.ModelSerializer):
    marks = SubjectMarkInputSerializer(many=True)

    class Meta:
        model = StudentPercentileMarks
        fields = ['student_id', 'student_class', 'marks', 'updated_at']

    def create(self, validated_data):
        marks = validated_data.pop('marks')
        obj, _ = StudentPercentileMarks.objects.update_or_create(
            student_id=validated_data['student_id'],
            defaults={**validated_data, 'marks': marks}
        )
        return obj

    def update(self, instance, validated_data):
        instance.student_class = validated_data.get('student_class', instance.student_class)
        instance.marks = validated_data.get('marks', instance.marks)
        instance.save()
        return instance