import json
from django.shortcuts import get_object_or_404
from django.utils.timezone import now
from django.db import models
from django.db.models import Q
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.files.storage import default_storage

from textblob import TextBlob
from fuzzywuzzy import fuzz

from storage_backends import AzureMediaStorage
from django.core.files.base import ContentFile
from .models import (
    PersonalityTestSession, Student, Career, AdaptiveTestQuestion, AdaptiveTestSession, 
    AdaptiveTestResponse, AdaptiveTestChatMessage
)
from .permissions import IsSchoolStudent
from .test_serializers import (
    TestQuestionSerializer, TestCategorySerializer, TestSessionSerializer,
    TestResponseSerializer, TestChatMessageSerializer, SubmitAnswerSerializer,
    CategorySelectionSerializer, ChatMessageCreateSerializer, TestReportSerializer
)
from api.renderers import ResponseRenderer

class AdaptiveTestSessionView(APIView):
    """API view for creating and listing test sessions"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def post(self, request):
        """Create a new test session"""
        student = request.user.student_profile
        
        # Create a new session
        session = AdaptiveTestSession.objects.create(
            student=student,
            is_active=True
        )
        
        # Record initial chat greeting
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content='Welcome to the Adaptive Aptitude Test! Choose a category to begin.',
            message_type='greeting'
        )
        
        # Get available categories
        categories = self._get_available_categories()
        
        return Response({
            'session_id': session.session_id,
            'created_at': session.created_at,
            'message': 'Welcome to the Adaptive Aptitude Test! Choose a category to begin.',
            'available_categories': categories
        }, status=status.HTTP_201_CREATED)
    
    def get(self, request):
        """List user's test sessions"""
        student = request.user.student_profile
        sessions = AdaptiveTestSession.objects.filter(student=student)
        
        serializer = TestSessionSerializer(sessions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def _get_available_categories(self):
        """Get list of available test categories"""
        # Query unique categories from question database
        categories = AdaptiveTestQuestion.objects.values_list('category', flat=True).distinct()
        
        # Format for response
        category_data = []
        for category in categories:
            display_name = category.replace('_', ' ').title()
            category_data.append({
                'id': category,
                'name': display_name
            })
        
        return category_data

class AdaptiveTestSessionDetailView(APIView):
    """API view for retrieving session details"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get test session details"""
        student = request.user.student_profile
        
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get basic session info
        serializer = TestSessionSerializer(session)
        
        # Get additional stats
        response_data = serializer.data
        
        # Add count of questions answered
        response_data['questions_answered'] = AdaptiveTestResponse.objects.filter(
            session=session
        ).count()
        
        # Add count of correct answers
        response_data['correct_answers'] = AdaptiveTestResponse.objects.filter(
            session=session,
            is_correct=True
        ).count()
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    def post(self, request, session_id):
        """Manually complete a test session"""
        student = request.user.student_profile
        
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student,
                is_active=True
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive test session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Mark the session as complete
        session.is_active = False
        session.completed_at = now()
        session.save()
        
        # Add completion message to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=f"You've completed the test.",
            message_type='completion'
        )
        
        return Response({
            "message": "Test completed successfully",
            "report_url": f"/api/school/student/test/{session_id}/report/"
        }, status=status.HTTP_200_OK)

class TestCategoryView(APIView):
    """API view for selecting a test category"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get available categories"""
        student = request.user.student_profile
        
        # Verify session exists
        try:
            AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get available categories
        categories = AdaptiveTestQuestion.objects.values_list('category', flat=True).distinct()
        
        # Format for response
        category_data = []
        for category in categories:
            display_name = category.replace('_', ' ').title()
            category_data.append({
                'id': category,
                'name': display_name
            })
        
        serializer = TestCategorySerializer(category_data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request, session_id):
        """Select a category to begin testing"""
        student = request.user.student_profile
        
        # Validate request data
        serializer = CategorySelectionSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # Get the session by ID
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student,
                is_active=True
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive test session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get category from request
        category = serializer.validated_data['category']
        
        # Verify category exists
        if not AdaptiveTestQuestion.objects.filter(category=category).exists():
            return Response(
                {"error": f"Category '{category}' not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Update session with selected category
        session.current_category = category
        session.save()
        
        # Create chat message for category selection
        display_name = category.replace('_', ' ').title()
        message = f"You've selected {display_name}. Let's begin!"
        
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=message,
            message_type='category_selection'
        )
        
        return Response({
            'message': message,
            'next_question_url': f'/api/school/student/test/{session_id}/question/'
        }, status=status.HTTP_200_OK)

class TestQuestionView(APIView):
    """API view for getting test questions"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get the next question for this session"""
        student = request.user.student_profile
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student,
                is_active=True
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive test session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if category is selected
        if not session.current_category:
            return Response(
                {"error": "Please select a category before requesting questions"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get next question based on adaptive algorithm
        question = self._get_next_question(session)
        
        if not question:
            # No more questions, mark session as complete
            session.is_active = False
            session.completed_at = now()
            session.save()
            
            # Add completion message to chat
            AdaptiveTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=f"You've completed all questions in this category!",
                message_type='completion'
            )
            
            return Response({
                "message": "Test completed",
                "report_url": f"/api/school/student/test/{session_id}/report/"
            }, status=status.HTTP_200_OK)
        
        # Add question to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=question.question_text,
            message_type='question',
            metadata={
                'question_id': question.id,
                'options': question.options,
                'image': question.image
            }
        )
        
        # Format response
        serializer = TestQuestionSerializer(
            question, 
            context={'request': request}
        )
        
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def _get_next_question(self, session):
        """
        Implement adaptive question selection algorithm
        - For new sessions, start with easiest questions
        - For existing sessions, adjust difficulty based on performance
        """
        category = session.current_category
        
        # Log diagnostic information
        print(f"Getting next question for session {session.session_id}, category {category}")
        
        # Get questions already answered in this session
        answered_responses = AdaptiveTestResponse.objects.filter(session=session)
        answered_question_ids = list(answered_responses.values_list('question_id', flat=True))
        
        print(f"Found {len(answered_question_ids)} answered questions: {answered_question_ids}")
        
        # Get previous responses to calculate performance
        previous_responses = AdaptiveTestResponse.objects.filter(
            session=session,
            question__category=category
        )
        
        # Calculate current performance level
        if not previous_responses.exists():
            # First question - start with lowest difficulty
            target_difficulty = 1
            print(f"First question - using difficulty {target_difficulty}")
        else:
            # Calculate accuracy
            correct_count = previous_responses.filter(is_correct=True).count()
            total_count = previous_responses.count()
            accuracy = correct_count / total_count
            
            print(f"Previous responses: {total_count}, Correct: {correct_count}, Accuracy: {accuracy}")
            
            # Adjust difficulty based on accuracy
            if accuracy > 0.8:
                # Increase difficulty for high performers
                max_difficulty = previous_responses.aggregate(
                    max_difficulty=models.Max('question__difficulty')
                )['max_difficulty'] or 1
                target_difficulty = max_difficulty + 1
                print(f"High accuracy - increasing difficulty to {target_difficulty}")
            elif accuracy < 0.5:
                # Decrease difficulty for struggling students
                min_difficulty = previous_responses.aggregate(
                    min_difficulty=models.Min('question__difficulty')
                )['min_difficulty'] or 1
                target_difficulty = max(1, min_difficulty - 1)
                print(f"Low accuracy - decreasing difficulty to {target_difficulty}")
            else:
                # Maintain similar difficulty
                avg_difficulty = previous_responses.aggregate(
                    avg_difficulty=models.Avg('question__difficulty')
                )['avg_difficulty'] or 1
                target_difficulty = round(avg_difficulty)
                print(f"Medium accuracy - maintaining difficulty at {target_difficulty}")
        
        # Find next question - be very explicit about filtering out answered questions
        all_questions = AdaptiveTestQuestion.objects.filter(category=category)
        print(f"Total questions in category: {all_questions.count()}")
        
        if answered_question_ids:
            available_questions = all_questions.exclude(id__in=answered_question_ids)
        else:
            available_questions = all_questions
        
        print(f"Available unanswered questions: {available_questions.count()}")
        
        # If no more questions, return None
        if not available_questions.exists():
            print("No more available questions")
            return None
        
        # Get question closest to target difficulty
        closest_question = available_questions.filter(
            difficulty__gte=target_difficulty
        ).order_by('difficulty').first()
        
        # If no questions with higher difficulty, get the hardest available
        if not closest_question:
            closest_question = available_questions.order_by('-difficulty').first()
            print(f"No questions at target difficulty, using highest: {closest_question.id} (difficulty {closest_question.difficulty})")
        else:
            print(f"Selected question {closest_question.id} with difficulty {closest_question.difficulty}")
        
        return closest_question

class TestAnswerView(APIView):
    """API view for submitting answers"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def post(self, request, session_id):
        """Submit an answer for a question"""
        student = request.user.student_profile
        
        # Validate request data
        serializer = SubmitAnswerSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student,
                is_active=True
            )
            print(f"Found active session: {session.session_id}")
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive test session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get request data
        question_id = serializer.validated_data['question_id']
        answer = serializer.validated_data['answer']
        response_time = serializer.validated_data['response_time']
        
        print(f"Processing answer for question {question_id}: '{answer}'")
        
        # Get the question
        try:
            question = AdaptiveTestQuestion.objects.get(id=question_id)
            print(f"Found question: {question.question_text}")
        except AdaptiveTestQuestion.DoesNotExist:
            return Response(
                {"error": "Question not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if question has already been answered
        existing_response = AdaptiveTestResponse.objects.filter(
            session=session, 
            question=question
        ).first()
        
        if existing_response:
            print(f"Question already answered: {existing_response.id}")
            return Response(
                {"error": "Question has already been answered in this session",
                "previous_answer": existing_response.student_answer}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Process the answer
        is_correct, corrected_answer = self._process_answer(answer, question)
        print(f"Answer processed: correct={is_correct}, corrected={corrected_answer}")
        
        # Store the response
        try:
            test_response = AdaptiveTestResponse.objects.create(
                session=session,
                question=question,
                student_answer=answer,
                corrected_answer=corrected_answer,
                is_correct=is_correct,
                response_time=response_time
            )
            print(f"Response saved with ID: {test_response.id}")
            
            # Verify the response was saved
            saved_response = AdaptiveTestResponse.objects.filter(id=test_response.id).first()
            if saved_response:
                print(f"Verified response saved: {saved_response.id}")
            else:
                print("WARNING: Response appears not to have been saved!")
        except Exception as e:
            print(f"Error saving response: {str(e)}")
            return Response(
                {"error": f"Error saving response: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Add answer to chat history
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=answer,
            message_type='answer'
        )
        
        # Add explanation to chat history
        explanation = question.explanation or "Moving to next question."
        feedback = "Correct!" if is_correct else f"Not quite. The correct answer is {question.correct_answer}."
        
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=f"{feedback} {explanation}",
            message_type='explanation'
        )
        
        # Update session metrics
        self._update_session_metrics(session)
        
        # Format response
        response_data = {
            'is_correct': is_correct,
            'correct_answer': question.correct_answer,
            'explanation': explanation,
            'response_time': response_time,
            'next_question_url': f"/api/school/student/test/{session_id}/question/",
            'answer_saved': True,
            'response_id': test_response.id
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    def _process_answer(self, answer, question):
        """
        Implement answer processing logic:
        - Check if answer matches correct answer
        - Process typos, spelling corrections, etc.
        - Implement fuzzy matching
        """
        # Clean up the answer
        user_answer = str(answer).strip().lower()
        correct_answer = str(question.correct_answer).strip().lower()
        
        # Direct match
        if user_answer == correct_answer:
            return True, None
        
        # Option match (e.g., 'a', 'b', 'c', 'd')
        if user_answer in ['a', 'b', 'c', 'd', 'e'] and user_answer == correct_answer:
            return True, None
        
        # Handle multi-choice options
        if question.options:
            # Check if user entered option value instead of key
            for key, value in question.options.items():
                if user_answer == str(value).strip().lower():
                    return key.lower() == correct_answer.lower(), key
        
        # Try spell correction
        corrected = str(TextBlob(user_answer).correct())
        
        if corrected.lower() == correct_answer:
            return True, corrected
        
        # Try fuzzy matching
        if fuzz.ratio(user_answer, correct_answer) >= 85:
            return True, correct_answer
        
        # Not correct
        return False, correct_answer
    
    def _update_session_metrics(self, session):
        """Update session metrics based on answers so far"""
        responses = AdaptiveTestResponse.objects.filter(session=session)
        
        if responses.exists():
            # Calculate accuracy
            correct_count = responses.filter(is_correct=True).count()
            total_count = responses.count()
            accuracy = correct_count / total_count
            
            # Calculate average response time
            avg_time = responses.aggregate(avg_time=models.Avg('response_time'))['avg_time']
            
            # Calculate stats by category
            categories = {}
            for category in responses.values_list('question__category', flat=True).distinct():
                cat_responses = responses.filter(question__category=category)
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_accuracy = cat_correct / cat_responses.count()
                cat_avg_difficulty = cat_responses.aggregate(
                    avg=models.Avg('question__difficulty')
                )['avg']
                
                categories[category] = {
                    'accuracy': cat_accuracy,
                    'avg_difficulty': cat_avg_difficulty,
                    'questions_answered': cat_responses.count()
                }
            
            # Update session metrics
            session.metrics = {
                'accuracy': accuracy,
                'avg_response_time': avg_time,
                'total_questions': total_count,
                'correct_answers': correct_count,
                'categories': categories
            }
            session.save()

class TestChatView(APIView):
    """API view for chat interactions"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get chat history for a test session"""
        student = request.user.student_profile
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get chat messages
        messages = AdaptiveTestChatMessage.objects.filter(
            session=session
        ).order_by('timestamp')
        
        # Format messages
        serializer = TestChatMessageSerializer(
            messages, 
            many=True,
            context={'request': request}
        )
        
        return Response({
            'session_id': session.session_id,
            'is_active': session.is_active,
            'messages': serializer.data
        }, status=status.HTTP_200_OK)
    
    def post(self, request, session_id):
        """Add a chat message from the student"""
        student = request.user.student_profile
        
        # Validate request data
        serializer = ChatMessageCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student,
                is_active=True
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Invalid or inactive test session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get message content
        content = serializer.validated_data['message']
        
        # Add message to chat
        message = AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=content,
            message_type='message'
        )
        
        # Generate a simple response
        response_content = "I'm your adaptive test assistant. Let's continue with the questions."
        
        response_message = AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=response_content,
            message_type='message'
        )
        
        return Response({
            'message': {
                'id': message.id,
                'content': message.content,
                'timestamp': message.timestamp
            },
            'response': {
                'id': response_message.id,
                'content': response_message.content,
                'timestamp': response_message.timestamp
            }
        }, status=status.HTTP_201_CREATED)

class TestReportView(APIView):
    """API view for test reports"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get comprehensive test report for a session and store it in Azure Blob Storage"""
        student = request.user.student_profile
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get session responses
        responses = AdaptiveTestResponse.objects.filter(
            session=session
        ).select_related('question')
        
        if not responses.exists():
            return Response(
                {"error": "No test data available for this session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Generate the detailed report (existing functionality)
        detailed_report = self._generate_detailed_report(session, student, responses)
        
        # Generate the template-friendly report
        template_report = self._generate_template_report(session, student, responses)
        
        # Store both reports in Azure Storage
        detailed_storage = self._store_report(
            session_id=session.session_id,
            student_id=student.id,
            report_data=detailed_report,
            report_type="detailed"
        )
        
        template_storage = self._store_report(
            session_id=session.session_id,
            student_id=student.id,
            report_data=template_report,
            report_type="template"
        )
        
        # Return the response with both report formats and their URLs
        response_data = {
            "detailed_report": detailed_report,
            "template_report": template_report,
            "files": {
                "detailed_report": detailed_storage,
                "template_report": template_storage
            }
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    def _generate_detailed_report(self, session, student, responses):
        """Generate the detailed report (current implementation)"""
        # Calculate test statistics
        test_stats = {
            'total_questions': responses.count(),
            'correct_answers': responses.filter(is_correct=True).count(),
            'accuracy': responses.filter(is_correct=True).count() / responses.count(),
            'avg_response_time': responses.aggregate(avg=models.Avg('response_time'))['avg'],
            'categories': {}
        }
        
        # Calculate stats by category
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            cat_correct = cat_responses.filter(is_correct=True).count()
            
            test_stats['categories'][category] = {
                'questions': cat_responses.count(),
                'correct': cat_correct,
                'accuracy': cat_correct / cat_responses.count() if cat_responses.count() > 0 else 0,
                'avg_difficulty': cat_responses.aggregate(avg=models.Avg('question__difficulty'))['avg'],
                'avg_time': cat_responses.aggregate(avg=models.Avg('response_time'))['avg']
            }
        
        # Format response
        report = {
            'session_id': str(session.session_id),
            'student': {
                'id': student.id,
                'name': student.user.name,
                'email': student.user.email,
                'class': student.student_class,
                'section': student.section
            },
            'test_details': {
                'started_at': session.created_at.isoformat() if hasattr(session.created_at, 'isoformat') else str(session.created_at),
                'completed_at': session.completed_at.isoformat() if session.completed_at and hasattr(session.completed_at, 'isoformat') else str(session.completed_at) if session.completed_at else None,
                'duration_minutes': (session.completed_at - session.created_at).seconds / 60 if session.completed_at else None,
                'is_complete': session.completed_at is not None
            },
            'performance': test_stats,
            'detailed_responses': []
        }
        
        # Add detailed response data
        for response in responses:
            report['detailed_responses'].append({
                'question': response.question.question_text,
                'category': response.question.category,
                'difficulty': response.question.difficulty,
                'student_answer': response.student_answer,
                'correct_answer': response.question.correct_answer,
                'is_correct': response.is_correct,
                'response_time': response.response_time,
                'explanation': response.question.explanation
            })
        
        # Get career recommendations
        report['career_recommendations'] = self._get_career_recommendations(test_stats)
        
        return report
    
    def _generate_template_report(self, session, student, responses):
        """Generate a template-friendly report for PDF generation"""
        # Get the school
        school = student.school
        
        # Calculate standardized aptitude scores (out of 10)
        aptitude_scores = {}
        
        # Map test categories to standardized categories displayed in the PDF
        category_mapping = {
            'Numerical_Reasoning': 'Numerical Aptitude',
            'Verbal_Aptitude': 'Verbal Aptitude',
            'Logical_Reasoning': 'Logical Reasoning',
            'Abstract_Reasoning': 'Abstract Reasoning',
            'Spatial_Aptitude': 'Spatial Aptitude',
            'Mechanical_Aptitude': 'Mechanical Aptitude',
            'Clerical_Aptitude': 'Clerical Aptitude',
            'Attention_to_detail': 'Attention to Detail',
            'General_knowledge_and_awareness': 'General Knowledge and Awareness',
            'Technical_Aptitude': 'Technical Aptitude',
            'Situational_Judgement': 'Situational Judgment',
            'Memory_Retention_Test': 'Memory and Retention'
        }
        
        # Ensure all categories from PDF are included with default values
        for pdf_category in category_mapping.values():
            aptitude_scores[pdf_category] = 0
        
        # Calculate actual scores for categories with responses
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                # Calculate standardized score (0-10)
                score = round((cat_correct / cat_total) * 10) if cat_total else 0
                
                # Map to PDF category if exists, otherwise use formatted category name
                pdf_category = category_mapping.get(
                    category, 
                    category.replace('_', ' ').title()
                )
                
                aptitude_scores[pdf_category] = score
        
        # Format the template-friendly report
        template_report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school.name,
            'personality_test_result': {},  # Placeholder for future implementation
            'big_results': aptitude_scores,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat(),
            'is_complete': session.completed_at is not None
        }
        
        return template_report
    
    def _store_report(self, session_id, student_id, report_data, report_type="detailed"):
        """
        Store a test report in Azure Blob Storage
        
        Args:
            session_id: The session ID of the test
            student_id: The ID of the student
            report_data: The report data to store (dict)
            report_type: The type of report (detailed or template)
            
        Returns:
            dict: Storage information including file path and URL
        """
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"reports/student_{student_id}/{session_id}/{report_type}_report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }
    
    def _get_career_recommendations(self, test_stats):
        """Generate career recommendations based on test performance"""
        # You can integrate this with your existing careers model
        try:
            recommendations = []
            
            # Simple algorithm: match high performance in categories to careers
            for category, stats in test_stats['categories'].items():
                if stats['accuracy'] >= 0.7:  # If accuracy is high
                    # Map test categories to career fields
                    if category == 'Numerical_Reasoning':
                        careers = Career.objects.filter(
                            Q(name__icontains='engineer') | 
                            Q(name__icontains='finance') |
                            Q(name__icontains='banking')
                        )
                    elif category == 'Verbal_Aptitude':
                        careers = Career.objects.filter(
                            Q(name__icontains='writer') | 
                            Q(name__icontains='lawyer') |
                            Q(name__icontains='teacher')
                        )
                    elif category == 'Logical_Reasoning':
                        careers = Career.objects.filter(
                            Q(name__icontains='computer') | 
                            Q(name__icontains='law') |
                            Q(name__icontains='business')
                        )
                    elif category == 'Technical_Aptitude':
                        careers = Career.objects.filter(
                            Q(name__icontains='comp') | 
                            Q(name__icontains='tech') |
                            Q(name__icontains='engin')
                        )
                    else:
                        # Default to all careers
                        careers = Career.objects.all()[:3]
                    
                    # Add match scores
                    for career in careers:
                        recommendations.append({
                            'id': career.value,
                            'name': career.name,
                            'match_score': round(stats['accuracy'] * 100, 1),
                            'category': category.replace('_', ' ')
                        })
            
            # Return top 5 recommendations
            return sorted(recommendations, key=lambda x: x['match_score'], reverse=True)[:5]
            
        except Exception as e:
            print(f"Error generating career recommendations: {str(e)}")
            # If career integration fails, return empty list
            return []
        
class PDFReportTemplateView(APIView):
    """API view for PDF-formatted report template"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, session_id):
        """Get PDF-friendly report template for a session"""
        student = request.user.student_profile
        
        # Get the session
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get session responses
        responses = AdaptiveTestResponse.objects.filter(
            session=session
        ).select_related('question')
        
        if not responses.exists():
            return Response(
                {"error": "No test data available for this session"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Generate the PDF-friendly report
        pdf_report = self._generate_pdf_report(session, student, responses)
        
        # Store the report
        storage_info = self._store_report(
            session_id=session.session_id,
            student_id=student.id,
            report_data=pdf_report,
            report_type="pdf"
        )
        
        # Return the report with storage information
        response_data = {
            "pdf_report": pdf_report,
            "file": storage_info
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    def _generate_pdf_report(self, session, student, responses):
        """Generate a PDF-friendly report template"""
        # Get the school
        school = student.school
        
        # Calculate standardized aptitude scores (out of 10)
        aptitude_scores = {}
        
        # Map test categories to standardized categories displayed in the PDF
        category_mapping = {
            'Numerical_Reasoning': 'Numerical Aptitude',
            'Verbal_Aptitude': 'Verbal Aptitude',
            'Logical_Reasoning': 'Logical Reasoning',
            'Abstract_Reasoning': 'Abstract Reasoning',
            'Spatial_Aptitude': 'Spatial Aptitude',
            'Mechanical_Aptitude': 'Mechanical Aptitude',
            'Clerical_Aptitude': 'Clerical Aptitude',
            'Attention_to_detail': 'Attention to Detail',
            'General_knowledge_and_awareness': 'General Knowledge and Awareness',
            'Technical_Aptitude': 'Technical Aptitude',
            'Situational_Judgement': 'Situational Judgment',
            'Memory_Retention_Test': 'Memory and Retention'
        }
        
        # Ensure all categories from PDF are included with default values
        for pdf_category in category_mapping.values():
            aptitude_scores[pdf_category] = 0
        
        # Calculate actual scores for categories with responses
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                # Calculate standardized score (0-10)
                score = round((cat_correct / cat_total) * 10) if cat_total else 0
                
                # Map to PDF category if exists, otherwise use formatted category name
                pdf_category = category_mapping.get(
                    category, 
                    category.replace('_', ' ').title()
                )
                
                aptitude_scores[pdf_category] = score
        
        # Get career recommendations
        career_recommendations = self._get_career_recommendations(session, student, responses)
        
        # Generate placeholder consolidated report
        consolidated_report = self._generate_consolidated_report(aptitude_scores)
        
        # Generate placeholder suggestions
        suggestions = self._generate_suggestions(aptitude_scores, career_recommendations)
        
        # NEW CODE: Get the latest personality test results for this student
        personality_session = PersonalityTestSession.objects.filter(
            student=student,
            completed_at__isnull=False  # Only include completed sessions
        ).order_by('-completed_at').first()
        
        # Initialize personality_test_result field
        personality_test_result = {}
        
        # If a completed personality test exists, include the results
        if personality_session and personality_session.dimension_scores:
            # Format dimensions for PDF report
            personality_dimensions = []
            
            for name, values in personality_session.dimension_scores.items():
                if name == 'Extraversion_Introversion':
                    personality_dimensions.append({
                        'name': 'Extraversion_Introversion',
                        'left_label': 'Introvert',
                        'left_percentage': values['Introversion'],
                        'right_label': 'Extrovert',
                        'right_percentage': values['Extraversion'],
                        'left_description': '',
                        'right_description': ''
                    })
                elif name == 'Sensing_Intuition':
                    personality_dimensions.append({
                        'name': 'Sensing_Intuition',
                        'left_label': 'Sensing',
                        'left_percentage': values['Sensing'],
                        'right_label': 'iNtuitive',
                        'right_percentage': values['Intuition'],
                        'left_description': '(Observant)',
                        'right_description': '(Futuristic)'
                    })
                elif name == 'Thinking_Feeling':
                    personality_dimensions.append({
                        'name': 'Thinking_Feeling',
                        'left_label': 'Thinking',
                        'left_percentage': values['Thinking'],
                        'right_label': 'Feeling',
                        'right_percentage': values['Feeling'],
                        'left_description': '',
                        'right_description': ''
                    })
                elif name == 'Judging_Perceiving':
                    personality_dimensions.append({
                        'name': 'Judging_Perceiving',
                        'left_label': 'Judging',
                        'left_percentage': values['Judging'],
                        'right_label': 'Perceiving',
                        'right_percentage': values['Perceiving'],
                        'left_description': '(Organized)',
                        'right_description': '(Spontaneous)'
                    })
            
            # Add to personality test result
            personality_test_result = {
                'personality_type': personality_session.personality_type,
                'dimensions': personality_dimensions
            }
        
        # Format the PDF-friendly report with personality test results
        pdf_report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school.name,
            'personality_test_result': personality_test_result,  # Add personality test results
            'big_results': aptitude_scores,
            'career_suggestions': career_recommendations,
            'consolidated_report': consolidated_report,
            'suggestions': suggestions,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat(),
            'is_complete': session.completed_at is not None
        }
        
        return pdf_report
    
    def _get_career_recommendations(self, session, student, responses):
        """Generate career recommendations based on aptitude scores"""
        # Calculate accuracy by category
        category_accuracy = {}
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                category_accuracy[category] = cat_correct / cat_total if cat_total else 0
        
        # Try to get career recommendations from Career model
        try:
            # Initialize empty recommendation structure
            recommendations = {
                "categories": []
            }
            
            # Map high-performing categories to career fields
            career_categories = {}
            
            for category, accuracy in category_accuracy.items():
                if accuracy >= 0.7:  # If accuracy is high
                    if category == 'Numerical_Reasoning':
                        career_categories["Legal and Subsidiary"] = "High numerical aptitude"
                        career_categories["Banking and Finance"] = "Strong mathematical skills"
                    elif category == 'Verbal_Aptitude':
                        career_categories["Sales Profession"] = "Excellent communication skills"
                    elif category in ['Logical_Reasoning', 'Abstract_Reasoning']:
                        career_categories["Legal and Subsidiary"] = "Strong analytical thinking"
                    elif category == 'Technical_Aptitude':
                        career_categories["Engineering"] = "Technical problem-solving"
            
            # Convert dictionary to list format as shown in PDF
            for category, details in career_categories.items():
                recommendations["categories"].append({
                    "category": category,
                    "details": details
                })
            
            # If no categories matched, provide a default recommendation
            if not recommendations["categories"]:
                recommendations["categories"].append({
                    "category": "General Career Path",
                    "details": "Explore multiple options based on interests"
                })
            
            return recommendations
            
        except Exception as e:
            print(f"Error generating career recommendations: {str(e)}")
            # Return default structure if career integration fails
            return {
                "categories": [
                    {
                        "category": "General Career Path",
                        "details": "Explore options based on interests"
                    }
                ]
            }
    
    def _generate_consolidated_report(self, aptitude_scores):
        """Generate consolidated report with strengths and improvement areas"""
        strengths = []
        improvements = []
        
        # Identify top 3 strengths
        top_strengths = sorted(aptitude_scores.items(), key=lambda x: x[1], reverse=True)[:3]
        for category, score in top_strengths:
            if score >= 5:  # Only include as strength if score is decent
                strengths.append(category)
        
        # Identify bottom 3 areas for improvement
        bottom_scores = sorted(aptitude_scores.items(), key=lambda x: x[1])[:3]
        for category, score in bottom_scores:
            if score < 7:  # Only include as improvement area if there's room to improve
                improvements.append(category)
        
        # If we don't have enough strengths or improvements, add generic ones
        if len(strengths) < 3:
            generic_strengths = ["Negotiation skills", "Story telling", "Problem solving"]
            strengths.extend(generic_strengths[:3-len(strengths)])
        
        if len(improvements) < 3:
            generic_improvements = ["Organizing things", "Logical reasoning", "Leadership ability"]
            improvements.extend(generic_improvements[:3-len(improvements)])
        
        # Format as per the PDF template
        return {
            "strengths": strengths[:3],  # Limit to top 3
            "scope_of_improvement": improvements[:3]  # Limit to top 3
        }
    
    def _generate_suggestions(self, aptitude_scores, career_recommendations):
        """Generate activity suggestions based on aptitude and career path"""
        # Default suggestions that align with the PDF template
        default_suggestions = [
            "Sports",
            "Blood donation camp",
            "Health camps",
            "Monitoring in school"
        ]
        
        # In the future, this could be enhanced to provide more tailored suggestions
        # based on the aptitude scores and career recommendations
        
        return default_suggestions
    
    def _store_report(self, session_id, student_id, report_data, report_type="pdf"):
        """Store the PDF report in Azure Blob Storage"""
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"reports/student_{student_id}/{session_id}/{report_type}_report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }

class PDFReportByStudentView(APIView):
    """API view for getting the latest PDF report for a student"""
    permission_classes = [IsAuthenticated]  # Both admins and students can access
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, student_id):
        """Get the latest PDF report for a student"""
        # Handle different user types (admin or student)
        if hasattr(request.user, 'school_admin'):
            # School admin can access any student's report
            school = request.user.school_admin
            student = get_object_or_404(Student, id=student_id, school=school)
        elif hasattr(request.user, 'student_profile'):
            # Students can only access their own reports
            if int(student_id) != request.user.student_profile.id:
                return Response(
                    {"error": "You can only access your own reports"},
                    status=status.HTTP_403_FORBIDDEN
                )
            student = request.user.student_profile
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Find the latest test session for this student
        latest_session = AdaptiveTestSession.objects.filter(
            student=student
        ).order_by('-created_at').first()
        
        if not latest_session:
            return Response(
                {"error": "No test sessions found for this student"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if this session has any responses
        responses = AdaptiveTestResponse.objects.filter(
            session=latest_session
        ).select_related('question')
        
        if not responses.exists():
            return Response(
                {"error": "No test data available for this student's latest session"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Generate the PDF-friendly report
        pdf_report = self._generate_pdf_report(latest_session, student, responses)
        
        # Check if a report was already stored for this session
        # First try to get an existing report
        try:
            azure_storage = AzureMediaStorage()
            report_path_pattern = f"reports/student_{student.id}/{latest_session.session_id}/pdf_report_"
            
            # List files in the directory
            try:
                storage_files = [f for f in azure_storage.listdir(f"reports/student_{student.id}/{latest_session.session_id}/")[1] 
                               if f.startswith(report_path_pattern.split('/')[-1])]
                
                if storage_files:
                    # Sort by name (which includes timestamp) to get the latest
                    latest_file = sorted(storage_files, reverse=True)[0]
                    existing_report_path = f"reports/student_{student.id}/{latest_session.session_id}/{latest_file}"
                    
                    # Get the URL
                    existing_report_url = azure_storage.url(existing_report_path)
                    
                    storage_info = {
                        'file_path': existing_report_path,
                        'file_url': existing_report_url
                    }
                else:
                    # No existing report found, store a new one
                    storage_info = self._store_report(
                        session_id=latest_session.session_id,
                        student_id=student.id,
                        report_data=pdf_report,
                        report_type="pdf"
                    )
            except:
                # If listing files fails, just store a new report
                storage_info = self._store_report(
                    session_id=latest_session.session_id,
                    student_id=student.id,
                    report_data=pdf_report,
                    report_type="pdf"
                )
        except Exception as e:
            print(f"Error checking for existing reports: {str(e)}")
            # Fall back to storing a new report
            storage_info = self._store_report(
                session_id=latest_session.session_id,
                student_id=student.id,
                report_data=pdf_report,
                report_type="pdf"
            )
        
        # Return the report with storage information
        response_data = {
            "pdf_report": pdf_report,
            "file": storage_info,
            "session_id": str(latest_session.session_id)
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    # Reuse the same helper methods from PDFReportTemplateView
    def _generate_pdf_report(self, session, student, responses):
        """Generate a PDF-friendly report template"""
        # Get the school with proper error handling
        try:
            school = student.school
            school_name = school.name if school else "Unknown School"
        except (AttributeError, Exception) as e:
            print(f"Warning: Error accessing school for student {student.id}: {str(e)}")
            school_name = "Unknown School"
        
        # Calculate standardized aptitude scores (out of 10)
        aptitude_scores = {}
        
        # Map test categories to standardized categories displayed in the PDF
        category_mapping = {
            'Numerical_Reasoning': 'Numerical Aptitude',
            'Verbal_Aptitude': 'Verbal Aptitude',
            'Logical_Reasoning': 'Logical Reasoning',
            'Abstract_Reasoning': 'Abstract Reasoning',
            'Spatial_Aptitude': 'Spatial Aptitude',
            'Mechanical_Aptitude': 'Mechanical Aptitude',
            'Clerical_Aptitude': 'Clerical Aptitude',
            'Attention_to_detail': 'Attention to Detail',
            'General_knowledge_and_awareness': 'General Knowledge and Awareness',
            'Technical_Aptitude': 'Technical Aptitude',
            'Situational_Judgement': 'Situational Judgment',
            'Memory_Retention_Test': 'Memory and Retention'
        }
        
        # Ensure all categories from PDF are included with default values
        for pdf_category in category_mapping.values():
            aptitude_scores[pdf_category] = 0
        
        # Calculate actual scores for categories with responses
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                # Calculate standardized score (0-10)
                score = round((cat_correct / cat_total) * 10) if cat_total else 0
                
                # Map to PDF category if exists, otherwise use formatted category name
                pdf_category = category_mapping.get(
                    category, 
                    category.replace('_', ' ').title()
                )
                
                aptitude_scores[pdf_category] = score
        
        # Get career recommendations
        career_recommendations = self._get_career_recommendations(session, student, responses)
        
        # Generate placeholder consolidated report
        consolidated_report = self._generate_consolidated_report(aptitude_scores)
        
        # Generate placeholder suggestions
        suggestions = self._generate_suggestions(aptitude_scores, career_recommendations)
        
        # NEW CODE: Get the latest personality test results for this student
        personality_test_result = {}
        try:
            from .models import PersonalityTestSession  # Make sure this import exists
            
            personality_session = PersonalityTestSession.objects.filter(
                student=student,
                completed_at__isnull=False  # Only include completed sessions
            ).order_by('-completed_at').first()
            
            print(f"DEBUG: Found personality session: {personality_session}")
            if personality_session:
                print(f"DEBUG: Personality type: {personality_session.personality_type}")
                print(f"DEBUG: Dimension scores: {personality_session.dimension_scores}")
            
            # If a completed personality test exists, include the results
            if personality_session and personality_session.dimension_scores:
                # Format dimensions exactly as frontend expects (as an array)
                personality_traits = []
                
                for name, values in personality_session.dimension_scores.items():
                    if name == 'Extraversion_Introversion':
                        personality_traits.append({
                            'name': 'Extraversion_Introversion',
                            'left_label': 'Introvert',
                            'left_percentage': values['Introversion'],
                            'right_label': 'Extrovert',
                            'right_percentage': values['Extraversion'],
                            'left_description': '',
                            'right_description': ''
                        })
                    elif name == 'Sensing_Intuition':
                        personality_traits.append({
                            'name': 'Sensing_Intuition',
                            'left_label': 'Sensing',
                            'left_percentage': values['Sensing'],
                            'right_label': 'iNtuitive',
                            'right_percentage': values['Intuition'],
                            'left_description': '(Observant)',
                            'right_description': '(Futuristic)'
                        })
                    elif name == 'Thinking_Feeling':
                        personality_traits.append({
                            'name': 'Thinking_Feeling',
                            'left_label': 'Thinking',
                            'left_percentage': values['Thinking'],
                            'right_label': 'Feeling',
                            'right_percentage': values['Feeling'],
                            'left_description': '',
                            'right_description': ''
                        })
                    elif name == 'Judging_Perceiving':
                        personality_traits.append({
                            'name': 'Judging_Perceiving',
                            'left_label': 'Judging',
                            'left_percentage': values['Judging'],
                            'right_label': 'Perceiving',
                            'right_percentage': values['Perceiving'],
                            'left_description': '(Organized)',
                            'right_description': '(Spontaneous)'
                        })
                
                # Add to personality test result in the format frontend expects
                personality_test_result = {
                    'personality_type': personality_session.personality_type,
                    'traits': personality_traits  # This is the array format frontend expects
                }
                
                print(f"DEBUG: Final personality_test_result: {personality_test_result}")
            else:
                print("DEBUG: No personality session found or no dimension scores")
                
        except Exception as e:
            print(f"ERROR: Error getting personality test results: {str(e)}")
            import traceback
            traceback.print_exc()
            # Keep personality_test_result as empty dict
        
        # Format the PDF-friendly report with personality test results
        pdf_report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school_name,
            'personality_test_result': personality_test_result,  # This will now be populated
            'big_results': aptitude_scores,
            'career_suggestions': career_recommendations,
            'consolidated_report': consolidated_report,
            'suggestions': suggestions,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat(),
            'is_complete': session.completed_at is not None
        }
        
        return pdf_report
    
    def _get_career_recommendations(self, session, student, responses):
        """Generate career recommendations based on aptitude scores"""
        # Calculate accuracy by category
        category_accuracy = {}
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                category_accuracy[category] = cat_correct / cat_total if cat_total else 0
        
        # Try to get career recommendations from Career model
        try:
            # Initialize empty recommendation structure
            recommendations = {
                "categories": []
            }
            
            # Map high-performing categories to career fields
            career_categories = {}
            
            for category, accuracy in category_accuracy.items():
                if accuracy >= 0.7:  # If accuracy is high
                    if category == 'Numerical_Reasoning':
                        career_categories["Legal and Subsidiary"] = "High numerical aptitude"
                        career_categories["Banking and Finance"] = "Strong mathematical skills"
                    elif category == 'Verbal_Aptitude':
                        career_categories["Sales Profession"] = "Excellent communication skills"
                    elif category in ['Logical_Reasoning', 'Abstract_Reasoning']:
                        career_categories["Legal and Subsidiary"] = "Strong analytical thinking"
                    elif category == 'Technical_Aptitude':
                        career_categories["Engineering"] = "Technical problem-solving"
            
            # Convert dictionary to list format as shown in PDF
            for category, details in career_categories.items():
                recommendations["categories"].append({
                    "category": category,
                    "details": details
                })
            
            # If no categories matched, provide a default recommendation
            if not recommendations["categories"]:
                recommendations["categories"].append({
                    "category": "General Career Path",
                    "details": "Explore multiple options based on interests"
                })
            
            return recommendations
            
        except Exception as e:
            print(f"Error generating career recommendations: {str(e)}")
            # Return default structure if career integration fails
            return {
                "categories": [
                    {
                        "category": "General Career Path",
                        "details": "Explore options based on interests"
                    }
                ]
            }
    
    def _generate_consolidated_report(self, aptitude_scores):
        """Generate consolidated report with strengths and improvement areas"""
        strengths = []
        improvements = []
        
        # Identify top 3 strengths
        top_strengths = sorted(aptitude_scores.items(), key=lambda x: x[1], reverse=True)[:3]
        for category, score in top_strengths:
            if score >= 5:  # Only include as strength if score is decent
                strengths.append(category)
        
        # Identify bottom 3 areas for improvement
        bottom_scores = sorted(aptitude_scores.items(), key=lambda x: x[1])[:3]
        for category, score in bottom_scores:
            if score < 7:  # Only include as improvement area if there's room to improve
                improvements.append(category)
        
        # If we don't have enough strengths or improvements, add generic ones
        if len(strengths) < 3:
            generic_strengths = ["Negotiation skills", "Story telling", "Problem solving"]
            strengths.extend(generic_strengths[:3-len(strengths)])
        
        if len(improvements) < 3:
            generic_improvements = ["Organizing things", "Logical reasoning", "Leadership ability"]
            improvements.extend(generic_improvements[:3-len(improvements)])
        
        # Format as per the PDF template
        return {
            "strengths": strengths[:3],  # Limit to top 3
            "scope_of_improvement": improvements[:3]  # Limit to top 3
        }
    
    def _generate_suggestions(self, aptitude_scores, career_recommendations):
        """Generate activity suggestions based on aptitude and career path"""
        # Default suggestions that align with the PDF template
        default_suggestions = [
            "Sports",
            "Blood donation camp",
            "Health camps",
            "Monitoring in school"
        ]
        
        # In the future, this could be enhanced to provide more tailored suggestions
        # based on the aptitude scores and career recommendations
        
        return default_suggestions
    
    def _store_report(self, session_id, student_id, report_data, report_type="pdf"):
        """Store the PDF report in Azure Blob Storage"""
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"reports/student_{student_id}/{session_id}/{report_type}_report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }
        
class PDFReportView(APIView):
    """API view for getting PDF reports by student ID or current user"""
    permission_classes = [IsAuthenticated]  # Both admins and students can access
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, student_id=None):
        """
        Get PDF report for a student
        - If student_id is provided, get that student's report (admin only)
        - If no student_id, get the current user's report (for students)
        """
        # Determine which student to use
        if student_id is None:
            # No student_id provided, use current user's profile
            if hasattr(request.user, 'student_profile'):
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "When no student ID is provided, you must be logged in as a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            # Student ID provided - only admins can access other students' reports
            if hasattr(request.user, 'school_admin'):
                # School admin can access any student's report
                school = request.user.school_admin
                student = get_object_or_404(Student, id=student_id, school=school)
            elif hasattr(request.user, 'student_profile'):
                # Students can only access their own reports
                if int(student_id) != request.user.student_profile.id:
                    return Response(
                        {"error": "You can only access your own reports"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "User is neither a school admin nor a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        
        # Find the latest test session for this student
        latest_session = AdaptiveTestSession.objects.filter(
            student=student
        ).order_by('-created_at').first()
        
        if not latest_session:
            return Response(
                {"error": "No test sessions found for this student"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if this session has any responses
        responses = AdaptiveTestResponse.objects.filter(
            session=latest_session
        ).select_related('question')
        
        if not responses.exists():
            return Response(
                {"error": "No test data available for this student's latest session"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Generate the PDF-friendly report
        pdf_report = self._generate_pdf_report(latest_session, student, responses)
        
        # Check if a report was already stored for this session
        # First try to get an existing report
        try:
            azure_storage = AzureMediaStorage()
            report_path_pattern = f"reports/student_{student.id}/{latest_session.session_id}/pdf_report_"
            
            # List files in the directory
            try:
                storage_files = [f for f in azure_storage.listdir(f"reports/student_{student.id}/{latest_session.session_id}/")[1] 
                               if f.startswith(report_path_pattern.split('/')[-1])]
                
                if storage_files:
                    # Sort by name (which includes timestamp) to get the latest
                    latest_file = sorted(storage_files, reverse=True)[0]
                    existing_report_path = f"reports/student_{student.id}/{latest_session.session_id}/{latest_file}"
                    
                    # Get the URL
                    existing_report_url = azure_storage.url(existing_report_path)
                    
                    storage_info = {
                        'file_path': existing_report_path,
                        'file_url': existing_report_url
                    }
                else:
                    # No existing report found, store a new one
                    storage_info = self._store_report(
                        session_id=latest_session.session_id,
                        student_id=student.id,
                        report_data=pdf_report,
                        report_type="pdf"
                    )
            except:
                # If listing files fails, just store a new report
                storage_info = self._store_report(
                    session_id=latest_session.session_id,
                    student_id=student.id,
                    report_data=pdf_report,
                    report_type="pdf"
                )
        except Exception as e:
            print(f"Error checking for existing reports: {str(e)}")
            # Fall back to storing a new report
            storage_info = self._store_report(
                session_id=latest_session.session_id,
                student_id=student.id,
                report_data=pdf_report,
                report_type="pdf"
            )
        
        # Return the report with storage information
        response_data = {
            "pdf_report": pdf_report,
            "file": storage_info,
            "session_id": str(latest_session.session_id),
            "student_id": student.id
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    def _generate_pdf_report(self, session, student, responses):
        """Generate a PDF-friendly report template"""
        # print(f"🔍🔍🔍 PDFReportView._generate_pdf_report() called!")
        # print(f"🔍 Student: {student.user.name} (ID: {student.id})")
        
        # Get the school
        school = student.school
        
        # Calculate standardized aptitude scores (out of 10)
        aptitude_scores = {}
        
        # Map test categories to standardized categories displayed in the PDF
        category_mapping = {
            'Numerical_Reasoning': 'Numerical Aptitude',
            'Verbal_Aptitude': 'Verbal Aptitude',
            'Logical_Reasoning': 'Logical Reasoning',
            'Abstract_Reasoning': 'Abstract Reasoning',
            'Spatial_Aptitude': 'Spatial Aptitude',
            'Mechanical_Aptitude': 'Mechanical Aptitude',
            'Clerical_Aptitude': 'Clerical Aptitude',
            'Attention_to_detail': 'Attention to Detail',
            'General_knowledge_and_awareness': 'General Knowledge and Awareness',
            'Technical_Aptitude': 'Technical Aptitude',
            'Situational_Judgement': 'Situational Judgment',
            'Memory_Retention_Test': 'Memory and Retention'
        }
        
        # Ensure all categories from PDF are included with default values
        for pdf_category in category_mapping.values():
            aptitude_scores[pdf_category] = 0
        
        # Calculate actual scores for categories with responses
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                # Calculate standardized score (0-10)
                score = round((cat_correct / cat_total) * 10) if cat_total else 0
                
                # Map to PDF category if exists, otherwise use formatted category name
                pdf_category = category_mapping.get(
                    category, 
                    category.replace('_', ' ').title()
                )
                
                aptitude_scores[pdf_category] = score
        
        # Get career recommendations
        career_recommendations = self._get_career_recommendations(session, student, responses)
        
        # Generate placeholder consolidated report
        consolidated_report = self._generate_consolidated_report(aptitude_scores)
        
        # Generate placeholder suggestions
        suggestions = self._generate_suggestions(aptitude_scores, career_recommendations)
        
        # === PERSONALITY TEST INTEGRATION ===
        # print(f"🔍 Looking for personality test data for student {student.id}")
        personality_test_result = []
        
        try:
            from .models import PersonalityTestSession
            print(f"🔍 Successfully imported PersonalityTestSession")
            
            # Get the latest completed personality test
            personality_session = PersonalityTestSession.objects.filter(
                student=student,
                completed_at__isnull=False,
                personality_type__isnull=False
            ).order_by('-completed_at').first()
            
            # print(f"🔍 Found personality session: {personality_session}")
            
            if personality_session and personality_session.dimension_scores:
                # print(f"🔍 Processing personality data: {personality_session.dimension_scores}")
                
                # Format dimensions for frontend
                for name, values in personality_session.dimension_scores.items():
                    trait_data = {'name': name}
                    
                    if name == 'Extraversion_Introversion':
                        trait_data.update({
                            'left_label': 'Introvert',
                            'left_percentage': values['Introversion'],
                            'right_label': 'Extrovert',
                            'right_percentage': values['Extraversion'],
                            'left_description': '',
                            'right_description': ''
                        })
                    elif name == 'Sensing_Intuition':
                        trait_data.update({
                            'left_label': 'Sensing',
                            'left_percentage': values['Sensing'],
                            'right_label': 'iNtuitive',
                            'right_percentage': values['Intuition'],
                            'left_description': '(Observant)',
                            'right_description': '(Futuristic)'
                        })
                    elif name == 'Thinking_Feeling':
                        trait_data.update({
                            'left_label': 'Thinking',
                            'left_percentage': values['Thinking'],
                            'right_label': 'Feeling',
                            'right_percentage': values['Feeling'],
                            'left_description': '',
                            'right_description': ''
                        })
                    elif name == 'Judging_Perceiving':
                        trait_data.update({
                            'left_label': 'Judging',
                            'left_percentage': values['Judging'],
                            'right_label': 'Perceiving',
                            'right_percentage': values['Perceiving'],
                            'left_description': '(Organized)',
                            'right_description': '(Spontaneous)'
                        })
                    
                    personality_test_result.append(trait_data)
                
                # print(f"🔍 Final personality_test_result: {personality_test_result}")
            else:
                # print(f"🔍 No valid personality session found")
                pass
                
        except Exception as e:
            print(f"🔍 Error getting personality data: {e}")
            import traceback
            traceback.print_exc()
        
        # Format the PDF-friendly report
        pdf_report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school.name,
            'personality_test_result': personality_test_result,  # ← This should now be populated!
            'big_results': aptitude_scores,
            'career_suggestions': career_recommendations,
            'consolidated_report': consolidated_report,
            'suggestions': suggestions,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat(),
            'is_complete': session.completed_at is not None
        }
        
        # print(f"🔍 FINAL personality_test_result in PDF report: {pdf_report['personality_test_result']}")
        
        return pdf_report
    
    def _get_career_recommendations(self, session, student, responses):
        """Generate career recommendations based on aptitude scores"""
        # Calculate accuracy by category
        category_accuracy = {}
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            if cat_responses.exists():
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_total = cat_responses.count()
                category_accuracy[category] = cat_correct / cat_total if cat_total else 0
        
        # Try to get career recommendations from Career model
        try:
            # Initialize empty recommendation structure
            recommendations = {
                "categories": []
            }
            
            # Map high-performing categories to career fields
            career_categories = {}
            
            for category, accuracy in category_accuracy.items():
                if accuracy >= 0.7:  # If accuracy is high
                    if category == 'Numerical_Reasoning':
                        career_categories["Legal and Subsidiary"] = "High numerical aptitude"
                        career_categories["Banking and Finance"] = "Strong mathematical skills"
                    elif category == 'Verbal_Aptitude':
                        career_categories["Sales Profession"] = "Excellent communication skills"
                    elif category in ['Logical_Reasoning', 'Abstract_Reasoning']:
                        career_categories["Legal and Subsidiary"] = "Strong analytical thinking"
                    elif category == 'Technical_Aptitude':
                        career_categories["Engineering"] = "Technical problem-solving"
            
            # Convert dictionary to list format as shown in PDF
            for category, details in career_categories.items():
                recommendations["categories"].append({
                    "category": category,
                    "details": details
                })
            
            # If no categories matched, provide a default recommendation
            if not recommendations["categories"]:
                recommendations["categories"].append({
                    "category": "General Career Path",
                    "details": "Explore multiple options based on interests"
                })
            
            return recommendations
            
        except Exception as e:
            print(f"Error generating career recommendations: {str(e)}")
            # Return default structure if career integration fails
            return {
                "categories": [
                    {
                        "category": "General Career Path",
                        "details": "Explore options based on interests"
                    }
                ]
            }
    
    def _generate_consolidated_report(self, aptitude_scores):
        """Generate consolidated report with strengths and improvement areas"""
        strengths = []
        improvements = []
        
        # Identify top 3 strengths
        top_strengths = sorted(aptitude_scores.items(), key=lambda x: x[1], reverse=True)[:3]
        for category, score in top_strengths:
            if score >= 5:  # Only include as strength if score is decent
                strengths.append(category)
        
        # Identify bottom 3 areas for improvement
        bottom_scores = sorted(aptitude_scores.items(), key=lambda x: x[1])[:3]
        for category, score in bottom_scores:
            if score < 7:  # Only include as improvement area if there's room to improve
                improvements.append(category)
        
        # If we don't have enough strengths or improvements, add generic ones
        if len(strengths) < 3:
            generic_strengths = ["Negotiation skills", "Story telling", "Problem solving"]
            strengths.extend(generic_strengths[:3-len(strengths)])
        
        if len(improvements) < 3:
            generic_improvements = ["Organizing things", "Logical reasoning", "Leadership ability"]
            improvements.extend(generic_improvements[:3-len(improvements)])
        
        # Format as per the PDF template
        return {
            "strengths": strengths[:3],  # Limit to top 3
            "scope_of_improvement": improvements[:3]  # Limit to top 3
        }
    
    def _generate_suggestions(self, aptitude_scores, career_recommendations):
        """Generate activity suggestions based on aptitude and career path"""
        # Default suggestions that align with the PDF template
        default_suggestions = [
            "Sports",
            "Blood donation camp",
            "Health camps",
            "Monitoring in school"
        ]
        
        # In the future, this could be enhanced to provide more tailored suggestions
        # based on the aptitude scores and career recommendations
        
        return default_suggestions
    
    def _store_report(self, session_id, student_id, report_data, report_type="pdf"):
        """Store the PDF report in Azure Blob Storage"""
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"reports/student_{student_id}/{session_id}/{report_type}_report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }