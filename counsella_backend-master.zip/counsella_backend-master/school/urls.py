from django.urls import path
from . import views
from . import test_views  # Import the new test views separately
from .chat_api_view import ChatAPIView
from . import personality_views


urlpatterns = [
    path('', views.SchoolListView.as_view(), name='list_schools'),
    path('<uuid:uid>/', views.SchoolListView.as_view(), name='school_details'),
    path('new/', views.SchoolCreateView.as_view(), name='new_school'),

    path('<uuid:uid>/activate/', views.SchoolActivationView.as_view(), name='school_activation'),
    path('<uuid:uid>/update/', views.SchoolUpdateView.as_view(), name='update_school_details'),
    path('<uuid:uid>/delete/', views.SchoolDeleteView.as_view(), name='delete_school'),

    path('boards/', views.SchoolBoardListCreateView.as_view(), name='schoolboard_list_create'),
    path('boards/active/', views.ActiveSchoolBoardListView.as_view(), name='schoolboards_active'),
    path('boards/<int:pk>/activate/', views.SchoolBoardActivationView.as_view(), name='schoolboard_activate'),
    path('boards/<int:pk>/', views.SchoolBoardDetailsView.as_view(), name='schoolboard_details'),

    path('withadmin/new/', views.SchoolWithAdminCreateView.as_view(), name='new_school_with_admin'),
    path('students/register/', views.StudentRegistrationView.as_view(), name='student_register'),

    path('admin/login/', views.SchoolAdminLoginView.as_view(), name='school_admin_login'),
    path('student/login/', views.SchoolStudentLoginView.as_view(), name='school_student_login'),

    path('student/profile/', views.StudentProfileAPIView.as_view(), name='student_profile'),

    path('results/', views.SchoolResultAPIView.as_view(), name='school_results'),

    path('process-results/', views.ProcessStudentResultsView.as_view(), name='process-results'),
    path('results/display/', views.ResultsDisplayView.as_view(), name='results-display'),
    path('finalize-results/', views.FinalizeResultsView.as_view(), name='finalize-results'),


    path('results/list/', views.StudentResultsListView.as_view(), name='results-list'),
    path('results/percentile/', views.StudentPercentileView.as_view(), name='student-percentile'),
    path('results/grades/', views.StudentGradeView.as_view(), name='student-grades'),
    path('results/statistics/', views.StudentStatisticsView.as_view(), name='subject-statistics'),
    path('results/predictions/', views.BoardResultPredictionDisplayView.as_view(), name='board-predictions'),
    path('subjects/', views.GetSubjectsView.as_view(), name='get-subjects'),

    path('students/', views.SchoolStudentListView.as_view(), name='school-student-list'),
    path('students/<int:pk>/', views.StudentProfileDetailView.as_view(), name='student-profile-detail'),

    path('students/grades/average/', views.StudentAverageGradesView.as_view(), name='student-average-grades'),
    path('students/percentiles/average/', views.StudentAveragePercentilesView.as_view(), name='student-average-percentiles'),
    # Add to urls.py
    path('students/debug/<int:student_id>/', views.SchoolStudentListView.as_view(), name='student-debug-by-id'),
    path('careers/', views.CareerListView.as_view(), name='career-list'),
    path('careers/statistics/', views.CareerStatisticsView.as_view(), name='career-statistics'),
    path('student/avatar/', views.StudentAvatarUpdateView.as_view(), name='student-avatar-update'),

    # Adaptive test
    path('student/test/', test_views.AdaptiveTestSessionView.as_view(), name='test-sessions'),
    path('student/test/<uuid:session_id>/', test_views.AdaptiveTestSessionDetailView.as_view(), name='test-session-detail'),
    path('student/test/<uuid:session_id>/categories/', test_views.TestCategoryView.as_view(), name='test-categories'),
    path('student/test/<uuid:session_id>/question/', test_views.TestQuestionView.as_view(), name='test-question'),
    path('student/test/<uuid:session_id>/answer/', test_views.TestAnswerView.as_view(), name='test-answer'),
    path('student/test/<uuid:session_id>/chat/', test_views.TestChatView.as_view(), name='test-chat'),
    path('student/test/<uuid:session_id>/report/', test_views.TestReportView.as_view(), name='test-report'),
    path('student/test/<uuid:session_id>/pdf-report/', test_views.PDFReportTemplateView.as_view(), name='pdf-report'),
    # path('student/pdf-report/<int:student_id>/', test_views.PDFReportByStudentView.as_view(), name='student-pdf-report'),
    path('student/pdf-report/', test_views.PDFReportView.as_view(), name='my-pdf-report'),  # For students (current user)
    path('student/pdf-report/<int:student_id>/', test_views.PDFReportView.as_view(), name='student-pdf-report'),  # For admins (specific student)



    # Board results prediction
    path('predict-board-results/', views.BoardResultPredictionView.as_view(), name='predict-board-results'),

    # Personality test
    path('student/personality-test/', personality_views.PersonalityTestView.as_view(), name='personality-test'),
    path('student/personality-test/report/', personality_views.PersonalityTestReportView.as_view(), name='personality-test-report'),
    path('student/personality-test/student-report/', personality_views.StudentPersonalityReportView.as_view(), name='student-personality-report'),

    path('chat/', ChatAPIView.as_view(), name='chat-api'),
    path('chat/report/', ChatAPIView.as_view(), name='chat-report'),

    # Test Results URLs with File Downloads
    path('test-results/upload/', views.TestResultsUploadView.as_view(), name='test-results-upload'),
    path('test-results/list/', views.TestResultsListView.as_view(), name='test-results-list'),
    path('test-results/summary/<int:student_id>/', views.TestResultsSummaryView.as_view(), name='test-results-summary'),
    path('test-results/batch/<int:batch_id>/', views.TestResultsBatchDetailView.as_view(), name='test-results-batch-detail'),
    path('test-results/storage-stats/', views.TestResultsStorageStatsView.as_view(), name='test-results-storage-stats'),

    # Download endpoints - Multiple options
    path('test-results/download/<int:student_id>/<str:file_type>/', views.TestResultsDownloadView.as_view(), name='test-results-download'),
    path('test-results/direct-download/<int:student_id>/<str:file_type>/', views.TestResultsDirectDownloadView.as_view(), name='test-results-direct-download'),
    path('test-results/redirect-download/<int:student_id>/<str:file_type>/', views.TestResultsRedirectDownloadView.as_view(), name='test-results-redirect-download'),

    # File info endpoint
    path('test-results/file-info/<int:student_id>/<str:file_type>/', views.TestResultsFileInfoView.as_view(), name='test-results-file-info'),

    # Test endpoint
    path('test-azure-storage/', views.TestAzureStorageView.as_view(), name='test-azure-storage'),

    # Career Counseling
    path('talk-to-career-expert/', views.TalkToCareerExpertView.as_view(), name='talk-to-career-expert'),
    # new api
    # path('feedback_questions/', views.FeedbackQuestionsView.as_view(), name='feedback_questions'),
    path('feedback_questions/<str:fid>/', views.FeedbackQuestionsView.as_view(), name='feedback_questions'),
    path('submit_feedback', views.SubmitFeedbackView.as_view(), name='submit_feedback'),
    path(
        'feedback/submission/<str:user_id>/<str:fid>/',
        views.FeedbackSubmissionRetrieveView.as_view(),
        name='feedback_submission_detail'
    ),
    # List all traits
    path('leadership-traits/', views.LeadershipTraitListView.as_view(), name='leadership-traits-list'),
    
    # Get trait by name
    path('leadership-traits/<str:leadership_trait_name>/', views.LeadershipTraitDetailView.as_view(), name='leadership-trait-detail'),

    #exam mark 
    path('percentile/submit_marks/', views.StudentPercentileMarksSubmitView.as_view()),
    path('percentile/get_marks/<str:student_id>/', views.StudentPercentileMarksRetrieveView.as_view()),
]

