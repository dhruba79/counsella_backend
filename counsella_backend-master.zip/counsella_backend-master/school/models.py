import uuid
import os
from django.utils.timezone import now
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from django.db import models

User = get_user_model()



class SchoolBoard(models.Model):
    name = models.CharField(max_length=100, unique=True)
    is_active = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class School(models.Model):
    uid = models.UUIDField(default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=2000)
    school_board = models.ForeignKey(SchoolBoard, on_delete=models.CASCADE, blank=True, null=True)
    registration_no = models.CharField(max_length=100, blank=True, null=True)
    contact_name = models.CharField(max_length=100, blank=True, null=True)
    contact_no = models.CharField(max_length=100, unique=True)
    contact_email = models.EmailField(max_length=100, unique=True)
    is_active = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_email_verified = models.BooleanField(default=False)
    is_mobile_verified = models.BooleanField(default=False)
    admin = models.OneToOneField(User, on_delete=models.CASCADE, related_name='school_admin', null=True, blank=True)

    def __str__(self):
        return self.name


def student_avatar_upload_path(instance, filename):
    """Generate file path for student avatar upload"""
    # Clean filename to remove spaces and special characters
    import os
    from django.utils.text import slugify
    
    base_name, ext = os.path.splitext(filename)
    safe_name = f"{slugify(base_name)}{ext}"
    
    return f"avatars/students/{instance.user.id}/{safe_name}"


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    school = models.ForeignKey('School', on_delete=models.CASCADE, related_name='students')
    student_class = models.IntegerField(blank=True, null=True)  # Example: "10-A"
    section = models.CharField(max_length=10, blank=True, null=True)  # Example: "10-A"
    roll_number = models.IntegerField(blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    registration_no = models.CharField(max_length=100, unique=True, blank=True, null=True)
    avatar = models.ImageField(upload_to=student_avatar_upload_path, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    alternate_contact_number = models.CharField(max_length=15, blank=True, null=True)
    address = models.CharField(max_length=2000, blank=True, null=True) 

    def __str__(self):
        return f"{self.user.name} - {self.school.name}"



def result_file_upload_path(instance, filename):
    """Generate file path for uploading school result files."""
    return f"school_results/{instance.school.id}/{instance.year}/{filename}"

def get_current_year():
    return now().year

class SchoolStudentResults(models.Model):
    school = models.ForeignKey('School', on_delete=models.CASCADE, related_name='results')
    year = models.PositiveIntegerField(default=get_current_year)
    pre_board_1_result = models.FileField(upload_to=result_file_upload_path, blank=False, null=False)
    pre_board_2_result = models.FileField(upload_to=result_file_upload_path, blank=False, null=False)
    half_yearly_result = models.FileField(upload_to=result_file_upload_path, blank=True, null=True)
    board_result = models.FileField(upload_to=result_file_upload_path, blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add the processing mode flag, defaults to False (validation enabled)
        self._processing_mode = False

    def clean(self):
        current_year = get_current_year()
        if self.year > current_year:
            raise ValidationError('Year cannot be greater than current year.')
        
        # Skip validation if we're in processing mode
        if getattr(self, '_processing_mode', False):
            return
            
        # Only require board_result and half_yearly for past years in normal mode
        if self.year < current_year:
            if not self.half_yearly_result:
                raise ValidationError('Half Yearly result is required for previous years.')
            if not self.board_result:
                raise ValidationError('Board result is required for previous years.')
    
    def save(self, *args, **kwargs):
        validate = kwargs.pop('validate', True)
        if validate and not self._processing_mode:
            self.clean()
        super().save(*args, **kwargs)
            
    class Meta:
        unique_together = ('school', 'year')
        ordering = ['-year']

    def __str__(self):
        return f"{self.school.name} - {self.year} Result"

class Career(models.Model):
    """Career options like Actors, Administrative, etc."""
    name = models.CharField(max_length=100)
    value = models.CharField(max_length=100, unique=True)
    
    def __str__(self):
        return self.name

class CareerStatistic(models.Model):
    """Pre-calculated statistics for each career and trait category"""
    career = models.ForeignKey(Career, on_delete=models.CASCADE, related_name='statistics')
    category = models.CharField(max_length=100)  # e.g., 'Career Choice', 'Time for Career Choice'
    labels = models.JSONField()  # e.g., ['Passion', 'Money', 'Nothing']
    values = models.JSONField()  # e.g., [44.4, 44.4, 11.1]
    
    class Meta:
        unique_together = ('career', 'category')
    
    def __str__(self):
        return f"{self.career.name} - {self.category}"

class CareerInfo(models.Model):
    """Additional career information like qualities, subjects, hobbies"""
    career = models.OneToOneField(Career, on_delete=models.CASCADE, related_name='info')
    
    # Original fields
    unique_qualities = models.JSONField(default=list)
    favorite_subjects = models.JSONField(default=list)
    hobbies = models.JSONField(default=list)
    
    # Additional fields for CSV data
    demanded_qualities = models.JSONField(default=list)
    suggested_books = models.JSONField(default=list)
    suggested_authors = models.JSONField(default=list)
    analytical_skills = models.JSONField(default=list)
    communication_skills = models.JSONField(default=list)
    nature_of_service = models.JSONField(default=list)
    sports_activities = models.JSONField(default=list)
    public_events = models.JSONField(default=list)
    secondary_domains = models.JSONField(default=list)
    
    def __str__(self):
        return f"Info for {self.career.name}"
    
class AdaptiveTestQuestion(models.Model):
    """Model to store questions from all test categories"""
    category = models.CharField(max_length=100)  # e.g., Abstract_Reasoning
    question_text = models.TextField()
    difficulty = models.IntegerField()
    options = models.JSONField()  # Store answer options
    correct_answer = models.CharField(max_length=100)
    explanation = models.TextField(blank=True, null=True)
    image = models.CharField(max_length=255, blank=True, null=True)
    
    def __str__(self):
        return f"{self.category} (Difficulty {self.difficulty})"

class AdaptiveTestSession(models.Model):
    """Model to track active test sessions"""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='test_sessions')
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    current_category = models.CharField(max_length=100, blank=True, null=True)
    session_id = models.UUIDField(default=uuid.uuid4, editable=False)
    metrics = models.JSONField(default=dict)  # Store session metrics (accuracy, timing, etc.)
    
    def __str__(self):
        return f"Session {self.session_id} - {self.student.user.name}"
    
    class Meta:
        ordering = ['-created_at']
    
class AdaptiveTestResponse(models.Model):
    """Model to record student responses to questions"""
    session = models.ForeignKey(AdaptiveTestSession, on_delete=models.CASCADE, related_name='responses')
    question = models.ForeignKey(AdaptiveTestQuestion, on_delete=models.CASCADE)
    student_answer = models.CharField(max_length=255)
    corrected_answer = models.CharField(max_length=255, blank=True, null=True)
    is_correct = models.BooleanField()
    response_time = models.FloatField()  # In seconds
    answered_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['answered_at']
    
    def __str__(self):
        return f"Response to question {self.question.id} in session {self.session.session_id}"

class AdaptiveTestChatMessage(models.Model):
    """Model to store chat interactions during the test"""
    session = models.ForeignKey(AdaptiveTestSession, on_delete=models.CASCADE, related_name='chat_messages')
    sender = models.CharField(max_length=10)  # 'system' or 'student'
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    message_type = models.CharField(max_length=20, default='message')  # 'question', 'answer', 'explanation', etc.
    metadata = models.JSONField(blank=True, null=True)  # For storing additional data like question options
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"{self.sender} message in session {self.session.session_id}"

class PersonalityTestQuestion(models.Model):
    """Model for personality test questions"""
    DIMENSION_CHOICES = [
        ('E_I', 'Extraversion vs. Introversion'),
        ('S_N', 'Sensing vs. Intuition'),
        ('T_F', 'Thinking vs. Feeling'),
        ('J_P', 'Judging vs. Perceiving')
    ]
    
    dimension = models.CharField(max_length=10, choices=DIMENSION_CHOICES)
    question_number = models.IntegerField()  # Within the dimension
    option_a_text = models.TextField()  # Maps to first letter in dimension (E, S, T, J)
    option_b_text = models.TextField()  # Maps to second letter in dimension (I, N, F, P)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.dimension} - Q{self.question_number}"
    
    @property
    def options(self):
        return {
            'A': self.option_a_text,
            'B': self.option_b_text
        }
    
    @property
    def dimension_display(self):
        return dict(self.DIMENSION_CHOICES).get(self.dimension, self.dimension)

class PersonalityTestSession(models.Model):
    """Model for personality test sessions"""
    session_id = models.UUIDField(primary_key=False, default=uuid.uuid4, editable=False)
    student = models.ForeignKey('Student', on_delete=models.CASCADE, related_name='personality_test_sessions')
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    personality_type = models.CharField(max_length=10, blank=True, null=True)
    dimension_scores = models.JSONField(default=dict, blank=True, null=True)
    
    def __str__(self):
        return f"Session {self.session_id} - {self.student.user.name}"
    
    @property
    def is_complete(self):
        return self.completed_at is not None
    
    @property
    def current_question_number(self):
        """Get the current question number based on answered questions"""
        answered = self.responses.count()
        return answered + 1
    
    def get_next_question(self):
        """Get the next unanswered question for this session"""
        # Get answered question IDs
        answered_ids = self.responses.values_list('question_id', flat=True)
        
        # Find the next unanswered question
        next_question = PersonalityTestQuestion.objects.exclude(
            id__in=answered_ids
        ).order_by('dimension', 'question_number').first()
        
        return next_question
    
    def calculate_result(self):
        """Calculate personality type and dimension scores"""
        responses = self.responses.all().select_related('question')
        
        # Initialize counters for each dimension
        e_count = 0
        i_count = 0
        s_count = 0
        n_count = 0
        t_count = 0
        f_count = 0
        j_count = 0
        p_count = 0
        
        # Count responses for each dimension
        for response in responses:
            dimension = response.question.dimension
            answer = response.selected_option
            
            # Map A/B answers to MBTI dimensions
            if dimension == 'E_I':
                if answer == 'A':
                    e_count += 1
                else:
                    i_count += 1
            elif dimension == 'S_N':
                if answer == 'A':
                    s_count += 1
                else:
                    n_count += 1
            elif dimension == 'T_F':
                if answer == 'A':
                    t_count += 1
                else:
                    f_count += 1
            elif dimension == 'J_P':
                if answer == 'A':
                    j_count += 1
                else:
                    p_count += 1
        
        # Calculate dimension scores (percentages)
        e_i_total = e_count + i_count
        s_n_total = s_count + n_count
        t_f_total = t_count + f_count
        j_p_total = j_count + p_count
        
        e_percentage = int((e_count / e_i_total) * 100) if e_i_total > 0 else 0
        i_percentage = int((i_count / e_i_total) * 100) if e_i_total > 0 else 0
        s_percentage = int((s_count / s_n_total) * 100) if s_n_total > 0 else 0
        n_percentage = int((n_count / s_n_total) * 100) if s_n_total > 0 else 0
        t_percentage = int((t_count / t_f_total) * 100) if t_f_total > 0 else 0
        f_percentage = int((f_count / t_f_total) * 100) if t_f_total > 0 else 0
        j_percentage = int((j_count / j_p_total) * 100) if j_p_total > 0 else 0
        p_percentage = int((p_count / j_p_total) * 100) if j_p_total > 0 else 0
        
        # Determine personality type
        personality_type = ""
        personality_type += "E" if e_count >= i_count else "I"
        personality_type += "S" if s_count >= n_count else "N"
        personality_type += "T" if t_count >= f_count else "F"
        personality_type += "J" if j_count >= p_count else "P"
        
        # Store results
        self.personality_type = personality_type
        self.dimension_scores = {
            "Extraversion_Introversion": {
                "Extraversion": e_percentage,
                "Introversion": i_percentage
            },
            "Sensing_Intuition": {
                "Sensing": s_percentage,
                "Intuition": n_percentage
            },
            "Thinking_Feeling": {
                "Thinking": t_percentage,
                "Feeling": f_percentage
            },
            "Judging_Perceiving": {
                "Judging": j_percentage,
                "Perceiving": p_percentage
            }
        }
        self.save()
        
        return {
            "personality_type": personality_type,
            "dimension_scores": self.dimension_scores
        }

class PersonalityTestResponse(models.Model):
    """Model for storing personality test responses"""
    session = models.ForeignKey(
        PersonalityTestSession, 
        on_delete=models.CASCADE, 
        related_name='responses'
    )
    question = models.ForeignKey(
        PersonalityTestQuestion, 
        on_delete=models.CASCADE
    )
    selected_option = models.CharField(max_length=1)  # 'A' or 'B'
    answered_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['session', 'question']
    
    def __str__(self):
        return f"Response {self.id} - Session {self.session.session_id}"
    
class PersonalityTestChatMessage(models.Model):
    """Model for personality test chat messages"""
    session = models.ForeignKey(
        PersonalityTestSession, 
        on_delete=models.CASCADE, 
        related_name='chat_messages'
    )
    sender = models.CharField(max_length=20)  # 'system' or 'student'
    content = models.TextField()
    message_type = models.CharField(max_length=50)  # 'greeting', 'question', 'answer', 'completion'
    timestamp = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict, blank=True, null=True)
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"{self.sender}: {self.content[:50]}..."
    
def student_test_results_upload_path(instance, filename):
    """Generate file path for student test results upload"""
    # Determine file type based on the field being uploaded
    file_type = None
    if hasattr(instance, '_current_upload_type'):
        file_type = instance._current_upload_type
    else:
        # Fallback - determine from filename
        if 'personality' in filename.lower():
            file_type = 'personality_test_results'
        elif 'aptitude' in filename.lower():
            file_type = 'aptitude_test_results'
        elif 'percentile' in filename.lower():
            file_type = 'percentile_results'
        else:
            file_type = 'unknown'
    
    return f"student_test_results/{instance.student.school.id}/{instance.student.id}/{instance.academic_year}/{file_type}.csv"

class StudentTestResults(models.Model):
    """Model to store individual student's test result files"""
    student = models.ForeignKey('Student', on_delete=models.CASCADE, related_name='test_results')
    academic_year = models.PositiveIntegerField(default=get_current_year)
    
    # Test result files
    personality_test_file = models.FileField(
        upload_to=student_test_results_upload_path, 
        blank=True, 
        null=True,
        help_text="Personality test results CSV file"
    )
    aptitude_test_file = models.FileField(
        upload_to=student_test_results_upload_path, 
        blank=True, 
        null=True,
        help_text="Aptitude test results CSV file"
    )
    percentile_results_file = models.FileField(
        upload_to=student_test_results_upload_path, 
        blank=True, 
        null=True,
        help_text="Academic percentile results CSV file"
    )
    
    # Metadata
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Processing status
    is_processed = models.BooleanField(default=False)
    processing_errors = models.JSONField(default=dict, blank=True)
    
    class Meta:
        unique_together = ('student', 'academic_year')
        ordering = ['-academic_year', '-uploaded_at']
    
    def __str__(self):
        return f"{self.student.user.name} - {self.academic_year} Test Results"
    
    def save(self, *args, **kwargs):
        # Set the upload type for the file path generation
        if hasattr(self, '_current_upload_type'):
            super().save(*args, **kwargs)
        else:
            super().save(*args, **kwargs)

class StudentTestResultsSummary(models.Model):
    """Model to store processed summary data from test results"""
    student_test_results = models.OneToOneField(
        StudentTestResults, 
        on_delete=models.CASCADE, 
        related_name='summary'
    )
    
    # Personality Test Summary
    personality_type = models.CharField(max_length=10, blank=True, null=True)  # e.g., "INTJ"
    personality_dimensions = models.JSONField(default=dict, blank=True)  # Dimension scores
    
    # Aptitude Test Summary
    total_aptitude_score = models.IntegerField(blank=True, null=True)
    aptitude_scores = models.JSONField(default=dict, blank=True)  # Individual aptitude scores
    aptitude_percentiles = models.JSONField(default=dict, blank=True)  # Percentile rankings
    
    # Academic Percentile Summary
    academic_percentiles = models.JSONField(default=dict, blank=True)  # Subject-wise percentiles
    overall_academic_percentile = models.FloatField(blank=True, null=True)
    academic_grade = models.CharField(max_length=20, blank=True, null=True)
    
    # Overall Rankings
    school_rank = models.IntegerField(blank=True, null=True)
    class_rank = models.IntegerField(blank=True, null=True)
    
    # Timestamps
    processed_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Summary for {self.student_test_results.student.user.name}"

class TestResultsUploadBatch(models.Model):
    """Model to track batch uploads of test results"""
    school = models.ForeignKey('School', on_delete=models.CASCADE, related_name='test_upload_batches')
    academic_year = models.PositiveIntegerField(default=get_current_year)
    upload_type = models.CharField(max_length=50, choices=[
        ('personality_test', 'Personality Test'),
        ('aptitude_test', 'Aptitude Test'),
        ('percentile_results', 'Percentile Results'),
        ('mixed', 'Mixed Upload')
    ])
    
    # Upload metadata
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    # Processing status
    total_records = models.IntegerField(default=0)
    successful_uploads = models.IntegerField(default=0)
    failed_uploads = models.IntegerField(default=0)
    processing_errors = models.JSONField(default=list, blank=True)
    
    # Files processed in this batch
    students_processed = models.ManyToManyField('Student', blank=True)
    
    is_completed = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"{self.school.name} - {self.upload_type} - {self.uploaded_at.strftime('%Y-%m-%d')}"
    
    @property
    def success_rate(self):
        if self.total_records > 0:
            return (self.successful_uploads / self.total_records) * 100
        return 0
    
def career_counseling_upload_path(instance, filename):
    """Generate file path for career counseling uploads"""
    from django.utils.text import slugify
    import os
    
    timestamp = now().strftime('%Y%m%d_%H%M%S')
    base_name, ext = os.path.splitext(filename)
    safe_name = f"{slugify(base_name)}{ext}"
    
    return f"career_counseling/{instance.student.school.id}/{instance.student.id}/{timestamp}/{safe_name}"

class CareerCounselingRequest(models.Model):
    """Model to store career counseling requests from students"""
    
    EMAIL_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('sent', 'Sent'),
        ('failed', 'Failed'),
    ]
    
    # Student information
    student = models.ForeignKey('Student', on_delete=models.CASCADE, related_name='career_counseling_requests')
    
    # Form data (as submitted by student)
    name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    career_field = models.CharField(max_length=255)
    
    # File storage
    pdf_file = models.FileField(
        upload_to=career_counseling_upload_path,
        help_text="Career Council PDF file uploaded by student"
    )
    response_json = models.FileField(
        upload_to=career_counseling_upload_path,
        help_text="JSON file containing form response data"
    )
    
    # Email tracking
    counselor_email = models.EmailField(default='counselor@example.com')
    email_content = models.TextField(blank=True, null=True, help_text="HTML content of the email sent")
    email_status = models.CharField(max_length=10, choices=EMAIL_STATUS_CHOICES, default='pending')
    email_sent_at = models.DateTimeField(blank=True, null=True)
    mailchimp_email_id = models.CharField(max_length=255, blank=True, null=True, help_text="Mailchimp message ID for tracking")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Career Counseling Request"
        verbose_name_plural = "Career Counseling Requests"
    
    def __str__(self):
        return f"{self.student.user.name} - {self.career_field} - {self.created_at.strftime('%Y-%m-%d')}"
    
    @property
    def school(self):
        return self.student.school
    
    @property
    def is_email_sent(self):
        return self.email_status == 'sent' and self.email_sent_at is not None
    
#new api feedback models

class FeedbackQuestion(models.Model):
    fid = models.CharField(max_length=100)
    qid = models.CharField(max_length=100)
    type = models.CharField(max_length=50)
    label = models.CharField(max_length=1000)
    options = models.JSONField(default=list)
    

    def __str__(self):
        return f"{self.fid} - {self.qid}"

    class Meta:
        unique_together = ('fid', 'qid')

class FeedbackSubmission(models.Model):
    user_id = models.CharField(max_length=100)
    fid = models.CharField(max_length=100)
    responses = models.JSONField(default=list)
    submitted_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user_id', 'fid'], name='unique_user_feedback')
        ]

    def __str__(self):
        return f"{self.user_id} - {self.fid}"
    

#leadership trait model
class LeadershipTrait(models.Model):
    leadership_trait_name = models.CharField(max_length=100, unique=True, blank=False)
    unique_qualities = models.JSONField(default=list, blank=False)
    hobbies = models.JSONField(default=list, blank=False)
    books = models.JSONField(default=list, blank=False)
    authors = models.JSONField(default=list, blank=False)
    communication_activities = models.JSONField(default=list, blank=False)
    public_service = models.JSONField(default=list, blank=False)
    secondary_domain = models.JSONField(default=list, blank=False)
    analytical_activities = models.JSONField(default=list, blank=False)
    favourite_subjects = models.JSONField(default=list, blank=False)
    suggestions = models.JSONField(default=list, blank=False)

    def __str__(self):
        return self.leadership_trait_name

# models_general.py

class GeneralTestQuestion(models.Model):
    """
    Stores each free‐text question for the General test.
    The `order` field dictates the sequence (1, 2, 3…).
    """
    question_id = models.AutoField(primary_key=True)          # Custom PK named question_id
    question_text = models.TextField()
    order = models.PositiveIntegerField(default=0, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order"]
        constraints = [
            models.UniqueConstraint(fields=["order"], name="unique_question_order")
        ]

    def __str__(self) -> str:
        return f"Q{self.order}: {self.question_text[:50]}..."


class GeneralTestSession(models.Model):
    """
    Tracks a user's attempt at the General test.
    """
    session_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    student = models.ForeignKey(
        "Student", on_delete=models.CASCADE, related_name="general_test_sessions"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"{self.student.user.username} – General Session {self.session_id}"


class GeneralTestResponse(models.Model):
    """
    Records each free‐text answer given during a session.
    """
    session = models.ForeignKey(
        GeneralTestSession, on_delete=models.CASCADE, related_name="responses"
    )
    question = models.ForeignKey(
        GeneralTestQuestion, on_delete=models.CASCADE, related_name="responses"
    )
    answer_text = models.TextField()
    response_time = models.FloatField(help_text="Seconds between ask and answer")
    answered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["answered_at"]
        unique_together = ("session", "question")

    def __str__(self) -> str:
        return f"Response to Q{self.question.order} in session {self.session.session_id}"


class GeneralTestChatMessage(models.Model):
    """
    Persists the chat transcript (questions, answers, completion messages).
    """
    session = models.ForeignKey(
        GeneralTestSession, on_delete=models.CASCADE, related_name="chat_messages"
    )
    sender = models.CharField(max_length=10)            # "system" or "student"
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    message_type = models.CharField(
        max_length=20, default="message"
    )  # "question", "answer", or "completion"
    metadata = models.JSONField(blank=True, null=True)

    class Meta:
        ordering = ["timestamp"]

    def __str__(self) -> str:
        return f"{self.sender} @ {self.timestamp:%Y-%m-%d %H:%M:%S}: {self.content[:30]}..."
        

class StudentPercentileMarks(models.Model):
    student_id = models.CharField(max_length=64, unique=True)
    student_class = models.CharField(max_length=10)
    marks = models.JSONField()
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.student_id} - {self.student_class}"
    

class GeneralTestAIAnalysis(models.Model):
    """
    Stores only the AI (OpenAI/ChatGPT) results for a completed GeneralTestSession as a JSON object.
    """
    ai_json = models.JSONField(null=True, blank=True)  # Store only the AI response as JSON

    def __str__(self):
        return f"AI Analysis Table: {self.ai_json}"