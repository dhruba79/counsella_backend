import os
import json
import re
import logging
from dotenv import read_dotenv
from typing import Dict, Any, List
import openai
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Load environment variables from .env file
# read_dotenv(dotenv=os.path.join(BASE_DIR, '.env'))

env_file = os.path.join(BASE_DIR, '.env')
print(f"Reading .env file from: {env_file}")
read_dotenv(dotenv=env_file)

# --- Boilerplate Setup ---
logger = logging.getLogger(__name__)

# --- OpenAI API Configuration ---
try:
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    if not openai_api_key:
        logger.warning("OPENAI_API_KEY is not found in your .env file.")
    openai.api_key = openai_api_key
except Exception as e:
    logger.error(f"Error configuring OpenAI API: {e}")
# --- End Boilerplate ---


# --- Updated, Highly Specific Prompt ---
COMPREHENSIVE_ANALYSIS_PROMPT = """
You are a highly intelligent data extraction AI. Your task is to analyze the following Q&A conversation from a student assessment and extract key information into a structured JSON format.

*Instructions:*
1.  Read the entire conversation carefully.
2.  Your final response MUST be ONLY the raw JSON object provided in the template below. Do not add any explanations, introductory text, or markdown formatting like ```json.
3.  *For text fields* (subject_name, hobby_1,hobby_2, hobby_3,unique_qualities,career_profession.), extract the specific names or items.
4.  *For boolean fields* (is_family_influenced, is_passion, etc.), you must respond with true or false.
5.  *For categorical fields*, your response MUST be one of the specified options:
    * book_movie_genre: romantic/documentary/sports/muder mystry/College movie
    * parental_profession_type: must be salaried or businessman.
    * socioeconomic_class: must be middle, upper, or lower.
    * upbringing_indicator: must be middle, upper, or lower.

---
*Full Conversation:*
{conversation_text}
---

*Provide your complete analysis in this exact JSON format:*
{{
    "subject_name": null,
    "hobby_1": null,
    "hobby_2": null,
    "hobby_3": null,
    "unique_qualities": null,
    "career_profession": null,
    "is_passion": null,
    "is_family_influenced": null,
    "parental_profession_type": null,
    "has_negotiation_skill": null,
    "is_public_service": null,
    "book_movie_genre": null,
    "nature_exploration": null,
    "cultural_exploration": null,
    "historical_exploration": null,
    "socioeconomic_class": null,
    "upbringing_indicator": null
}}
"""

def clean_and_parse_json(raw_text: str):
    """
    Extracts a JSON object from a string that might include markdown.
    """
    match = re.search(r'\{.*\}', raw_text, re.DOTALL)
    if not match:
        logger.error("No JSON object found in response.")
        return None
    json_str = match.group(0)

    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        logger.error(f"Failed to decode JSON from response: {e}\nResponse text: {json_str}")
        return None

def analyze_student_profile(questions_data: List[Dict[str, Any]], user_answers: Dict[int, str]):
    """
    Sends the entire student conversation to OpenAI ChatGPT for a comprehensive analysis.
    """
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    if not openai_api_key:
        logger.error("OpenAI analysis failed: API key not configured.")
        return None

    conversation_parts = []
    for question in questions_data:
        order = question['order']
        answer = user_answers.get(order, "No answer provided.")
        conversation_parts.append(f"Q{order}: {question['question_text']}\nA{order}: {answer}")

    conversation_text = "\n\n".join(conversation_parts)

    prompt = COMPREHENSIVE_ANALYSIS_PROMPT.format(conversation_text=conversation_text)

    try:
        # For openai>=1.0.0
        client = openai.OpenAI(api_key=openai_api_key)
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=4000,
            temperature=0.2
        )
        result_text = response.choices[0].message.content
        return clean_and_parse_json(result_text)
    except Exception as e:
        logger.error(f"OpenAI API call failed: {e}")
        return None

