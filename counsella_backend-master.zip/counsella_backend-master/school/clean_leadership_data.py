import os
import sys
import django

# Setup Django
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')
django.setup()

from django.db import connection

table_name = "school_leadershiptrait"  # Keep table, just clear all rows

def clear_table_data():
    with connection.cursor() as cursor:
        try:
            cursor.execute(f"DELETE FROM {table_name};")
            print(f"✅ All data from table '{table_name}' has been deleted.")
        except Exception as e:
            print(f"❌ Failed to delete data from table '{table_name}':", e)

if __name__ == "__main__":
    clear_table_data()