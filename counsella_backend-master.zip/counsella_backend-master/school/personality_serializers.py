from rest_framework import serializers
from .models import PersonalityTestQuestion, PersonalityTestSession, PersonalityTestResponse

class PersonalityTestQuestionSerializer(serializers.ModelSerializer):
    """Serializer for personality test questions"""
    options = serializers.DictField(read_only=True)
    dimension = serializers.CharField(source='dimension_display')
    
    class Meta:
        model = PersonalityTestQuestion
        fields = [
            'id', 
            'question_id',
            'dimension', 
            'options', 
            'question_number'
        ]
        extra_kwargs = {
            'question_id': {'source': 'id'}
        }

class PersonalityTestSessionSerializer(serializers.ModelSerializer):
    """Serializer for personality test sessions"""
    
    class Meta:
        model = PersonalityTestSession
        fields = [
            'session_id', 
            'created_at', 
            'completed_at', 
            'is_active',
            'personality_type',
            'dimension_scores'
        ]

class PersonalityTestResponseSerializer(serializers.ModelSerializer):
    """Serializer for personality test responses"""
    
    class Meta:
        model = PersonalityTestResponse
        fields = [
            'id', 
            'session', 
            'question', 
            'selected_option', 
            'answered_at'
        ]
        read_only_fields = ['id', 'answered_at']

class PersonalityTestReportSerializer(serializers.Serializer):
    """Serializer for personality test reports"""
    student_name = serializers.CharField()
    grade = serializers.CharField()
    school_name = serializers.CharField()
    personality_type = serializers.CharField()
    dimensions = serializers.ListField()
    session_id = serializers.UUIDField()
    generated_at = serializers.DateTimeField()