from django.contrib import admin

from .models import School, SchoolBoard, Student, SchoolStudentResults, Career, CareerStatistic, CareerInfo


@admin.register(SchoolBoard)
class SchoolBoardAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    search_fields = ['name']


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ['name', 'school_board', 'contact_name', 'contact_no', 'is_active']
    search_fields = ['name', 'contact_name', 'contact_no']
    list_filter = ['is_active', 'school_board']
    readonly_fields = ['uid', 'created_at', 'updated_at']


admin.site.register(Student)
admin.site.register(SchoolStudentResults)

# Register the Leader Traits models
class CareerStatisticInline(admin.TabularInline):
    model = CareerStatistic
    extra = 1

class CareerInfoInline(admin.StackedInline):
    model = CareerInfo

@admin.register(Career)
class CareerAdmin(admin.ModelAdmin):
    list_display = ('name', 'value')
    search_fields = ('name', 'value')
    inlines = [CareerStatisticInline, CareerInfoInline]

@admin.register(CareerStatistic)
class CareerStatisticAdmin(admin.ModelAdmin):
    list_display = ('career', 'category')
    list_filter = ('category',)
    search_fields = ('career__name', 'category')

@admin.register(CareerInfo)
class CareerInfoAdmin(admin.ModelAdmin):
    list_display = ('career',)
    search_fields = ('career__name',)