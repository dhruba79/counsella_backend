from rest_framework import permissions

class IsSchoolAdmin(permissions.BasePermission):
    """
    Custom permission to grant access only to users who are school admins.
    """

    def has_permission(self, request, view):
        # Ensure the user is authenticated and is a school admin
        return bool(request.user and request.user.is_authenticated and request.user.is_school_admin)


class IsSchoolStudent(permissions.BasePermission):
    """
    Custom permission to grant access only to users who are school admins.
    """

    def has_permission(self, request, view):
        # Ensure the user is authenticated and is a school admin
        return bool(request.user and request.user.is_authenticated and request.user.is_school_student)