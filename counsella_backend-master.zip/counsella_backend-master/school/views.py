from datetime import datetime
import json
from django.contrib.auth import authenticate
from django.forms import ValidationError
from django.shortcuts import render, get_object_or_404
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from api.renderers import ResponseRenderer
from django.conf import settings
from . import serializers
from .models import AdaptiveTestResponse, AdaptiveTestSession, School, SchoolBoard, Student, SchoolStudentResults, Career, CareerInfo, CareerStatistic, StudentTestResults, StudentTestResultsSummary, TestResultsUploadBatch, FeedbackQuestion, FeedbackSubmission,StudentPercentileMarks
from .permissions import IsSchoolAdmin, IsSchoolStudent

from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import pandas as pd
import numpy as np
import os
import re
from scripts.data_science.marks_to_percentile import calc_percentile
from scripts.data_science.percentile_to_grade import calculate_grades
from .serializers import ProcessResultsSerializer, ResultFilterSerializer, StudentResultsListSerializer, StudentPercentileSerializer, StudentGradeSerializer, CareerSerializer, StudentTestResultsSerializer, StudentTestResultsSummarySerializer, TestResultsUploadBatchSerializer, TestResultsUploadSerializer, StudentPercentileMarksSerializer
import tempfile
from account.models import User
from django.utils.timezone import now
from account.models import User
from .utils import process_avatar_image
from django.http import HttpResponse, Http404
import mimetypes
from .models import CareerCounselingRequest,LeadershipTrait
from .serializers import CareerCounselingRequestSerializer, CareerCounselingRequestResponseSerializer, FeedbackQuestionSerializer, FeedbackSubmissionSerializer,LeadershipTraitSerializer
import mailchimp_transactional as MailchimpTransactional
from mailchimp_transactional.api_client import ApiClientError
from drf_yasg.utils import swagger_auto_schema

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

class SchoolBoardListCreateView(generics.ListCreateAPIView):
    queryset = SchoolBoard.objects.all()
    serializer_class = serializers.SchoolBoardSerializer
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]


class SchoolBoardDetailsView(generics.RetrieveUpdateDestroyAPIView):
    queryset = SchoolBoard.objects.all()
    serializer_class = serializers.SchoolBoardSerializer
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response({'message': 'SchoolBoard deleted successfully'}, status=status.HTTP_204_NO_CONTENT)


class ActiveSchoolBoardListView(generics.ListAPIView):
    queryset = SchoolBoard.objects.filter(is_active=True)
    serializer_class = serializers.SchoolBoardSerializer
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]


class SchoolBoardActivationView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            school_board = SchoolBoard.objects.get(pk=pk)
        except SchoolBoard.DoesNotExist:
            return Response({'error': 'SchoolBoard not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = serializers.SchoolBoardActivationSerializer(school_board, data=request.data, partial=True)

        if serializer.is_valid(raise_exception=True):
            serializer.save()
            is_active = serializer.data.get('is_active')
            message = 'SchoolBoard activated successfully' if is_active else 'SchoolBoard deactivated successfully'
            return Response({'message': message}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolListView(APIView):
    def get(self, request, uid=None, *args, **kwargs):
        if uid:
            try:
                # Retrieve school by UID
                school = School.objects.get(uid=uid)
                serializer = serializers.SchoolSerializer(school)
                return Response(serializer.data, status=status.HTTP_200_OK)
            except School.DoesNotExist:
                return Response(
                    {"error": "School not found."},
                    status=status.HTTP_404_NOT_FOUND
                )
        else:
            # Retrieve all schools
            schools = School.objects.all()
            serializer = serializers.SchoolSerializer(schools, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)


class SchoolCreateView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(request_body=serializers.SchoolCreateSerializer)
    def post(self, request, *args, **kwargs):
        serializer = serializers.SchoolCreateSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response({'message': 'New School added successfully', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolActivationView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, uid, *args, **kwargs):
        try:
            school = School.objects.get(uid=uid)
        except School.DoesNotExist:
            return Response({'error': 'School not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = serializers.SchoolActivationSerializer(school, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            is_active = serializer.data.get('is_active')
            message = 'School activated successfully' if is_active else 'School deactivated successfully'
            return Response({'message': message}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolUpdateView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, uid, *args, **kwargs):
        try:
            school = School.objects.get(uid=uid)
        except School.DoesNotExist:
            return Response({'error': 'School not found'}, status=status.HTTP_404_NOT_FOUND)

        serializer = serializers.SchoolUpdateSerializer(school, data=request.data, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response({'message': 'School details updated successfully', 'data':serializer.data}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolDeleteView(APIView):
    def delete(self, request, uid, *args, **kwargs):
        try:
            # Retrieve the school by UID
            school = School.objects.get(uid=uid)
            school.delete()  # Delete the school instance
            return Response({"message": "School deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
        except School.DoesNotExist:
            return Response({"error": "School not found."}, status=status.HTTP_404_NOT_FOUND)


class SchoolWithAdminCreateView(generics.CreateAPIView):
    """API View to create a school with an admin"""
    #queryset = School.objects.all()
    serializer_class = serializers.SchoolWithAdminSerializer
    renderer_classes = [ResponseRenderer]


    @swagger_auto_schema(
        operation_description="Create a new school along with an admin in a single API request",
        request_body=serializers.SchoolWithAdminSerializer,
        responses={
            201: serializers.SchoolWithAdminSerializer,
            400: openapi.Response("Bad Request"),
        },
    )
    def post(self, request, *args, **kwargs):
        # return super().post(request, *args, **kwargs)

        serializer = serializers.SchoolWithAdminSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            message = 'School onboarding request accepted successfully, please wait until we review and approve.'
            return Response({'status': True, 'message': message}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class StudentRegistrationView(generics.CreateAPIView):
    """API to register students"""

    # queryset = Student.objects.all()
    serializer_class = serializers.SchoolStudentSerializer
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(
        operation_description="Register a new student",
        request_body=serializers.SchoolStudentSerializer,
        responses={
            201: serializers.SchoolStudentSerializer,
            400: openapi.Response("Bad Request"),
        },
    )
    def post(self, request, *args, **kwargs):
        serializer = serializers.SchoolStudentSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            message = 'School student request accepted successfully, please wait until we review and approve.'
            return Response({'status': True, 'message': message}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolAdminLoginView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.SchoolUserLoginSerializer)
    def post(self, request, format=None):
        serializer = serializers.SchoolUserLoginSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            print (serializer.data)
            print (serializer.validated_data)
            print ("@#^&@#^*&#@^^*&#*^&")
            email = serializer.validated_data.get('email')
            password = serializer.validated_data.get('password')

            print (email)
            print (password)
            user = authenticate(email=email, password=password)
            print (user)
            print ("&@&#*&()")
            if user and user.is_school_admin:
                token = get_tokens_for_user(user)
                return Response({'token': token, 'message': 'Login successful'}, status=status.HTTP_200_OK)
            else:
                return Response({'errors': {'non_field_errors': ['Email or Password is not valid']}}, status=status.HTTP_404_NOT_FOUND)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolStudentLoginView(APIView):
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=serializers.SchoolUserLoginSerializer)
    def post(self, request, format=None):
        serializer = serializers.SchoolUserLoginSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            email = serializer.validated_data.get('email')
            password = serializer.validated_data.get('password')
            user = authenticate(email=email, password=password)
            
            # First check if this is an admin account trying to use student login
            if user and user.is_school_admin:
                return Response(
                    {'errors': {'non_field_errors': ['Admin accounts cannot use the student login. Please use the admin login page.']}},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # Then check if this is a valid student account
            if user and user.is_school_student:
                token = get_tokens_for_user(user)
                return Response({'token': token, 'message': 'Login successful'}, status=status.HTTP_200_OK)
            else:
                return Response({'errors': {'non_field_errors': ['Email or Password is not valid']}}, status=status.HTTP_404_NOT_FOUND)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class StudentProfileAPIView(APIView):
    renderer_classes = [ResponseRenderer]
    permission_classes = [IsAuthenticated, IsSchoolStudent]  # Ensure the user is authenticated

    @swagger_auto_schema()
    def get(self, request, *args, **kwargs):
        """
        Retrieve the student's profile.
        """

        student = get_object_or_404(Student, user=request.user)
        serializer = serializers.StudentProfileSerializer(student)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @swagger_auto_schema(request_body=serializers.StudentProfileSerializer)
    def put(self, request, *args, **kwargs):
        """
        Update the student's profile.
        """
        student = get_object_or_404(Student, user=request.user)
        serializer = serializers.StudentProfileSerializer(student, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Student profile updated successfully'}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SchoolResultAPIView(APIView):
    renderer_classes = [ResponseRenderer]

    permission_classes = [IsAuthenticated, IsSchoolAdmin]

    @swagger_auto_schema(
        operation_description="""
        Retrieve school results. Returns most recent result submission.
        """,
        responses={
            200: serializers.SchoolResultSerializer(many=True),
            404: 'No results found'
        }    )
    def get(self, request, *args, **kwargs):
        """
        Retrieve the school's results for the last 3 years.
        """

        results = SchoolStudentResults.objects.filter(school_id=request.user.school_admin.id).order_by('-year').order_by('-uploaded_at').first()
        serializer = serializers.SchoolResultSerializer(results, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)

    @swagger_auto_schema(request_body=serializers.SchoolResultSerializer)
    def post(self, request, *args, **kwargs):
        """
        Upload a new result for a specific school and year.
        """

        serializer = serializers.SchoolResultSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Results uploaded successfully'}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class ProcessStudentResultsView(APIView):
    permission_classes = [IsAuthenticated, IsSchoolAdmin]

    def process_file(self, file, school, exam_type, section, academic_year, default_class=10):
        """Process a single file, save percentile and grades, and create student accounts"""
        try:
            print(f"Processing file for {exam_type}...")
            df = pd.read_csv(file)
            print(f"CSV loaded successfully with {len(df)} rows")
            
            # Clean column names
            df.columns = df.columns.str.strip()
            print(f"Columns after cleaning: {df.columns.tolist()}")
            
            # Check for required columns for registration and grades
            registration_columns = ['Name', 'Email', 'Address', 'Roll Number', 'Birth Date', 'Mobile Number', 'Class']
            grade_columns = ['Literature', 'Grammer', 'History', 'Geography', 'Math', 'Biology', 'Physics', 'Chemistry']
            required_columns = registration_columns + grade_columns
            
            # Check for optional "Passout Year" column
            has_passout_year = 'Passout Year' in df.columns
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                print(f"Missing columns: {missing_columns}")
                return {
                    "success": False,
                    "error": f"Missing required columns: {', '.join(missing_columns)}"
                }

            # Store student info before processing
            student_info = df[registration_columns].copy()
            if has_passout_year:
                student_info['Passout Year'] = df['Passout Year']
            
            print(f"Student info extracted with shape: {student_info.shape}")
            
            if len(student_info) == 0:
                print("No rows found in the CSV")
                return {
                    "success": False,
                    "error": "CSV file contains no data rows"
                }
            
            # Print first row as sample
            print(f"First row sample: {student_info.iloc[0].to_dict()}")
            
            # Get class_number for file naming (use most common class in the file)
            # Handle the case where mode() might return an empty array
            if not student_info.empty:
                try:
                    most_common_class = student_info['Class'].mode()[0]
                    print(f"Most common class detected: {most_common_class}")
                except (IndexError, KeyError):
                    most_common_class = default_class
                    print(f"Could not determine most common class, using default: {default_class}")
            else:
                most_common_class = default_class
                print(f"Empty DataFrame, using default class: {default_class}")
            
            # Create student accounts for each student in the CSV
            created_accounts = []
            existing_accounts = []
            error_records = []
            
            print(f"Starting to process {len(student_info)} student records...")
            
            for idx, row in student_info.iterrows():
                try:
                    print(f"Processing row {idx + 2}...")
                    # Check for missing values in this row
                    missing_fields = [col for col in registration_columns if pd.isna(row[col])]
                    if missing_fields:
                        print(f"Row {idx + 2} has missing fields: {missing_fields}")
                        error_records.append({
                            'row': idx + 2,  # +2 because idx is 0-based and we have a header row
                            'error': f"Missing required fields: {', '.join(missing_fields)}",
                            'data': row.to_dict()
                        })
                        continue
                    
                    student_name = row['Name'].strip()
                    email = row['Email'].strip()
                    address = row['Address'].strip()
                    roll_number = int(row['Roll Number'])
                    
                    print(f"Processing student: {student_name}, email: {email}")
                    
                    # Convert birth date from dd-mm-yyyy to yyyy-mm-dd for database
                    try:
                        birth_date_str = str(row['Birth Date']).strip()
                        print(f"Raw birth date: {birth_date_str}")
                        
                        # Always use YYYY-MM-DD format for Django
                        # Check if the format is already correct
                        if re.match(r'^\d{4}-\d{2}-\d{2}$', birth_date_str):
                            # Already in YYYY-MM-DD format
                            birth_date = birth_date_str
                            print(f"Birth date already in correct format: {birth_date}")
                        else:
                            # Try different parsing approaches
                            try:
                                # Try parsing with dateutil which is more flexible
                                from dateutil import parser
                                parsed_date = parser.parse(birth_date_str)
                                birth_date = parsed_date.strftime('%Y-%m-%d')
                                print(f"Parsed birth date: {birth_date}")
                            except:
                                # If that fails, try manual parsing based on common formats
                                parts = birth_date_str.split('-')
                                if len(parts) == 3:
                                    # Check if first part is a 4-digit year or day
                                    if len(parts[0]) == 4:  # Likely YYYY-MM-DD
                                        birth_date = birth_date_str
                                    else:  # Likely DD-MM-YYYY
                                        birth_date = f"{parts[2]}-{parts[1]}-{parts[0]}"
                                    print(f"Manually formatted birth date: {birth_date}")
                                else:
                                    raise ValueError(f"Cannot parse date format: {birth_date_str}")
                        
                        # Validate the final date format
                        if not re.match(r'^\d{4}-\d{2}-\d{2}$', birth_date):
                            raise ValueError(f"Final date {birth_date} is not in YYYY-MM-DD format")
                            
                    except Exception as e:
                        print(f"Birth date error: {str(e)}")
                        error_records.append({
                            'row': idx + 2,
                            'error': f"Birth date format error: {str(e)}. Expected format: YYYY-MM-DD",
                            'data': row.to_dict()
                        })
                        continue
                    
                    mobile_number = str(row['Mobile Number']).strip()
                    
                    # Handle class field - ensure it's an integer
                    try:
                        student_class = int(row['Class'])
                    except (ValueError, TypeError):
                        error_records.append({
                            'row': idx + 2,
                            'error': f"Class must be a number. Got: {row['Class']}",
                            'data': row.to_dict()
                        })
                        continue
                    
                    # Get passout year if available, or calculate based on class
                    passout_year = None
                    if has_passout_year and not pd.isna(row['Passout Year']):
                        try:
                            passout_year = int(row['Passout Year'])
                        except (ValueError, TypeError):
                            print(f"Invalid passout year for row {idx + 2}: {row['Passout Year']}")
                    
                    # Generate a default password
                    default_password = f"{student_name.split()[0].lower()}@123"
                    
                    # Check if student already exists
                    existing_user = User.objects.filter(email=email).first()
                    
                    if existing_user:
                        print(f"User already exists: {email}")
                        existing_accounts.append({
                            'name': student_name,
                            'email': email,
                            'roll_number': roll_number
                        })
                        continue
                    
                    # Calculate passout year if not provided
                    if not passout_year:
                        current_year = now().year
                        student_class = int(row['Class'])
                        if student_class <= 10:
                            years_to_passout = 10 - student_class
                            passout_year = current_year + years_to_passout
                        else:
                            # For classes above 10, they've already passed 10th
                            passout_year = current_year
                    
                    # Create user
                    print(f"Creating user: {email}")
                    user = User.objects.create(
                        email=email,
                        name=student_name,
                        is_school_student=True,
                        is_active=True,
                        contact_number=mobile_number
                    )
                    user.set_password(default_password)
                    user.save()
                    print(f"User created with ID: {user.id}")
                    
                    # Generate registration number
                    try:
                        # Generate a unique registration number
                        school_code = ''.join([word[0].upper() for word in school.name.split() if word])
                        if len(school_code) <= 2:
                            school_code = school.name[:3].upper()
                        
                        year_code = str(passout_year)[-2:]
                        roll_code = str(roll_number).zfill(3)
                        
                        registration_no = f"{school_code}{year_code}{roll_code}"
                        
                        # Ensure it's unique
                        counter = 1
                        original_reg_no = registration_no
                        while Student.objects.filter(registration_no=registration_no).exists():
                            registration_no = f"{original_reg_no}-{counter}"
                            counter += 1
                            
                        print(f"Generated registration number: {registration_no}")
                    except Exception as e:
                        print(f"Error generating registration number: {str(e)}")
                        registration_no = f"TBD-{user.id}"
                    
                    # Create student profile
                    print(f"Creating student profile for: {email}")
                    try:
                        student = Student(
                            user=user,
                            school=school,
                            student_class=student_class,
                            section=section,
                            roll_number=roll_number,
                            birth_date=birth_date,
                            contact_number=mobile_number,
                            address=address,
                            registration_no=registration_no
                        )
                        student.save()  # Explicit save
                        
                        # Verify the student was created with a valid ID
                        student_id = student.id
                        if not student_id:
                            print(f"WARNING: Student created without ID for user {user.id}")
                        else:
                            print(f"Student created successfully with ID {student_id}")
                        
                        # Double-check by re-querying
                        saved_student = Student.objects.filter(user=user).first()
                        if saved_student:
                            print(f"Verified student in database: ID={saved_student.id}")
                        else:
                            print(f"WARNING: Could not verify student in database for user {user.id}")
                    
                    except Exception as e:
                        print(f"Error creating student: {str(e)}")
                        import traceback
                        traceback.print_exc()
                        
                        # Clean up user if student creation failed
                        try:
                            user.delete()
                            print(f"Deleted user {user.id} due to student creation failure")
                        except Exception as del_e:
                            print(f"Error deleting user after student creation failure: {str(del_e)}")
                        
                        error_records.append({
                            'row': idx + 2,
                            'error': f"Failed to create student: {str(e)}",
                            'data': row.to_dict()
                        })
                        continue
                    
                    created_accounts.append({
                        'name': student_name,
                        'email': email,
                        'password': default_password,
                        'roll_number': roll_number,
                        'class': student_class,
                        'birth_date': birth_date_str,  # Return original format
                        'mobile_number': mobile_number,
                        'registration_no': registration_no,
                        'student_id': student.id,  # Include student ID in the response
                        'passout_year': passout_year
                    })
                    print(f"Successfully created account for: {email}")
                
                except Exception as e:
                    print(f"Error processing row {idx + 2}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    error_records.append({
                        'row': idx + 2,
                        'error': str(e),
                        'data': row.to_dict()
                    })
            
            print(f"Account creation complete. Created: {len(created_accounts)}, Existing: {len(existing_accounts)}, Errors: {len(error_records)}")
            
            # Check if we processed any student records successfully
            accounts_processed = len(created_accounts) + len(existing_accounts) > 0
            
            # Skip grade calculation if no accounts were processed
            if not accounts_processed:
                print("No valid student records were processed")
                return {
                    "success": False,
                    "error": "No valid student records to process",
                    "error_records": error_records
                }
            
            # IMPORTANT ADDITION: Save the original raw marks file
            raw_marks_filename = f"Raw_{school.name}_{academic_year}_{most_common_class}_{section}_{exam_type}.csv"
            raw_marks_path = f"school_results/{school.id}/{academic_year}/{raw_marks_filename}"
            
            raw_marks_file_path = None
            try:
                # Save the original CSV file
                df.to_csv('temp_raw_marks.csv', index=False)
                with open('temp_raw_marks.csv', 'rb') as f:
                    raw_marks_file_path = default_storage.save(raw_marks_path, ContentFile(f.read()))
                os.remove('temp_raw_marks.csv')
                print(f"Original raw marks file saved at {raw_marks_file_path}")
            except Exception as e:
                print(f"Error saving raw marks file: {str(e)}")
                raw_marks_file_path = None
            
            # GRADE PROCESSING SECTION - Skip for board exams
            percentile_path = ""
            grades_path = ""
            grade_error = None
            
            # Only process percentiles and grades for non-board exams
            if exam_type != 'board':
                try:
                    print("Beginning grade processing...")
                    # Continue with the existing processing logic for grades
                    subjects_df = df[grade_columns].copy()

                    # Convert marks to percentile
                    print("Calculating percentiles...")
                    percentile_df = calc_percentile(subjects_df.copy())
                    
                    # Combine percentile results with student info
                    percentile_results = pd.concat([student_info, percentile_df], axis=1)
                    
                    # Save percentile results - use most common class for filename
                    percentile_filename = f"Percentile_{school.name}_{academic_year}_{most_common_class}_{section}_{exam_type}.csv"
                    percentile_path = f"school_results/{school.id}/{academic_year}/{percentile_filename}"
                    
                    print(f"Saving percentile results to: {percentile_path}")
                    percentile_results.to_csv('temp_percentile.csv', index=False)
                    with open('temp_percentile.csv', 'rb') as f:
                        saved_percentile = default_storage.save(percentile_path, ContentFile(f.read()))
                    percentile_path = saved_percentile
                    os.remove('temp_percentile.csv')
                    
                    # Save percentile to temp file for grade conversion
                    print("Converting percentiles to grades...")
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp:
                        percentile_df.to_csv(tmp.name, index=False)
                        
                        # Convert percentile to grades
                        grades_df = calculate_grades(tmp.name, "temp_grade.csv")
                    
                    # Combine grades with student info
                    final_grades = pd.concat([student_info, grades_df], axis=1)
                    
                    # Save grades results - use most common class for filename
                    grades_filename = f"Grades_{school.name}_{academic_year}_{most_common_class}_{section}_{exam_type}.csv"
                    grades_path = f"school_results/{school.id}/{academic_year}/{grades_filename}"
                    
                    print(f"Saving grade results to: {grades_path}")
                    final_grades.to_csv('temp_grades.csv', index=False)
                    with open('temp_grades.csv', 'rb') as f:
                        saved_grades = default_storage.save(grades_path, ContentFile(f.read()))
                    grades_path = saved_grades
                    
                    # Clean up
                    print("Cleaning up temporary files...")
                    os.remove('temp_grades.csv')
                    if os.path.exists("temp_grade.csv"):
                        os.remove("temp_grade.csv")
                    if os.path.exists(tmp.name):
                        os.unlink(tmp.name)
                        
                except Exception as e:
                    print(f"Error in grade processing: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    # Continue with successful account creation but note the grade calculation error
                    grade_error = str(e)
            else:
                print(f"Skipping percentile and grade calculation for board exam")

            print(f"Processing complete for {exam_type}")
            
            # Even if grade calculation fails, return success if accounts were processed
            return {
                "success": True,
                "raw_marks_path": raw_marks_file_path,  # Add raw marks file path
                "percentile_path": percentile_path,
                "grades_path": grades_path,
                "total_students": len(student_info),
                "created_accounts": created_accounts,
                "existing_accounts": existing_accounts,
                "error_records": error_records,
                "grade_calculation_error": grade_error
            }

        except Exception as e:
            print(f"Critical error in process_file: {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                "success": False,
                "error": str(e)
            }
    
    def generate_unique_registration_number(self, school, roll_number, student_id, passout_year):
        """Generate a unique registration number for student during CSV import"""
        # Extract first letter of each word from school name
        school_code = ''.join([word[0].upper() for word in school.name.split() if word])
        
        # If school code is too short, use the first 3 letters
        if len(school_code) <= 2:
            school_code = school.name[:3].upper()
        
        # Last two digits of passout year
        year_code = str(passout_year)[-2:]
        
        # Get a unique identifier based on roll number or student ID
        if roll_number:
            roll_code = str(roll_number).zfill(3)
        else:
            import random
            random_suffix = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=2))
            roll_code = f"{student_id:03d}{random_suffix}"
        
        # Combine to create registration number
        registration_number = f"{school_code}{year_code}{roll_code}"
        
        # Ensure the registration number is unique
        counter = 1
        original_reg_no = registration_number
        while Student.objects.filter(registration_no=registration_number).exists():
            # Add an incremental suffix if there's a collision
            registration_number = f"{original_reg_no}-{counter}"
            counter += 1
        
        return registration_number

    def post(self, request):
        serializer = ProcessResultsSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Get school from authenticated user
            school = request.user.school_admin
            
            pre_board_1_file = request.FILES['pre_board_1']
            pre_board_2_file = request.FILES['pre_board_2']
            half_yearly_file = request.FILES.get('half_yearly', None)
            board_file = request.FILES.get('board', None)  # Get board file
            
            section = serializer.validated_data.get('section', 'A')
            academic_year = serializer.validated_data['academic_year']
            default_class = 10  # Default class to use if not specified in CSV

            # Map new parameter names to old file naming convention
            param_to_filename = {
                'pre_board_1': 'pretest1',
                'pre_board_2': 'pretest2',
                'half_yearly': 'half_yearly',
                'board': 'board'  # Add board mapping
            }

            # Process all files
            results = {
                "pre_board_1": self.process_file(
                    pre_board_1_file, school, param_to_filename['pre_board_1'], section, academic_year, default_class=default_class
                ),
                "pre_board_2": self.process_file(
                    pre_board_2_file, school, param_to_filename['pre_board_2'], section, academic_year, default_class=default_class
                )
            }
            
            if half_yearly_file:
                results["half_yearly"] = self.process_file(
                    half_yearly_file, school, param_to_filename['half_yearly'], section, academic_year, default_class=default_class
                )
            
            # Process board file if provided - now using process_file method
            if board_file:
                results["board"] = self.process_file(
                    board_file, school, param_to_filename['board'], section, academic_year, default_class=default_class
                )

            # Check for any errors
            errors = {}
            for exam_type, result in results.items():
                if not result.get("success", False):
                    errors[exam_type] = result.get("error")
            
            if errors:
                return Response({
                    "error": "Some files could not be processed",
                    "details": errors
                }, status=status.HTTP_400_BAD_REQUEST)

            # Determine if we're processing a previous year
            current_year = now().year
            is_previous_year = academic_year < current_year

            # Create or update SchoolStudentResults record
            try:
                # Try to get existing record
                results_obj = SchoolStudentResults.objects.get(school=school, year=academic_year)
            except SchoolStudentResults.DoesNotExist:
                # Create new record
                results_obj = SchoolStudentResults(
                    school=school,
                    year=academic_year
                )
                # Set processing mode for new records
                results_obj._processing_mode = True

            # Update result fields - now using grades_path for consistency
            if results["pre_board_1"].get("success"):
                # Use grades_path if available, otherwise raw_marks_path
                file_path = results["pre_board_1"].get("grades_path") or results["pre_board_1"].get("raw_marks_path")
                results_obj.pre_board_1_result = file_path
            
            if results["pre_board_2"].get("success"):
                # Use grades_path if available, otherwise raw_marks_path
                file_path = results["pre_board_2"].get("grades_path") or results["pre_board_2"].get("raw_marks_path")
                results_obj.pre_board_2_result = file_path
            
            if "half_yearly" in results and results["half_yearly"].get("success"):
                # Use grades_path if available, otherwise raw_marks_path
                file_path = results["half_yearly"].get("grades_path") or results["half_yearly"].get("raw_marks_path")
                results_obj.half_yearly_result = file_path
            
            # Store board file - only raw_marks_path since no grades are calculated
            if "board" in results and results["board"].get("success"):
                results_obj.board_result = results["board"].get("raw_marks_path")
            
            # Always use processing mode for uploads - validation will be done when finalizing results
            results_obj._processing_mode = True
            results_obj.save()

            # Format the response data
            response_data = {
                "message": "Results processed and student accounts created successfully",
                "results_summary": {
                    "pre_board_1": {
                        "total_students": results["pre_board_1"].get("total_students", 0),
                        "raw_marks_file": results["pre_board_1"].get("raw_marks_path", ""),
                        "percentile_file": results["pre_board_1"].get("percentile_path", ""),
                        "grades_file": results["pre_board_1"].get("grades_path", ""),
                        "accounts_created": len(results["pre_board_1"].get("created_accounts", [])),
                        "existing_accounts": len(results["pre_board_1"].get("existing_accounts", []))
                    },
                    "pre_board_2": {
                        "total_students": results["pre_board_2"].get("total_students", 0),
                        "raw_marks_file": results["pre_board_2"].get("raw_marks_path", ""),
                        "percentile_file": results["pre_board_2"].get("percentile_path", ""),
                        "grades_file": results["pre_board_2"].get("grades_path", ""),
                        "accounts_created": len(results["pre_board_2"].get("created_accounts", [])),
                        "existing_accounts": len(results["pre_board_2"].get("existing_accounts", []))
                    },
                    "half_yearly": half_yearly_file and results.get("half_yearly", {}).get("success") and {
                        "total_students": results["half_yearly"].get("total_students", 0),
                        "raw_marks_file": results["half_yearly"].get("raw_marks_path", ""),
                        "percentile_file": results["half_yearly"].get("percentile_path", ""),
                        "grades_file": results["half_yearly"].get("grades_path", ""),
                        "accounts_created": len(results["half_yearly"].get("created_accounts", [])),
                        "existing_accounts": len(results["half_yearly"].get("existing_accounts", []))
                    },
                    # Board section - only raw file, no percentile/grades
                    "board": board_file and results.get("board", {}).get("success") and {
                        "total_students": results["board"].get("total_students", 0),
                        "raw_marks_file": results["board"].get("raw_marks_path", ""),
                        "accounts_created": len(results["board"].get("created_accounts", [])),
                        "existing_accounts": len(results["board"].get("existing_accounts", []))
                    },
                    "section": section,
                    "academic_year": academic_year
                },
                "created_accounts": {
                    "pre_board_1": results["pre_board_1"].get("created_accounts", []),
                    "pre_board_2": results["pre_board_2"].get("created_accounts", []),
                    "half_yearly": half_yearly_file and results.get("half_yearly", {}).get("created_accounts", []),
                    "board": board_file and results.get("board", {}).get("created_accounts", [])
                }
            }

            # Add warning for previous year without board result
            if is_previous_year and not results_obj.board_result:
                response_data["warnings"] = ["Processing previous year data without board result. Board result will be required for final submission."]

            # Add error summary if there were any errors
            if any(result.get("error_records", []) for result in results.values()):
                response_data["error_summary"] = {
                    exam_type: result.get("error_records", [])
                    for exam_type, result in results.items()
                    if result.get("error_records")
                }

            return Response(response_data, status=status.HTTP_200_OK)
        
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response({
                "error": str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class StudentResultsListView(APIView):
    """
    API to list all available result files for a school or student
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(
        operation_description="List all available result files",
        manual_parameters=[
            openapi.Parameter(
                'exam_type', openapi.IN_QUERY, 
                description="Filter by exam type (pretest1, pretest2, half_yearly)", 
                type=openapi.TYPE_STRING, required=False
            ),
            openapi.Parameter(
                'academic_year', openapi.IN_QUERY, 
                description="Filter by academic year", 
                type=openapi.TYPE_INTEGER, required=False
            ),
            openapi.Parameter(
                'section', openapi.IN_QUERY, 
                description="Filter by section", 
                type=openapi.TYPE_STRING, required=False
            )
        ],
        responses={
            200: StudentResultsListSerializer(many=True),
            400: 'Bad Request',
            404: 'No results found'
        }
    )
    def get(self, request, *args, **kwargs):
        """
        List all available result files for the current user
        """
        filter_serializer = ResultFilterSerializer(data=request.query_params)
        if not filter_serializer.is_valid():
            return Response(filter_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        filters = {}
        
        # Add filters if provided
        if 'exam_type' in filter_serializer.validated_data:
            filters['exam_type'] = filter_serializer.validated_data['exam_type']
        
        if 'academic_year' in filter_serializer.validated_data:
            filters['year'] = filter_serializer.validated_data['academic_year']
        
        # Handle different user roles
        if hasattr(request.user, 'school_admin'):
            # For school admin, get all results for their school
            school = request.user.school_admin
            results = SchoolStudentResults.objects.filter(school=school, **filters)
        elif hasattr(request.user, 'student'):
            # For students, get results for their school
            student = request.user.student
            results = SchoolStudentResults.objects.filter(school=student.school, **filters)
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        if not results.exists():
            return Response(
                {"error": "No results found matching the criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Format results
        formatted_results = []
        for result in results:
            # Add pretest1 if it exists
            if result.pretest1_result:
                section = self._extract_section_from_path(result.pretest1_result)
                formatted_results.append({
                    'exam_type': 'pretest1',
                    'academic_year': result.year,
                    'section': section,
                    'file_path': result.pretest1_result
                })
            
            # Add pretest2 if it exists
            if result.pretest2_result:
                section = self._extract_section_from_path(result.pretest2_result)
                formatted_results.append({
                    'exam_type': 'pretest2',
                    'academic_year': result.year,
                    'section': section,
                    'file_path': result.pretest2_result
                })
            
            # Add half_yearly if it exists
            if result.half_yearly_result:
                section = self._extract_section_from_path(result.half_yearly_result)
                formatted_results.append({
                    'exam_type': 'half_yearly',
                    'academic_year': result.year,
                    'section': section,
                    'file_path': result.half_yearly_result
                })
        
        # Filter by section if provided
        if 'section' in filter_serializer.validated_data:
            section = filter_serializer.validated_data['section']
            formatted_results = [r for r in formatted_results if r['section'] == section]
        
        # If no results after filtering
        if not formatted_results:
            return Response(
                {"error": "No results found matching the criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        serializer = StudentResultsListSerializer(formatted_results, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def _extract_section_from_path(self, file_path):
        """
        Extract section from file path
        Format: Grades_{school.name}_{academic_year}_{class}_{section}_{exam_type}.csv
        """
        try:
            filename = os.path.basename(file_path)
            parts = filename.split('_')
            if len(parts) >= 4:
                return parts[-2]  # Section should be the second-to-last part
            return "Unknown"  # Default if parsing fails
        except Exception:
            return "Unknown"


class StudentPercentileView(APIView):
    """
    API to get student percentiles
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Get student percentiles",
        manual_parameters=[
            openapi.Parameter(
                'exam_type', openapi.IN_QUERY, 
                description="Exam type (pretest1, pretest2, half_yearly, board)", 
                type=openapi.TYPE_STRING, required=True
            ),
            openapi.Parameter(
                'academic_year', openapi.IN_QUERY, 
                description="Academic year", 
                type=openapi.TYPE_INTEGER, required=True
            ),
            openapi.Parameter(
                'section', openapi.IN_QUERY, 
                description="Section (e.g., 'A')", 
                type=openapi.TYPE_STRING, required=False
            ),
            openapi.Parameter(
                'roll_number', openapi.IN_QUERY, 
                description="Filter by student roll number", 
                type=openapi.TYPE_INTEGER, required=False
            )
        ],
        responses={
            200: StudentPercentileSerializer(many=True),
            400: 'Bad Request',
            404: 'No results found'
        }
    )
    def get(self, request, *args, **kwargs):
        """Get student percentiles based on query parameters"""
        # Validate parameters
        exam_type = request.query_params.get('exam_type')
        if not exam_type or exam_type not in ['pre_board_1', 'pre_board_2', 'half_yearly', 'board', 'pretest1', 'pretest2']:
            return Response(
                {"error": "Invalid or missing exam_type parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        academic_year = request.query_params.get('academic_year')
        if not academic_year or not academic_year.isdigit():
            return Response(
                {"error": "Invalid or missing academic_year parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        academic_year = int(academic_year)
        
        section = request.query_params.get('section')
        roll_number = request.query_params.get('roll_number')
        
        # Map old parameter names to new field names in model
        file_field_mapping = {
            'pretest1': 'pre_board_1_result',
            'pretest2': 'pre_board_2_result', 
            'pre_board_1': 'pre_board_1_result',
            'pre_board_2': 'pre_board_2_result',
            'half_yearly': 'half_yearly_result',
            'board': 'board_result'
        }
        
        # Get result file path based on user role and permissions
        file_path = None
        school = None
        
        if hasattr(request.user, 'school_admin'):
            # School admin can see all students' results
            school = request.user.school_admin
            result = SchoolStudentResults.objects.filter(
                school=school, 
                year=academic_year
            ).first()
            
            if not result:
                return Response(
                    {"error": "No results found for the specified criteria"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get the file using the mapped field name
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name)
        
        elif hasattr(request.user, 'student'):
            # Students can only see their own results
            student = request.user.student
            school = student.school
            roll_number = student.roll_number  # Override roll_number with student's own
            
            result = SchoolStudentResults.objects.filter(
                school=student.school, 
                year=academic_year
            ).first()
            
            if not result:
                return Response(
                    {"error": "No results found for the specified criteria"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get the file using the mapped field name
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name)
        
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if file exists
        if not file_path:
            return Response(
                {"error": f"No {exam_type} results found for the specified criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if section matches if provided
        if section and section not in file_path:
            # Find an alternative file with the right section if it exists
            if hasattr(request.user, 'school_admin'):
                school = request.user.school_admin
                all_results = SchoolStudentResults.objects.filter(
                    school=school, 
                    year=academic_year
                )
                
                for alt_result in all_results:
                    field_name = file_field_mapping[exam_type]
                    alt_file_path = getattr(alt_result, field_name)
                    
                    if alt_file_path and section in alt_file_path:
                        file_path = alt_file_path
                        break
            
            # If still no match
            if section not in file_path:
                return Response(
                    {"error": f"No {exam_type} results found for section {section}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        # For board exam type, check if we should show predicted or actual results
        current_year = now().year
        if exam_type == 'board':
            if academic_year == current_year:
                # Current year - redirect to predicted board results
                return Response(
                    {"error": "For current year board results, please use the board predictions API endpoint"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                # Previous years - show actual board results (Raw file)
                # For board exams, we want to show the Raw file, not percentile
                if hasattr(file_path, 'path'):
                    file_path_str = file_path.path
                elif hasattr(file_path, 'name'):
                    file_path_str = file_path.name
                else:
                    file_path_str = str(file_path)
                
                # Board results are stored as Raw files, so we read them directly
                percentile_path_str = file_path_str
        else:
            # Get percentile file path (convert grades path to percentile path if needed)
            if 'Grades_' in file_path:
                percentile_path = file_path.replace('Grades_', 'Percentile_')
            else:
                percentile_path = file_path

            # Convert FieldFile to string path
            if hasattr(percentile_path, 'path'):
                percentile_path_str = percentile_path.path
            elif hasattr(percentile_path, 'name'):
                percentile_path_str = percentile_path.name
            else:
                percentile_path_str = str(percentile_path)

        # Read percentile file
        try:
            with default_storage.open(percentile_path_str, 'rb') as f:
                df = pd.read_csv(f)
                
                # Clean column names
                df.columns = df.columns.str.strip()
                
                # For non-board exams, check if this is actually a grades file instead of a percentile file
                if exam_type != 'board':
                    if ('Literature' in df.columns and 
                        len(df) > 0 and 
                        isinstance(df['Literature'].iloc[0], str) if not pd.isna(df['Literature'].iloc[0]) else False):
                        
                        print(f"Detected grades file, need to find corresponding percentile file")
                        percentile_path_str = find_corresponding_file(percentile_path_str, 'Grades', 'Percentile')
                        print(f"Looking for percentile file at: {percentile_path_str}")
                        
                        try:
                            with default_storage.open(percentile_path_str, 'rb') as pf:
                                df = pd.read_csv(pf)
                                df.columns = df.columns.str.strip()
                                print(f"Successfully loaded percentile file: {percentile_path_str}")
                        except FileNotFoundError:
                            return Response(
                                {"error": "Percentile file not found. Only grade data is available."}, 
                                status=status.HTTP_404_NOT_FOUND
                            )
                
                # Make sure the columns we need exist
                required_columns = ['Roll Number', 'Name', 'Literature', 'Grammer', 'History', 
                                'Geography', 'Math', 'Biology', 'Physics', 'Chemistry']
                missing_columns = [col for col in required_columns if col not in df.columns]
                
                if missing_columns:
                    return Response(
                        {"error": f"Missing required columns in data file: {', '.join(missing_columns)}"}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
                
                # Handle empty DataFrame
                if df.empty:
                    return Response(
                        {"error": "No data found in the result file"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Convert numeric columns for non-board exams
                if exam_type != 'board':
                    numeric_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                                    'Math', 'Biology', 'Physics', 'Chemistry']
                    for col in numeric_columns:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                
                # Filter by roll number if provided
                if roll_number:
                    df = df[df['Roll Number'] == int(roll_number)]
                    if df.empty:
                        return Response(
                            {"error": f"No results found for roll number {roll_number}"}, 
                            status=status.HTTP_404_NOT_FOUND
                        )
                
                # Add student IDs to the results
                students_map = {}
                for index, row in df.iterrows():
                    # Get roll_number from the current row
                    row_roll_number = row['Roll Number']
                    
                    # Try to get the student ID from the database
                    try:
                        student = Student.objects.get(
                            school=school,
                            roll_number=row_roll_number,
                            student_class=row['Class'] if 'Class' in row else None
                        )
                        students_map[row_roll_number] = student.id
                    except Student.DoesNotExist:
                        # Try without class filter if first query fails
                        try:
                            student = Student.objects.get(
                                school=school,
                                roll_number=row_roll_number
                            )
                            students_map[row_roll_number] = student.id
                        except Student.DoesNotExist:
                            students_map[row_roll_number] = None
                    except Student.MultipleObjectsReturned:
                        # If multiple students found, get the most recent one
                        student = Student.objects.filter(
                            school=school,
                            roll_number=row_roll_number
                        ).order_by('-id').first()
                        students_map[row_roll_number] = student.id if student else None
                
                # Prepare data for serialization
                results = df.to_dict('records')
                
                # Add the ID to each row in the results
                for result in results:
                    result['id'] = students_map.get(result['Roll Number'])
                
                # For board exams, we're returning raw marks, not percentiles
                if exam_type == 'board':
                    # Create a custom serializer response for board results
                    board_results = []
                    for result in results:
                        board_result = {
                            'id': result.get('id'),
                            'roll_number': result['Roll Number'],
                            'name': result['Name'],
                            'literature': result['Literature'],
                            'grammer': result['Grammer'],
                            'history': result['History'],
                            'geography': result['Geography'],
                            'math': result['Math'],
                            'biology': result['Biology'],
                            'physics': result['Physics'],
                            'chemistry': result['Chemistry'],
                            'class_field': result.get('Class', None)
                        }
                        board_results.append(board_result)
                    return Response(board_results, status=status.HTTP_200_OK)
                else:
                    # Serializer will handle mapping for percentile data
                    serializer = StudentPercentileSerializer(results, many=True)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                    
        except FileNotFoundError:
            return Response(
                {"error": "Result file not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error reading result file: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class StudentGradeView(APIView):
    """
    API to get student grades
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Get student grades",
        manual_parameters=[
            openapi.Parameter(
                'exam_type', openapi.IN_QUERY, 
                description="Exam type (pretest1, pretest2, half_yearly, board)", 
                type=openapi.TYPE_STRING, required=True
            ),
            openapi.Parameter(
                'academic_year', openapi.IN_QUERY, 
                description="Academic year", 
                type=openapi.TYPE_INTEGER, required=True
            ),
            openapi.Parameter(
                'section', openapi.IN_QUERY, 
                description="Section (e.g., 'A')", 
                type=openapi.TYPE_STRING, required=False
            ),
            openapi.Parameter(
                'roll_number', openapi.IN_QUERY, 
                description="Filter by student roll number", 
                type=openapi.TYPE_INTEGER, required=False
            )
        ],
        responses={
            200: StudentGradeSerializer(many=True),
            400: 'Bad Request',
            404: 'No results found'
        }
    )
    def get(self, request, *args, **kwargs):
        """Get student grades based on query parameters"""
        # Validate parameters
        exam_type = request.query_params.get('exam_type')
        if not exam_type or exam_type not in ['pre_board_1', 'pre_board_2', 'half_yearly', 'board', 'pretest1', 'pretest2']:
            return Response(
                {"error": "Invalid or missing exam_type parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        academic_year = request.query_params.get('academic_year')
        if not academic_year or not academic_year.isdigit():
            return Response(
                {"error": "Invalid or missing academic_year parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        academic_year = int(academic_year)
        
        section = request.query_params.get('section')
        roll_number = request.query_params.get('roll_number')
        
        # Map old parameter names to new field names in model
        file_field_mapping = {
            'pretest1': 'pre_board_1_result',
            'pretest2': 'pre_board_2_result', 
            'pre_board_1': 'pre_board_1_result',
            'pre_board_2': 'pre_board_2_result',
            'half_yearly': 'half_yearly_result',
            'board': 'board_result'
        }
        
        # Get result file path based on user role and permissions
        file_path = None
        school = None
        
        if hasattr(request.user, 'school_admin'):
            # School admin can see all students' results
            school = request.user.school_admin
            result = SchoolStudentResults.objects.filter(
                school=school, 
                year=academic_year
            ).first()
            
            if not result:
                return Response(
                    {"error": "No results found for the specified criteria"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get the file using the mapped field name
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name)
        
        elif hasattr(request.user, 'student'):
            # Students can only see their own results
            student = request.user.student
            school = student.school
            roll_number = student.roll_number  # Override roll_number with student's own
            
            result = SchoolStudentResults.objects.filter(
                school=student.school, 
                year=academic_year
            ).first()
            
            if not result:
                return Response(
                    {"error": "No results found for the specified criteria"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get the file using the mapped field name
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name)
        
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if file exists
        if not file_path:
            return Response(
                {"error": f"No {exam_type} results found for the specified criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if section matches if provided
        if section and section not in file_path:
            # Find an alternative file with the right section if it exists
            if hasattr(request.user, 'school_admin'):
                school = request.user.school_admin
                all_results = SchoolStudentResults.objects.filter(
                    school=school, 
                    year=academic_year
                )
                
                for alt_result in all_results:
                    field_name = file_field_mapping[exam_type]
                    alt_file_path = getattr(alt_result, field_name)
                    
                    if alt_file_path and section in alt_file_path:
                        file_path = alt_file_path
                        break
            
            # If still no match
            if section not in file_path:
                return Response(
                    {"error": f"No {exam_type} results found for section {section}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        # For board exam type, check if we should show predicted or actual results
        current_year = now().year
        if exam_type == 'board':
            if academic_year == current_year:
                # Current year - redirect to predicted board results
                return Response(
                    {"error": "For current year board results, please use the board predictions API endpoint"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                # Previous years - show actual board results (Raw file)
                # For board exams, grades are the actual marks, not calculated grades
                if hasattr(file_path, 'path'):
                    file_path_str = file_path.path
                elif hasattr(file_path, 'name'):
                    file_path_str = file_path.name
                else:
                    file_path_str = str(file_path)
                
                # Board results are stored as Raw files, so we read them directly
                grade_path_str = file_path_str
        else:
            # Read grade file
            # Convert FieldFile to string path
            if hasattr(file_path, 'path'):
                file_path_str = file_path.path
            elif hasattr(file_path, 'name'):
                file_path_str = file_path.name
            else:
                file_path_str = str(file_path)
            
            # For non-board exams, we want grades file, not percentile
            if 'Percentile_' in file_path_str:
                grade_path_str = file_path_str.replace('Percentile_', 'Grades_')
            else:
                grade_path_str = file_path_str

        try:
            with default_storage.open(grade_path_str, 'rb') as f:
                df = pd.read_csv(f)
                
                # Clean column names
                df.columns = df.columns.str.strip()
                
                # For non-board exams, check if this is actually a percentile file instead of a grades file
                if exam_type != 'board':
                    if ('Literature' in df.columns and 
                        len(df) > 0 and 
                        isinstance(df['Literature'].iloc[0], (int, float)) if not pd.isna(df['Literature'].iloc[0]) else True):
                        # We have a percentile file but need grades
                        print(f"Detected percentile file, need to find corresponding grades file")
                        grade_path_str = find_corresponding_file(grade_path_str, 'Percentile', 'Grades')
                        print(f"Looking for grades file at: {grade_path_str}")
                        
                        try:
                            with default_storage.open(grade_path_str, 'rb') as gf:
                                df = pd.read_csv(gf)
                                df.columns = df.columns.str.strip()
                                print(f"Successfully loaded grades file: {grade_path_str}")
                        except FileNotFoundError:
                            return Response(
                                {"error": "Grade file not found. Only percentile data is available."}, 
                                status=status.HTTP_404_NOT_FOUND
                            )
                
                # Make sure the columns we need exist
                required_columns = ['Roll Number', 'Name', 'Literature', 'Grammer', 'History', 
                                'Geography', 'Math', 'Biology', 'Physics', 'Chemistry']
                missing_columns = [col for col in required_columns if col not in df.columns]
                
                if missing_columns:
                    return Response(
                        {"error": f"Missing required columns in data file: {', '.join(missing_columns)}"}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
                
                # Handle empty DataFrame
                if df.empty:
                    return Response(
                        {"error": "No data found in the result file"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Filter by roll number if provided
                if roll_number:
                    df = df[df['Roll Number'] == int(roll_number)]
                    if df.empty:
                        return Response(
                            {"error": f"No results found for roll number {roll_number}"}, 
                            status=status.HTTP_404_NOT_FOUND
                        )
                
                # Add student IDs to the results
                students_map = {}
                for index, row in df.iterrows():
                    # Get roll_number from the current row
                    row_roll_number = row['Roll Number']
                    
                    # Try to get the student ID from the database
                    try:
                        student = Student.objects.get(
                            school=school,
                            roll_number=row_roll_number,
                            student_class=row['Class'] if 'Class' in row else None
                        )
                        students_map[row_roll_number] = student.id
                    except Student.DoesNotExist:
                        # Try without class filter if first query fails
                        try:
                            student = Student.objects.get(
                                school=school,
                                roll_number=row_roll_number
                            )
                            students_map[row_roll_number] = student.id
                        except Student.DoesNotExist:
                            students_map[row_roll_number] = None
                    except Student.MultipleObjectsReturned:
                        # If multiple students found, get the most recent one
                        student = Student.objects.filter(
                            school=school,
                            roll_number=row_roll_number
                        ).order_by('-id').first()
                        students_map[row_roll_number] = student.id if student else None
                
                # Prepare data for serialization
                results = df.to_dict('records')
                
                # Add the ID to each row in the results
                for result in results:
                    result['id'] = students_map.get(result['Roll Number'])
                
                # Serializer will handle mapping
                serializer = StudentGradeSerializer(results, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
                    
        except FileNotFoundError:
            return Response(
                {"error": "Result file not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error reading result file: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class StudentStatisticsView(APIView):
    """
    API to get statistics for subject percentiles
    """
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Get statistics for subject percentiles",
        manual_parameters=[
            openapi.Parameter(
                'exam_type', openapi.IN_QUERY, 
                description="Exam type (pretest1, pretest2, half_yearly, board)", 
                type=openapi.TYPE_STRING, required=True
            ),
            openapi.Parameter(
                'academic_year', openapi.IN_QUERY, 
                description="Academic year", 
                type=openapi.TYPE_INTEGER, required=True
            ),
            openapi.Parameter(
                'section', openapi.IN_QUERY, 
                description="Section (e.g., 'A')", 
                type=openapi.TYPE_STRING, required=False
            ),
            openapi.Parameter(
                'subject', openapi.IN_QUERY, 
                description="Subject to get statistics for", 
                type=openapi.TYPE_STRING, required=False
            )
        ],
        responses={
            200: "Statistics data",
            400: 'Bad Request',
            404: 'No results found'
        }
    )
    def get(self, request, *args, **kwargs):
        """Get statistics for subject percentiles"""
        # Validate parameters
        exam_type = request.query_params.get('exam_type')
        if not exam_type or exam_type not in ['pre_board_1', 'pre_board_2', 'half_yearly', 'board', 'pretest1', 'pretest2']:
            return Response(
                {"error": "Invalid or missing exam_type parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        academic_year = request.query_params.get('academic_year')
        if not academic_year or not academic_year.isdigit():
            return Response(
                {"error": "Invalid or missing academic_year parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        academic_year = int(academic_year)
        
        section = request.query_params.get('section')
        subject = request.query_params.get('subject')
        
        # Validate subject if provided
        valid_subjects = [
            'literature', 'grammer', 'history', 'geography', 
            'math', 'biology', 'physics', 'chemistry'
        ]
        if subject and subject.lower() not in valid_subjects:
            return Response(
                {"error": f"Invalid subject. Must be one of: {', '.join(valid_subjects)}"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Map old parameter names to new field names in model
        file_field_mapping = {
            'pretest1': 'pre_board_1_result',
            'pretest2': 'pre_board_2_result', 
            'pre_board_1': 'pre_board_1_result',
            'pre_board_2': 'pre_board_2_result',
            'half_yearly': 'half_yearly_result',
            'board': 'board_result'
        }
        
        # Get percentile file path
        file_path = None
        school = request.user.school_admin
        result = SchoolStudentResults.objects.filter(
            school=school, 
            year=academic_year
        ).first()
        
        if not result:
            return Response(
                {"error": "No results found for the specified criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get the file using the mapped field name
        field_name = file_field_mapping[exam_type]
        file_path = getattr(result, field_name)
        
        # Check if file exists
        if not file_path:
            return Response(
                {"error": f"No {exam_type} results found for the specified criteria"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if section matches if provided
        if section and section not in file_path:
            # Find an alternative file with the right section
            all_results = SchoolStudentResults.objects.filter(
                school=school, 
                year=academic_year
            )
            
            for alt_result in all_results:
                field_name = file_field_mapping[exam_type]
                alt_file_path = getattr(alt_result, field_name)
                
                if alt_file_path and section in alt_file_path:
                    file_path = alt_file_path
                    break
        
        # Get file path string
        if hasattr(file_path, 'path'):
            file_path_str = file_path.path
        elif hasattr(file_path, 'name'):
            file_path_str = file_path.name
        else:
            file_path_str = str(file_path)

        # For board exam type, check if we should show predicted or actual results
        current_year = now().year
        if exam_type == 'board':
            if academic_year == current_year:
                # Current year - redirect to predicted board results
                return Response(
                    {"error": "For current year board statistics, please use the board predictions API endpoint"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                # Previous years - show actual board results statistics (Raw file)
                statistics_path_str = file_path_str
        else:
            # Get percentile file path for non-board exams
            if 'Grades_' in file_path_str:
                print(f"Detected grades file, need to find corresponding percentile file")
                statistics_path_str = find_corresponding_file(file_path_str, 'Grades', 'Percentile')
                print(f"Looking for percentile file at: {statistics_path_str}")
            else:
                statistics_path_str = file_path_str

        # Read file for statistics
        try:
            with default_storage.open(statistics_path_str, 'rb') as f:
                df = pd.read_csv(f)
                
                # Clean column names
                df.columns = df.columns.str.strip()
                
                # For non-board exams, check if this is actually a grades file instead of a percentile file
                if exam_type != 'board':
                    if ('Literature' in df.columns and 
                        len(df) > 0 and 
                        isinstance(df['Literature'].iloc[0], str)):
                        # We have a grades file but need percentiles for statistics
                        percentile_path_str = statistics_path_str.replace('Grades_', 'Percentile_')
                        try:
                            with default_storage.open(percentile_path_str, 'rb') as pf:
                                df = pd.read_csv(pf)
                                df.columns = df.columns.str.strip()
                        except FileNotFoundError:
                            return Response(
                                {"error": "Percentile file not found. Only grade data is available."}, 
                                status=status.HTTP_404_NOT_FOUND
                            )
                
                # Handle empty DataFrame
                if df.empty:
                    return Response(
                        {"error": "No data found in the result file"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Convert numeric columns for non-board exams (percentiles)
                # For board exams, these are actual marks, so we still treat them as numeric
                numeric_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                                'Math', 'Biology', 'Physics', 'Chemistry']
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                # Calculate statistics for all subjects or specified subject
                subjects = ['Literature', 'Grammer', 'History', 'Geography', 'Math', 'Biology', 'Physics', 'Chemistry']
                
                if subject:
                    # Normalize subject name (capitalize first letter)
                    subject = subject.lower().capitalize()
                    if subject in subjects:
                        subjects = [subject]
                
                # Calculate statistics for each subject
                statistics = {}
                for subj in subjects:
                    if subj in df.columns:
                        # For board exams, create different bins (mark ranges)
                        # For other exams, use percentile ranges
                        if exam_type == 'board':
                            # Create bins for mark ranges (0-100)
                            bins = list(range(0, 101, 10))  # 0, 10, 20, ..., 100
                            bin_labels = [f"{b}-{b+9}" for b in bins[:-1]] + ["100"]
                            
                            # Count values in each bin
                            hist, _ = np.histogram(df[subj], bins=bins)
                            
                            # Create formatted statistics for marks
                            subject_stats = {
                                'distribution': dict(zip(bin_labels, hist.tolist())),
                                'mean': df[subj].mean(),
                                'median': df[subj].median(),
                                'min': df[subj].min(),
                                'max': df[subj].max(),
                                'count': len(df[subj]),
                                # Count students in each mark range
                                'ranges': {
                                    'excellent': int((df[subj] >= 90).sum()),
                                    'good': int(((df[subj] >= 80) & (df[subj] < 90)).sum()),
                                    'fair': int(((df[subj] >= 60) & (df[subj] < 80)).sum()),
                                    'average': int(((df[subj] >= 40) & (df[subj] < 60)).sum()),
                                    'poor': int((df[subj] < 40).sum())
                                }
                            }
                        else:
                            # Create bins for percentile ranges
                            bins = list(range(0, 101, 10))  # 0, 10, 20, ..., 100
                            bin_labels = [f"{b}-{b+9}" for b in bins[:-1]] + ["100"]
                            
                            # Count values in each bin
                            hist, _ = np.histogram(df[subj], bins=bins)
                            
                            # Create formatted statistics for percentiles
                            subject_stats = {
                                'distribution': dict(zip(bin_labels, hist.tolist())),
                                'mean': df[subj].mean(),
                                'median': df[subj].median(),
                                'min': df[subj].min(),
                                'max': df[subj].max(),
                                'count': len(df[subj]),
                                # Count students in each percentile range
                                'ranges': {
                                    'excellent': int((df[subj] >= 90).sum()),
                                    'good': int(((df[subj] >= 80) & (df[subj] < 90)).sum()),
                                    'fair': int(((df[subj] >= 60) & (df[subj] < 80)).sum()),
                                    'average': int(((df[subj] >= 40) & (df[subj] < 60)).sum()),
                                    'poor': int((df[subj] < 40).sum())
                                }
                            }
                        
                        statistics[subj] = subject_stats
                
                return Response(statistics, status=status.HTTP_200_OK)
                    
        except FileNotFoundError:
            return Response(
                {"error": "Result file not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error reading result file: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
def find_corresponding_file(file_path, from_prefix, to_prefix):
    """
    Find the corresponding file with a different prefix (e.g., Grades_ to Percentile_)
    Handles files with random suffixes added by Django storage
    """
    import os
    from django.core.files.storage import default_storage
    
    directory = os.path.dirname(file_path)
    filename = os.path.basename(file_path)
    
    # Extract the file pattern without the random suffix
    parts = filename.split('_')
    # Replace the type prefix (first part)
    if parts and parts[0] == from_prefix:
        parts[0] = to_prefix
    else:
        # Handle case where the prefix is part of a longer string
        return file_path.replace(from_prefix + '_', to_prefix + '_')
    
    # Get the pattern to search for (without any random suffix)
    base_pattern = '_'.join(parts)
    base_pattern = base_pattern.split('.')[0]  # Remove extension
    
    if default_storage.exists(directory):
        try:
            files = list(default_storage.listdir(directory)[1])
            # Look for files that match the pattern
            for file in files:
                # Check if this file starts with the right pattern (ignoring random suffix)
                if file.startswith(base_pattern):
                    return os.path.join(directory, file)
        except Exception as e:
            print(f"Error listing directory: {str(e)}")
    
    # Fallback to direct replacement if no match is found
    return file_path.replace(from_prefix + '_', to_prefix + '_')

class GetSubjectsView(APIView):
    """
    API to get all subjects from the result CSV files
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Get list of available subjects from result files",
        responses={
            200: "List of subjects",
            404: 'No result files found'
        }
    )
    def get(self, request, *args, **kwargs):
        """
        Get list of all subjects from result files
        """
        # Define the columns that are not subjects
        non_subject_columns = [
            'Name', 'Email', 'Address', 'Roll Number', 
            'Birth Date', 'Mobile Number', 'Class', 'Section'
        ]
        
        # Find CSV files in school_results directory
        try:
            # Determine the school ID based on the user
            school_id = None
            if hasattr(request.user, 'school_admin'):
                school_id = request.user.school_admin.id
            elif hasattr(request.user, 'student'):
                school_id = request.user.student.school.id
            
            if not school_id:
                raise ValueError("Could not determine school ID")
            
            # Get all files in the school_results directory
            base_path = f'school_results/{school_id}'
            
            # Check if the directory exists
            if not default_storage.exists(base_path):
                raise FileNotFoundError(f"No school_results directory found for school {school_id}")
            
            # Find any percentile or grade CSV files
            csv_files = []
            
            # List all subdirectories (years)
            years = default_storage.listdir(base_path)[0]  # Get directories
            
            for year in years:
                year_path = f"{base_path}/{year}"
                try:
                    # Get all files in this year directory
                    files = default_storage.listdir(year_path)[1]  # Get files
                    
                    # Filter to only get CSV files
                    csv_files.extend([f"{year_path}/{file}" for file in files if file.endswith('.csv')])
                except Exception as e:
                    # Skip any directories that can't be read
                    print(f"Error reading directory {year_path}: {str(e)}")
                    continue
            
            if not csv_files:
                raise FileNotFoundError("No CSV files found in school_results directory")
            
            # Use the first CSV file to extract subject columns
            file_path = csv_files[0]
            
            with default_storage.open(file_path, 'rb') as f:
                df = pd.read_csv(f)
                
                # Clean column names
                df.columns = df.columns.str.strip()
                
                # Get all columns that are not in non_subject_columns
                subject_columns = [
                    col for col in df.columns 
                    if col not in non_subject_columns and not col.startswith('Unnamed:')
                ]
                
                # Format subjects as requested
                subjects_data = [{'label': subject, 'value': subject} for subject in subject_columns]
                
                return Response(subjects_data, status=status.HTTP_200_OK)
                
        except Exception as e:
            # Log the error
            import traceback
            traceback.print_exc()
            print(f"Error accessing CSV files: {str(e)}")
            
            # If there's an error, fall back to default subjects from your test_pretest1.csv
            default_subjects = [
                'Literature', 'Grammer', 'History', 'Geography', 
                'Math', 'Biology', 'Physics', 'Chemistry'
            ]
            
            subjects_data = [{'label': subject, 'value': subject} for subject in default_subjects]
            return Response(
                subjects_data, 
                status=status.HTTP_200_OK
            )
        
class SchoolStudentListView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def generate_registration_number(self, school, student, passout_year):
        """Generate a unique registration number for student"""
        # Extract first letter of each word from school name
        school_code = ''.join([word[0].upper() for word in school.name.split() if word])
        
        # If school code is too short, use the first 3 letters
        if len(school_code) <= 2:
            school_code = school.name[:3].upper()
        
        # Last two digits of passout year
        year_code = str(passout_year)[-2:]
        
        # Get a unique identifier for this student
        # Try using roll number first, then fall back to student ID plus random suffix
        if student.roll_number:
            roll_code = str(student.roll_number).zfill(3)
        else:
            # Use student ID and add a random suffix to ensure uniqueness
            import random
            random_suffix = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=2))
            roll_code = f"{student.id:03d}{random_suffix}"
        
        # Combine to create registration number
        registration_number = f"{school_code}{year_code}{roll_code}"
        
        # Ensure the registration number is unique
        counter = 1
        original_reg_no = registration_number
        while Student.objects.filter(registration_no=registration_number).exclude(id=student.id).exists():
            # Add an incremental suffix if there's a collision
            registration_number = f"{original_reg_no}-{counter}"
            counter += 1
        
        return registration_number
    
    def determine_passout_year(self, student):
        """Determine student's passout year based on current class"""
        from django.utils.timezone import now
        
        # If student has a "Year to be pass out" field value in CSV, return that
        # Since we don't have direct access now, we'll calculate based on class
        current_year = now().year
        
        # Default to current year if no class information
        if not student.student_class:
            return current_year
            
        # For Indian education system:
        # Class 10 students pass out in the current year
        # Class 9 students pass out next year (current year + 1)
        # Class 8 students pass out in 2 years (current year + 2)
        # And so on
        if student.student_class <= 10:
            years_to_passout = 10 - student.student_class
        else:
            # For classes above 10 (11, 12), they've already passed 10th
            years_to_passout = 0
        
        return current_year + years_to_passout
    
    def get_student_profile(self, student, request):
        """Get profile data for a single student"""
        school = student.school
        
        # Determine passout year
        passout_year = self.determine_passout_year(student)
        
        # Generate registration number if not already assigned
        if not student.registration_no:
            try:
                registration_no = self.generate_registration_number(school, student, passout_year)
                
                # Save the registration number to the student record
                student.registration_no = registration_no
                student.save(update_fields=['registration_no'])
            except Exception as e:
                print(f"Error generating registration number for student {student.id}: {str(e)}")
                # If saving fails, still return a registration number for display
                # but it won't be saved to the database
                registration_no = f"TBD-{student.id}"
        else:
            registration_no = student.registration_no
        
        # Check if student has taken any tests
        has_taken_test = False
        
        # Check for test sessions associated with this student
        test_sessions_exist = AdaptiveTestSession.objects.filter(student=student).exists()
        
        if test_sessions_exist:
            # Check if any session has responses
            test_responses_exist = AdaptiveTestResponse.objects.filter(
                session__student=student
            ).exists()
            
            # Only mark as having taken a test if there are actual responses
            has_taken_test = test_responses_exist
        
        profile = {
            'id': student.id,
            'user_id': student.user.id,
            'name': student.user.name,
            'email': student.user.email,
            'contact_number': student.contact_number or student.user.contact_number,
            'alternate_contact_number': student.alternate_contact_number,
            'class': student.student_class,
            'section': student.section,
            'roll_number': student.roll_number,
            'birth_date': student.birth_date,
            'registration_no': registration_no,
            'address': student.address,
            'avatar_url': request.build_absolute_uri(student.avatar.url) if student.avatar else None,
            'is_active': student.user.is_active,
            'joined_date': student.user.date_joined.strftime('%Y-%m-%d') if hasattr(student.user, 'date_joined') else None,
            'school_name': school.name,
            'passout_year': passout_year,
            'test_taken': has_taken_test  # New field indicating if tests have been taken
        }
        
        return profile
    
    def get(self, request, *args, **kwargs):
        """List all students in the admin's school or provide current student's profile"""
        
        # Check if user is a student
        if hasattr(request.user, 'student_profile'):
            # If user is a student, return only their profile as a single object
            try:
                student = request.user.student_profile
                print(f"Student found: ID={student.id}, User ID={student.user.id}, Email={student.user.email}")
                profile = self.get_student_profile(student, request)
                return Response(profile, status=status.HTTP_200_OK)
            except Exception as e:
                print(f"Error retrieving student profile: {str(e)}")
                import traceback
                traceback.print_exc()
                return Response(
                    {"error": "Could not retrieve student profile"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        # If user is a school admin
        elif hasattr(request.user, 'school_admin'):
            try:
                school = request.user.school_admin
                
                # Use a more robust query
                students = Student.objects.filter(school=school).select_related('user')
                
                print(f"Found {students.count()} students for school {school.id}")
                
                # Create comprehensive student profiles
                student_profiles = []
                for student in students:
                    try:
                        print(f"Processing student: ID={student.id}, User ID={student.user.id}, Email={student.user.email}")
                        profile = self.get_student_profile(student, request)
                        student_profiles.append(profile)
                    except Exception as e:
                        print(f"Error processing student {student.id}: {str(e)}")
                        import traceback
                        traceback.print_exc()
                        # Continue with the next student instead of failing the entire request
                
                return Response(student_profiles, status=status.HTTP_200_OK)
            except Exception as e:
                print(f"Error listing students: {str(e)}")
                import traceback
                traceback.print_exc()
                return Response(
                    {"error": "Could not retrieve student list"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        else:
            # User is neither a student nor a school admin
            return Response(
                {"errors": {"detail": "You do not have permission to perform this action."}}, 
                status=status.HTTP_403_FORBIDDEN
            )
    
    # Add this as a new method in SchoolStudentListView
    def get_student_by_id(self, request, student_id):
        """Get student profile by ID for debugging purposes"""
        try:
            # First try a direct query without school filter
            student = Student.objects.filter(id=student_id).select_related('user', 'school').first()
            
            if not student:
                print(f"No student found with ID {student_id}")
                return Response(
                    {"error": f"No student found with ID {student_id}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            print(f"Found student: ID={student.id}, User ID={student.user.id}, Email={student.user.email}, School={student.school.id}")
            
            profile = self.get_student_profile(student, request)
            return Response(profile, status=status.HTTP_200_OK)
        except Exception as e:
            print(f"Error retrieving student by ID {student_id}: {str(e)}")
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error retrieving student: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
class StudentProfileDetailView(APIView):
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    def determine_passout_year(self, student):
        """Determine student's passout year based on current class"""
        from django.utils.timezone import now
        
        # Default to current year if no class information
        current_year = now().year
        
        if not student.student_class:
            return current_year
            
        # For Indian education system:
        # Class 10 students pass out in the current year
        # Class 9 students pass out next year (current year + 1)
        # Class 8 students pass out in 2 years (current year + 2)
        # And so on
        if student.student_class <= 10:
            years_to_passout = 10 - student.student_class
        else:
            # For classes above 10 (11, 12), they've already passed 10th
            years_to_passout = 0
        
        return current_year + years_to_passout
    
    def generate_registration_number(self, school, student, passout_year):
        """Generate a unique registration number for student"""
        # Extract first letter of each word from school name
        school_code = ''.join([word[0].upper() for word in school.name.split() if word])
        
        # If school code is too short, use the first 3 letters
        if len(school_code) <= 2:
            school_code = school.name[:3].upper()
        
        # Last two digits of passout year
        year_code = str(passout_year)[-2:]
        
        # Get a unique identifier for this student
        # Try using roll number first, then fall back to student ID plus random suffix
        if student.roll_number:
            roll_code = str(student.roll_number).zfill(3)
        else:
            # Use student ID and add a random suffix to ensure uniqueness
            import random
            random_suffix = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=2))
            roll_code = f"{student.id:03d}{random_suffix}"
        
        # Combine to create registration number
        registration_number = f"{school_code}{year_code}{roll_code}"
        
        # Ensure the registration number is unique
        counter = 1
        original_reg_no = registration_number
        while Student.objects.filter(registration_no=registration_number).exclude(id=student.id).exists():
            # Add an incremental suffix if there's a collision
            registration_number = f"{original_reg_no}-{counter}"
            counter += 1
        
        return registration_number
    
    def get(self, request, pk, *args, **kwargs):
        """Get detailed profile for a specific student"""
        school = request.user.school_admin
        student = get_object_or_404(Student, id=pk, school=school)
        
        # Determine passout year
        passout_year = self.determine_passout_year(student)
        
        # Generate registration number if not already assigned
        if not student.registration_no:
            try:
                registration_no = self.generate_registration_number(school, student, passout_year)
                
                # Save the registration number to the student record
                student.registration_no = registration_no
                student.save(update_fields=['registration_no'])
            except Exception as e:
                print(f"Error generating registration number for student {student.id}: {str(e)}")
                # If saving fails, still return a registration number for display
                registration_no = f"TBD-{student.id}"
        else:
            registration_no = student.registration_no
        
        # Check if student has taken any tests
        has_taken_test = False
        
        # Check for test sessions associated with this student
        test_sessions_exist = AdaptiveTestSession.objects.filter(student=student).exists()
        
        if test_sessions_exist:
            # Check if any session has responses
            test_responses_exist = AdaptiveTestResponse.objects.filter(
                session__student=student
            ).exists()
            
            # Only mark as having taken a test if there are actual responses
            has_taken_test = test_responses_exist
        
        # Get student results if available
        recent_results = SchoolStudentResults.objects.filter(
            school=school,
            year=now().year
        ).first()
        
        results_data = None
        if recent_results:
            results_data = {
                # Updated field references
                'pre_board_1': recent_results.pre_board_1_result.url if recent_results.pre_board_1_result else None,
                'pre_board_2': recent_results.pre_board_2_result.url if recent_results.pre_board_2_result else None,
                'half_yearly': recent_results.half_yearly_result.url if recent_results.half_yearly_result else None,
                'board_result': recent_results.board_result.url if recent_results.board_result else None,
                'year': recent_results.year
            }
        
        # Assemble complete profile
        profile = {
            'id': student.id,
            'user_id': student.user.id,
            'name': student.user.name,
            'email': student.user.email,
            'contact_number': student.contact_number or student.user.contact_number,
            'alternate_contact_number': student.alternate_contact_number,
            'class': student.student_class,
            'section': student.section,
            'roll_number': student.roll_number,
            'birth_date': student.birth_date,
            'registration_no': registration_no,
            'address': student.address,
            'avatar_url': request.build_absolute_uri(student.avatar.url) if student.avatar else None,
            'is_active': student.user.is_active,
            'joined_date': student.user.date_joined.strftime('%Y-%m-%d') if hasattr(student.user, 'date_joined') else None,
            'recent_results': results_data,
            'school_name': school.name,
            'passout_year': passout_year,
            'test_taken': has_taken_test  # Add the test_taken field here
        }
        
        return Response(profile, status=status.HTTP_200_OK)
    
    def put(self, request, pk, *args, **kwargs):
        """Update student profile details"""
        school = request.user.school_admin
        student = get_object_or_404(Student, id=pk, school=school)
        
        # Create a serializer that allows partial updates
        serializer = serializers.StudentProfileSerializer(
            student, 
            data=request.data,
            partial=True,
            context={'request': request}
        )
        
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Student profile updated successfully'}, status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class StudentAverageGradesView(APIView):
    """
    API to get average grades across multiple exams for a student
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get_grade_numeric_value(self, grade):
        """Convert letter grades or descriptive grades to numeric values for averaging"""
        if not grade or pd.isna(grade):
            return 0
            
        # Convert to string in case it's a different type
        grade_str = str(grade).strip().upper()
        
        # Map for letter grades
        letter_grade_map = {
            'A+': 10,
            'A': 9,
            'B+': 8,
            'B': 7,
            'C+': 6,
            'C': 5,
            'D+': 4,
            'D': 3,
            'E': 2,
            'F': 1
        }
        
        # Map for descriptive grades
        descriptive_grade_map = {
            'EXCELLENT': 9,
            'GOOD': 7.5,
            'FAIR': 6.5,  # Added Fair grade
            'AVERAGE': 5.5,
            'POOR': 4,
            'FAIL': 1
        }
        
        # Check if it's a letter grade
        if grade_str in letter_grade_map:
            return letter_grade_map[grade_str]
        
        # Check if it's a descriptive grade
        if grade_str in descriptive_grade_map:
            return descriptive_grade_map[grade_str]
        
        # Try to handle other grade formats
        if 'EXCELLENT' in grade_str:
            return 9
        elif 'GOOD' in grade_str:
            return 7.5
        elif 'FAIR' in grade_str:  # Added Fair check
            return 6.5
        elif 'AVERAGE' in grade_str:
            return 5.5
        elif 'POOR' in grade_str:
            return 4
        elif 'FAIL' in grade_str:
            return 1
        
        # If we can't determine the grade, return 0
        print(f"Unknown grade format: {grade_str}")
        return 0
    
    def get_average_grade(self, numeric_values):
        """Convert average numeric value to descriptive grade"""
        if not numeric_values:
            return 'N/A'
            
        avg = sum(numeric_values) / len(numeric_values)
        
        if avg >= 9.0:
            return 'Excellent'
        elif avg >= 7.5:
            return 'Good'
        elif avg >= 6.0:
            return 'Fair'  # Added Fair grade
        elif avg >= 5.0:
            return 'Average'
        elif avg >= 4.0:
            return 'Poor'
        else:
            return 'Fail'
    
    def get_student_grades(self, student, academic_year, exam_type=None):
        """Retrieve grades for a specific student from a specific exam"""
        school = student.school
        print(f"Looking for {exam_type} results for student {student.id} in year {academic_year}")
        
        result = SchoolStudentResults.objects.filter(
            school=school, 
            year=academic_year
        ).first()
        
        if not result:
            print(f"No results found for school {school.id} in year {academic_year}")
            return None
        
        # Map old parameter names to new field names in model
        file_field_mapping = {
            'pretest1': 'pre_board_1_result',
            'pretest2': 'pre_board_2_result', 
            'pre_board_1': 'pre_board_1_result',
            'pre_board_2': 'pre_board_2_result',
            'half_yearly': 'half_yearly_result'
        }
        
        # Get the appropriate file path based on exam type
        file_path = None
        if exam_type in file_field_mapping:
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name, None)
        else:
            print(f"Invalid exam type: {exam_type}")
            return None
            
        print(f"Found file path: {file_path}")
        
        # Ensure file path is in correct format
        if hasattr(file_path, 'path'):
            file_path_str = file_path.path
        elif hasattr(file_path, 'name'):
            file_path_str = file_path.name
        else:
            file_path_str = str(file_path)
            
        print(f"Using file path: {file_path_str}")
        
        # Make sure we're using the grades file, not percentile
        if 'Percentile_' in file_path_str:
            new_path = file_path_str.replace('Percentile_', 'Grades_')
            print(f"Switching to grades file: {new_path}")
            file_path_str = new_path
            
        try:
            # Check if file exists
            if not default_storage.exists(file_path_str):
                print(f"File does not exist: {file_path_str}")
                return None
                
            # Read the grades CSV
            with default_storage.open(file_path_str, 'rb') as f:
                print(f"Successfully opened file")
                df = pd.read_csv(f)
                df.columns = df.columns.str.strip()
                
                print(f"CSV columns: {df.columns.tolist()}")
                print(f"Looking for student with roll number: {student.roll_number}")
                
                # Find the student by roll number
                if student.roll_number:
                    student_row = df[df['Roll Number'] == student.roll_number]
                    if student_row.empty:
                        print(f"Student with roll number {student.roll_number} not found in CSV")
                        # Try looking by name as fallback
                        student_row = df[df['Name'].str.strip().str.lower() == student.user.name.strip().lower()]
                        if student_row.empty:
                            print(f"Student with name {student.user.name} not found in CSV either")
                            return None
                        else:
                            print(f"Found student by name")
                else:
                    # Try looking by name if no roll number
                    student_row = df[df['Name'].str.strip().str.lower() == student.user.name.strip().lower()]
                    if student_row.empty:
                        print(f"Student with name {student.user.name} not found in CSV")
                        return None
                    else:
                        print(f"Found student by name")
                        
                # Get the grades for this student
                grade_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                                'Math', 'Biology', 'Physics', 'Chemistry']
                
                student_grades = {}
                for col in grade_columns:
                    if col in df.columns:
                        value = student_row[col].iloc[0]
                        student_grades[col] = value
                        print(f"Found grade for {col}: {value}")
                    else:
                        print(f"Column {col} not found in CSV")
                        
                return student_grades
        except Exception as e:
            print(f"Error reading grade file: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
            
        return None
    
    def get(self, request, *args, **kwargs):
        """
        Get average grades across multiple exams
        """
        # Get current academic year
        from django.utils.timezone import now
        academic_year = int(request.query_params.get('academic_year', now().year))
        
        # For students, we only show their own grades
        if hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            # Process single student
            return self.get_student_average_grades(student, academic_year)
        elif hasattr(request.user, 'school_admin'):
            # For school admins
            if 'student_id' in request.query_params:
                # If student_id is provided, show that specific student
                try:
                    student_id = int(request.query_params.get('student_id'))
                    student = get_object_or_404(Student, id=student_id, school=request.user.school_admin)
                    return self.get_student_average_grades(student, academic_year)
                except (ValueError, TypeError):
                    return Response(
                        {"error": "Invalid student_id parameter"}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
            else:
                # If no student_id is provided, show all students in the school
                school = request.user.school_admin
                students = Student.objects.filter(school=school).select_related('user')
                
                if not students.exists():
                    return Response(
                        {"error": "No students found in this school"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Process all students
                all_student_grades = []
                for student in students:
                    try:
                        student_grades = self.get_student_average_grades(student, academic_year, include_response=False)
                        if student_grades:  # Only add if grades were found
                            all_student_grades.append(student_grades)
                    except Exception as e:
                        print(f"Error processing grades for student {student.id}: {str(e)}")
                        # Continue with next student
                
                if not all_student_grades:
                    return Response(
                        {"error": "No grade data found for any students"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                    
                return Response(all_student_grades, status=status.HTTP_200_OK)
        else:
            return Response(
                {"error": "User is neither a student nor a school admin"}, 
                status=status.HTTP_403_FORBIDDEN
            )

    def get_student_average_grades(self, student, academic_year, include_response=True):
        """Process and return average grades for a single student"""
        # Get grades from all three exam types
        pretest1_grades = self.get_student_grades(student, academic_year, 'pretest1')
        pretest2_grades = self.get_student_grades(student, academic_year, 'pretest2')
        half_yearly_grades = self.get_student_grades(student, academic_year, 'half_yearly')
        
        if not pretest1_grades and not pretest2_grades and not half_yearly_grades:
            if include_response:
                return Response(
                    {"error": f"No grades found for student {student.id}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            return None
            
        # Combine and average the grades
        subject_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                        'Math', 'Biology', 'Physics', 'Chemistry']
        
        average_grades = {}
        for subject in subject_columns:
            # Collect all available grades for this subject
            subject_grades = []
            
            if pretest1_grades and subject in pretest1_grades and pretest1_grades[subject]:
                grade_value = self.get_grade_numeric_value(pretest1_grades[subject])
                if grade_value > 0:  # Only include valid grades
                    subject_grades.append(grade_value)
                
            if pretest2_grades and subject in pretest2_grades and pretest2_grades[subject]:
                grade_value = self.get_grade_numeric_value(pretest2_grades[subject])
                if grade_value > 0:  # Only include valid grades
                    subject_grades.append(grade_value)
                
            if half_yearly_grades and subject in half_yearly_grades and half_yearly_grades[subject]:
                grade_value = self.get_grade_numeric_value(half_yearly_grades[subject])
                if grade_value > 0:  # Only include valid grades
                    subject_grades.append(grade_value)
                
            # Calculate average
            if subject_grades:
                average_grades[subject] = self.get_average_grade(subject_grades)
            else:
                average_grades[subject] = 'N/A'
                
        # Format the response as a flattened structure
        response_data = {
            'student_id': student.id,
            'student_name': student.user.name,
            'class': student.student_class,
            'roll_number': student.roll_number,
            'school_name': student.school.name,
            'academic_year': academic_year,
            'literature': average_grades.get('Literature', 'N/A'),
            'grammar': average_grades.get('Grammer', 'N/A'),
            'history': average_grades.get('History', 'N/A'),
            'geography': average_grades.get('Geography', 'N/A'),
            'math': average_grades.get('Math', 'N/A'),
            'biology': average_grades.get('Biology', 'N/A'),
            'physics': average_grades.get('Physics', 'N/A'),
            'chemistry': average_grades.get('Chemistry', 'N/A')
        }
        
        if include_response:
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return response_data

class StudentAveragePercentilesView(APIView):
    """
    API to get average percentiles across multiple exams for a student
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get_student_percentiles(self, student, academic_year, exam_type=None):
        """Retrieve percentiles for a specific student from a specific exam"""
        school = student.school
        print(f"Looking for {exam_type} percentile results for student {student.id} in year {academic_year}")
        
        result = SchoolStudentResults.objects.filter(
            school=school, 
            year=academic_year
        ).first()
        
        if not result:
            print(f"No results found for school {school.id} in year {academic_year}")
            return None
        
        # Map old parameter names to new field names in model
        file_field_mapping = {
            'pretest1': 'pre_board_1_result',
            'pretest2': 'pre_board_2_result', 
            'pre_board_1': 'pre_board_1_result',
            'pre_board_2': 'pre_board_2_result',
            'half_yearly': 'half_yearly_result'
        }
        
        # Get the appropriate file path based on exam type
        file_path = None
        if exam_type in file_field_mapping:
            field_name = file_field_mapping[exam_type]
            file_path = getattr(result, field_name, None)
        else:
            print(f"Invalid exam type: {exam_type}")
            return None
            
        print(f"Found file path: {file_path}")
        
        # Ensure file path is in correct format
        if hasattr(file_path, 'path'):
            file_path_str = file_path.path
        elif hasattr(file_path, 'name'):
            file_path_str = file_path.name
        else:
            file_path_str = str(file_path)
            
        print(f"Using file path: {file_path_str}")
        
        # Make sure we're using the percentile file, not grades
        if 'Grades_' in file_path_str:
            new_path = file_path_str.replace('Grades_', 'Percentile_')
            print(f"Switching to percentile file: {new_path}")
            file_path_str = new_path
            
        try:
            # Check if file exists
            if not default_storage.exists(file_path_str):
                print(f"File does not exist: {file_path_str}")
                return None
                
            # Read the percentile CSV
            with default_storage.open(file_path_str, 'rb') as f:
                print(f"Successfully opened file")
                df = pd.read_csv(f)
                df.columns = df.columns.str.strip()
                
                print(f"CSV columns: {df.columns.tolist()}")
                print(f"Looking for student with roll number: {student.roll_number}")
                
                # Find the student by roll number
                if student.roll_number:
                    student_row = df[df['Roll Number'] == student.roll_number]
                    if student_row.empty:
                        print(f"Student with roll number {student.roll_number} not found in CSV")
                        # Try looking by name as fallback
                        student_row = df[df['Name'].str.strip().str.lower() == student.user.name.strip().lower()]
                        if student_row.empty:
                            print(f"Student with name {student.user.name} not found in CSV either")
                            return None
                        else:
                            print(f"Found student by name")
                else:
                    # Try looking by name if no roll number
                    student_row = df[df['Name'].str.strip().str.lower() == student.user.name.strip().lower()]
                    if student_row.empty:
                        print(f"Student with name {student.user.name} not found in CSV")
                        return None
                    else:
                        print(f"Found student by name")
                        
                # Get the percentiles for this student
                percentile_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                                'Math', 'Biology', 'Physics', 'Chemistry']
                
                student_percentiles = {}
                for col in percentile_columns:
                    if col in df.columns:
                        value = student_row[col].iloc[0]
                        student_percentiles[col] = value
                        print(f"Found percentile for {col}: {value}")
                    else:
                        print(f"Column {col} not found in CSV")
                        
                return student_percentiles
        except Exception as e:
            print(f"Error reading percentile file: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
            
        return None
        
    def get_student_average_percentiles(self, student, academic_year, include_response=True):
        """Process and return average percentiles for a single student"""
        # Get percentiles from all three exam types
        pretest1_percentiles = self.get_student_percentiles(student, academic_year, 'pretest1')
        pretest2_percentiles = self.get_student_percentiles(student, academic_year, 'pretest2')
        half_yearly_percentiles = self.get_student_percentiles(student, academic_year, 'half_yearly')
        
        if not pretest1_percentiles and not pretest2_percentiles and not half_yearly_percentiles:
            if include_response:
                return Response(
                    {"error": f"No percentile data found for student {student.id}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            return None
            
        # Combine and average the percentiles
        subject_columns = ['Literature', 'Grammer', 'History', 'Geography', 
                         'Math', 'Biology', 'Physics', 'Chemistry']
        
        average_percentiles = {}
        for subject in subject_columns:
            # Collect all available percentiles for this subject
            subject_percentiles = []
            
            if pretest1_percentiles and subject in pretest1_percentiles:
                try:
                    value = float(pretest1_percentiles[subject])
                    if not pd.isna(value):  # Skip NaN values
                        subject_percentiles.append(value)
                except (ValueError, TypeError):
                    pass
                
            if pretest2_percentiles and subject in pretest2_percentiles:
                try:
                    value = float(pretest2_percentiles[subject])
                    if not pd.isna(value):  # Skip NaN values
                        subject_percentiles.append(value)
                except (ValueError, TypeError):
                    pass
                
            if half_yearly_percentiles and subject in half_yearly_percentiles:
                try:
                    value = float(half_yearly_percentiles[subject])
                    if not pd.isna(value):  # Skip NaN values
                        subject_percentiles.append(value)
                except (ValueError, TypeError):
                    pass
                
            # Calculate average
            if subject_percentiles:
                average_percentiles[subject] = round(sum(subject_percentiles) / len(subject_percentiles), 1)
            else:
                average_percentiles[subject] = 'N/A'
                
        # Format the response as a flattened structure
        response_data = {
            'student_id': student.id,
            'student_name': student.user.name,
            'class': student.student_class,
            'roll_number': student.roll_number,
            'school_name': student.school.name,
            'academic_year': academic_year,
            'literature': average_percentiles.get('Literature', 'N/A'),
            'grammar': average_percentiles.get('Grammer', 'N/A'),
            'history': average_percentiles.get('History', 'N/A'),
            'geography': average_percentiles.get('Geography', 'N/A'),
            'math': average_percentiles.get('Math', 'N/A'),
            'biology': average_percentiles.get('Biology', 'N/A'),
            'physics': average_percentiles.get('Physics', 'N/A'),
            'chemistry': average_percentiles.get('Chemistry', 'N/A')
        }
        
        if include_response:
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return response_data
            
    def get(self, request, *args, **kwargs):
        """
        Get average percentiles across multiple exams
        """
        # Get current academic year
        from django.utils.timezone import now
        academic_year = int(request.query_params.get('academic_year', now().year))
        
        # For students, we only show their own percentiles
        if hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            # Process single student
            return self.get_student_average_percentiles(student, academic_year)
        elif hasattr(request.user, 'school_admin'):
            # For school admins
            if 'student_id' in request.query_params:
                # If student_id is provided, show that specific student
                try:
                    student_id = int(request.query_params.get('student_id'))
                    student = get_object_or_404(Student, id=student_id, school=request.user.school_admin)
                    return self.get_student_average_percentiles(student, academic_year)
                except (ValueError, TypeError):
                    return Response(
                        {"error": "Invalid student_id parameter"}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
            else:
                # If no student_id is provided, show all students in the school
                school = request.user.school_admin
                students = Student.objects.filter(school=school).select_related('user')
                
                if not students.exists():
                    return Response(
                        {"error": "No students found in this school"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Process all students
                all_student_percentiles = []
                for student in students:
                    try:
                        student_percentiles = self.get_student_average_percentiles(student, academic_year, include_response=False)
                        if student_percentiles:  # Only add if percentiles were found
                            all_student_percentiles.append(student_percentiles)
                    except Exception as e:
                        print(f"Error processing percentiles for student {student.id}: {str(e)}")
                        # Continue with next student
                
                if not all_student_percentiles:
                    return Response(
                        {"error": "No percentile data found for any students"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                    
                return Response(all_student_percentiles, status=status.HTTP_200_OK)
        else:
            return Response(
                {"error": "User is neither a student nor a school admin"}, 
                status=status.HTTP_403_FORBIDDEN
            )

class CareerListView(APIView):
    """API endpoint that returns list of all careers for dropdown"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, *args, **kwargs):
        careers = Career.objects.all()
        serializer = CareerSerializer(careers, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class CareerStatisticsView(APIView):
    """API endpoint that returns all statistics for a specific career"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, *args, **kwargs):
        career_id = request.query_params.get('id')
        if not career_id:
            return Response(
                {"error": "Career ID is required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        try:
            career = Career.objects.get(value=career_id)
            
            # Get all statistics for this career
            statistics = {}
            for stat in career.statistics.all():
                # Round values to 2 decimal places
                rounded_values = [round(value, 2) for value in stat.values]
                
                statistics[stat.category] = {
                    'labels': stat.labels,
                    'values': rounded_values
                }
            
            # Initialize default empty lists for all fields
            response_data = {
                'careerName': career.name,
                'statistics': statistics,
                'uniqueQualities': [],
                'favoriteSubjects': [],
                'hobbies': [],
                'demandedQualities': [],
                'suggestedBooks': [],
                'suggestedAuthors': [],
                'analyticalSkills': [],
                'communicationSkills': [],
                'natureOfService': [],
                'sportsActivities': [],
                'publicEvents': [],
                'secondaryDomains': []
            }
            
            # Get additional info
            try:
                info = career.info
                
                # Map model fields to response fields
                field_mapping = {
                    'unique_qualities': 'uniqueQualities',
                    'favorite_subjects': 'favoriteSubjects',
                    'hobbies': 'hobbies',
                    'demanded_qualities': 'demandedQualities',
                    'suggested_books': 'suggestedBooks',
                    'suggested_authors': 'suggestedAuthors',
                    'analytical_skills': 'analyticalSkills',
                    'communication_skills': 'communicationSkills',
                    'nature_of_service': 'natureOfService',
                    'sports_activities': 'sportsActivities',
                    'public_events': 'publicEvents',
                    'secondary_domains': 'secondaryDomains'
                }
                
                # Update response data with all available fields
                for model_field, response_field in field_mapping.items():
                    if hasattr(info, model_field):
                        response_data[response_field] = getattr(info, model_field)
                
            except CareerInfo.DoesNotExist:
                # Keep the default empty lists if no info exists
                pass
            
            return Response(response_data, status=status.HTTP_200_OK)
        
        except Career.DoesNotExist:
            return Response(
                {"error": f"Career with ID '{career_id}' not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class StudentAvatarUpdateView(APIView):
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(
        operation_description="Upload or update student avatar",
        request_body=serializers.StudentAvatarSerializer,
        responses={
            200: "Avatar updated successfully",
            400: "Bad request"
        }
    )
    def post(self, request, *args, **kwargs):
        # Get the student profile associated with the user
        try:
            student = Student.objects.get(user=request.user)
        except Student.DoesNotExist:
            return Response(
                {"error": "Student profile not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Check if image file is provided
        if 'avatar' not in request.FILES:
            return Response(
                {"error": "No image file provided"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate the file using serializer
        serializer = serializers.StudentAvatarSerializer(data={'avatar': request.FILES['avatar']})
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # If validation passes, process the image
        try:
            # Get the file and process it
            image_file = request.FILES['avatar']
            
            # Process the image using your existing function
            processed_image = process_avatar_image(
                image_file,
                max_size=(300, 300),
                quality=85
            )
            
            # Create the file path
            file_path = f"avatars/students/{student.user.id}/{image_file.name}"
            
            # Use storage backend (works with either local or Azure)
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            
            # Save to storage
            saved_path = azure_storage.save(file_path, processed_image)
            file_url = azure_storage.url(saved_path)
            
            # Update the student model
            student.avatar = saved_path
            student.save(update_fields=['avatar'])
            
            # Return the result
            return Response({
                "message": "Avatar updated successfully",
                "avatar_url": file_url
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response(
                {"error": f"Error processing image: {str(e)}"},
                status=status.HTTP_400_BAD_REQUEST
            )

class BoardResultPredictionView(APIView):
    """
    API view for predicting board results based on existing exam data
    """
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Predict board results based on pre_board_1, pre_board_2, and half-yearly results",
        request_body=serializers.BoardResultPredictionSerializer,
        responses={
            200: "Prediction successful",
            400: "Invalid input data",
            404: "Referenced files not found",
            500: "Prediction error"
        }
    )
    def post(self, request, *args, **kwargs):
        """
        Predict board results based on pre_board_1, pre_board_2, and half-yearly results
        """
        # Import both prediction modules
        from scripts.data_science.board_results_prediction import predict_board_scores, load_models
        from scripts.data_science.debug_board_prediction import predict_board_scores_simple
        import logging
        logger = logging.getLogger(__name__)
        
        # Validate request data
        serializer = serializers.BoardResultPredictionSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # Extract validated data
        validated_data = serializer.validated_data
        academic_year = validated_data.get('academic_year')
        retrain_model = validated_data.get('retrain_model', False)
        school_id = request.user.school_admin.id
        
        # Get files from the request
        file_objects = {}
        
        # Get direct file uploads - match frontend parameter names
        if 'pre_board_1' in request.FILES:
            file_objects['pre_board_1'] = request.FILES['pre_board_1']
        if 'pre_board_2' in request.FILES:
            file_objects['pre_board_2'] = request.FILES['pre_board_2']
        if 'half_yearly' in request.FILES:
            file_objects['half_yearly'] = request.FILES['half_yearly']
        if 'board' in request.FILES:
            file_objects['board'] = request.FILES['board']
        
        # If files not directly uploaded, try to get from SchoolStudentResults
        if not all(exam_type in file_objects for exam_type in ['pre_board_1', 'pre_board_2']):
            try:
                # Find the file in the school's results
                result = SchoolStudentResults.objects.filter(
                    school_id=school_id, 
                    year=academic_year
                ).first()
                
                if result:
                    # Get the files from the database if not provided directly
                    if 'pre_board_1' not in file_objects and result.pre_board_1_result:
                        file_path = result.pre_board_1_result.path if hasattr(result.pre_board_1_result, 'path') else result.pre_board_1_result.name
                        file_objects['pre_board_1'] = file_path
                        logger.info(f"Using existing file for pre_board_1: {file_path}")
                    
                    if 'pre_board_2' not in file_objects and result.pre_board_2_result:
                        file_path = result.pre_board_2_result.path if hasattr(result.pre_board_2_result, 'path') else result.pre_board_2_result.name
                        file_objects['pre_board_2'] = file_path
                        logger.info(f"Using existing file for pre_board_2: {file_path}")
                    
                    if 'half_yearly' not in file_objects and result.half_yearly_result:
                        file_path = result.half_yearly_result.path if hasattr(result.half_yearly_result, 'path') else result.half_yearly_result.name
                        file_objects['half_yearly'] = file_path
                        logger.info(f"Using existing file for half_yearly: {file_path}")
                    
                    if 'board' not in file_objects and result.board_result:
                        file_path = result.board_result.path if hasattr(result.board_result, 'path') else result.board_result.name
                        file_objects['board'] = file_path
                        logger.info(f"Using existing file for board: {file_path}")
            except Exception as e:
                logger.error(f"Error accessing school results: {str(e)}")
                # Continue with directly uploaded files
        
        # Ensure we have all required files
        required_types = ['pre_board_1', 'pre_board_2', 'half_yearly']
        missing_files = [exam_type for exam_type in required_types if exam_type not in file_objects]
        if missing_files:
            return Response(
                {"error": f"Missing required files: {', '.join(missing_files)}"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            # First check if we have trained models available
            models, metrics = load_models(school_id=school_id)
            
            if models and not retrain_model:
                logger.info("Using pre-trained models for prediction")
                # Use the full ML prediction approach
                result = predict_board_scores(
                    half_yearly_file=file_objects.get('half_yearly'),
                    pretest1_file=file_objects.get('pre_board_1'),  # Map to function parameter
                    pretest2_file=file_objects.get('pre_board_2'),  # Map to function parameter
                    board_file=file_objects.get('board', None),
                    school_id=school_id,
                    academic_year=academic_year,
                    retrain=retrain_model
                )
            else:
                # If models aren't available or retraining is requested with board data
                if retrain_model and 'board' in file_objects:
                    logger.info("Retraining models with provided data")
                    # Train new models and make predictions
                    result = predict_board_scores(
                        half_yearly_file=file_objects.get('half_yearly'),
                        pretest1_file=file_objects.get('pre_board_1'),  # Map to function parameter
                        pretest2_file=file_objects.get('pre_board_2'),  # Map to function parameter
                        board_file=file_objects.get('board'),
                        school_id=school_id,
                        academic_year=academic_year,
                        retrain=True
                    )
                else:
                    logger.info("No trained models available - using simplified prediction approach")
                    # Fall back to simple prediction
                    result = predict_board_scores_simple(
                        half_yearly_file=file_objects.get('half_yearly'),
                        pretest1_file=file_objects.get('pre_board_1'),  # Map to function parameter
                        pretest2_file=file_objects.get('pre_board_2'),  # Map to function parameter
                        school_id=school_id,
                        academic_year=academic_year
                    )
            
            if not result.get('success', False):
                return Response(
                    {"error": result.get('error', 'Prediction failed')},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Return predictions
            return Response({
                "message": "Board result prediction completed successfully",
                "file_path": result.get('file_path'),
                "file_url": result.get('file_url', ''),
                "total_students": len(result.get('predictions', [])),
                "prediction_method": "machine_learning" if models else "rule_based",
                "subject_predictions": self.format_subject_summary(result.get('predictions')),
                "preview": self.format_preview(result.get('predictions'))
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error generating predictions: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    # These helper methods remain unchanged
    def format_subject_summary(self, predictions_df):
        """Format a summary of predictions by subject"""
        if predictions_df is None or len(predictions_df) == 0:
            return {}
            
        summary = {}
        
        # Find prediction columns
        pred_cols = [col for col in predictions_df.columns if col.startswith('predicted_board_')]
        
        # Calculate statistics for each subject
        for col in pred_cols:
            subject = col.replace('predicted_board_', '')
            
            # Calculate basic statistics
            summary[subject] = {
                'mean': round(float(predictions_df[col].mean()), 2),
                'min': int(predictions_df[col].min()),
                'max': int(predictions_df[col].max()),
                'ranges': {
                    '91-100': int((predictions_df[col] >= 91).sum()),
                    '81-90': int(((predictions_df[col] >= 81) & (predictions_df[col] <= 90)).sum()),
                    '71-80': int(((predictions_df[col] >= 71) & (predictions_df[col] <= 80)).sum()),
                    '61-70': int(((predictions_df[col] >= 61) & (predictions_df[col] <= 70)).sum()),
                    '51-60': int(((predictions_df[col] >= 51) & (predictions_df[col] <= 60)).sum()),
                    '41-50': int(((predictions_df[col] >= 41) & (predictions_df[col] <= 50)).sum()),
                    '33-40': int(((predictions_df[col] >= 33) & (predictions_df[col] <= 40)).sum()),
                    'below 33': int((predictions_df[col] < 33).sum())
                }
            }
        
        return summary
        
    def format_preview(self, predictions_df):
        """Return a preview of the first 5 students' predictions"""
        if predictions_df is None or len(predictions_df) == 0:
            return []
            
        # Get the first 5 rows for preview
        preview_df = predictions_df.head(5)
        
        # Convert to list of dictionaries for API response
        preview_list = []
        
        for _, row in preview_df.iterrows():
            student_data = {
                'name': row['Name'],
                'roll_number': row['Roll Number'],
                'predictions': {}
            }
            
            # Add predicted scores for each subject
            pred_cols = [col for col in preview_df.columns if col.startswith('predicted_board_')]
            for col in pred_cols:
                subject = col.replace('predicted_board_', '')
                student_data['predictions'][subject] = int(row[col])
                
            preview_list.append(student_data)
            
        return preview_list
    
def find_latest_file_by_pattern(directory, pattern_prefix, pattern_suffix='.csv'):
    """
    Find the latest file in a directory that matches a given pattern.
    Handles random suffixes added by Django storage.
    """
    import os
    from django.core.files.storage import default_storage
    
    if not default_storage.exists(directory):
        return None
    
    try:
        # Get all files in the directory
        _, files = default_storage.listdir(directory)
        
        # Filter files that match our pattern
        matching_files = []
        for f in files:
            if f.startswith(pattern_prefix) and f.endswith(pattern_suffix):
                matching_files.append(f)
        
        if not matching_files:
            return None
            
        # Get full paths and last modified times
        file_paths = [os.path.join(directory, f) for f in matching_files]
        file_stats = []
        
        for path in file_paths:
            try:
                modified_time = default_storage.get_modified_time(path)
                file_stats.append((path, modified_time))
            except:
                # If we can't get modified time, use current time as fallback
                file_stats.append((path, now()))
        
        # Sort by modification time (newest first)
        file_stats.sort(key=lambda x: x[1], reverse=True)
        
        # Return the most recent file
        return file_stats[0][0] if file_stats else None
    
    except Exception as e:
        import logging
        logging.error(f"Error finding latest file in {directory}: {str(e)}")
        return None

# Update the existing find_corresponding_file function
def find_corresponding_file(file_path, from_prefix, to_prefix):
    """
    Find the corresponding file with a different prefix (e.g., Grades_ to Percentile_)
    Handles files with random suffixes added by Django storage
    """
    import os
    from django.core.files.storage import default_storage
    
    directory = os.path.dirname(file_path)
    filename = os.path.basename(file_path)
    
    # Extract the file pattern without the random suffix
    parts = filename.split('_')
    
    # Replace prefix
    if parts and parts[0] == from_prefix:
        parts[0] = to_prefix
    else:
        # Handle case where prefix is in a different position or format
        new_path = file_path.replace(from_prefix + '_', to_prefix + '_')
        
        # Try direct replacement first
        if default_storage.exists(new_path):
            return new_path
            
        # If that fails, try to find the latest matching file
        directory = os.path.dirname(new_path)
        base_name = os.path.basename(new_path).split('.')[0]
        extension = os.path.splitext(filename)[1]
        
        return find_latest_file_by_pattern(directory, base_name, extension)
    
    # Reconstruct base pattern without random suffix
    # For example, from "Grades_School_2025_10_A_pre_board_1_ABC123.csv" 
    # to "Percentile_School_2025_10_A_pre_board_1"
    base_pattern = '_'.join(parts)
    base_pattern = base_pattern.split('.')[0]  # Remove extension
    extension = os.path.splitext(filename)[1]
    
    # Try to find matching file with this pattern
    matching_file = find_latest_file_by_pattern(directory, base_pattern, extension)
    if matching_file:
        return matching_file
        
    # Fallback to simple replacement if no match found
    return file_path.replace(from_prefix + '_', to_prefix + '_')

class FinalizeResultsView(APIView):
    """
    API to finalize school results (enabling validation)
    """
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    def post(self, request, *args, **kwargs):
        academic_year = request.data.get('academic_year')
        if not academic_year:
            return Response(
                {"error": "academic_year is required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        try:
            academic_year = int(academic_year)
        except ValueError:
            return Response(
                {"error": "academic_year must be a valid year"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get the results object
        try:
            school = request.user.school_admin
            results_obj = SchoolStudentResults.objects.get(
                school=school, 
                year=academic_year
            )
        except SchoolStudentResults.DoesNotExist:
            return Response(
                {"error": f"No results found for academic year {academic_year}"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Perform full validation
        results_obj._processing_mode = False
        
        try:
            results_obj.clean()  # Run validation manually
            results_obj.save()  # Save with validation
            
            return Response({
                "message": f"Results for academic year {academic_year} have been finalized successfully",
                "status": "complete",
                "academic_year": academic_year,
                "has_pre_board_1": bool(results_obj.pre_board_1_result),
                "has_pre_board_2": bool(results_obj.pre_board_2_result),
                "has_half_yearly": bool(results_obj.half_yearly_result),
                "has_board_result": bool(results_obj.board_result)
            }, status=status.HTTP_200_OK)
            
        except ValidationError as e:
            # Return validation errors
            return Response({
                "error": "Validation failed",
                "details": e.messages,
                "status": "incomplete",
                "academic_year": academic_year,
                "has_pre_board_1": bool(results_obj.pre_board_1_result),
                "has_pre_board_2": bool(results_obj.pre_board_2_result),
                "has_half_yearly": bool(results_obj.half_yearly_result),
                "has_board_result": bool(results_obj.board_result)
            }, status=status.HTTP_400_BAD_REQUEST)
        
class BoardResultPredictionDisplayView(APIView):
    """API to get predicted board results"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, *args, **kwargs):
        """Get board result predictions for students"""
        # Validate parameters
        academic_year = request.query_params.get('academic_year')
        if not academic_year or not academic_year.isdigit():
            return Response(
                {"error": "Invalid or missing academic_year parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        academic_year = int(academic_year)
        
        section = request.query_params.get('section')
        roll_number = request.query_params.get('roll_number')
        
        # Get the school
        if hasattr(request.user, 'school_admin'):
            school = request.user.school_admin
        elif hasattr(request.user, 'student'):
            student = request.user.student
            school = student.school
            roll_number = student.roll_number
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check for prediction file
        prediction_dir = f"predictions/school_{school.id}/{academic_year}"
        
        try:
            # Check if directory exists
            if not default_storage.exists(prediction_dir):
                return Response(
                    {"error": f"No prediction files found for academic year {academic_year}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # List files in directory
            try:
                _, files = default_storage.listdir(prediction_dir)
            except Exception as e:
                return Response(
                    {"error": f"Error listing prediction files: {str(e)}"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Look for prediction CSV files
            prediction_files = [f for f in files if f.lower().startswith('predicted_board_results') and f.endswith('.csv')]
            
            if not prediction_files:
                return Response(
                    {"error": f"No prediction files found for academic year {academic_year}"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Sort by creation time (newest first)
            prediction_files.sort(reverse=True)
            prediction_file = prediction_files[0]
            prediction_path = f"{prediction_dir}/{prediction_file}"
            
            # Read the prediction file
            with default_storage.open(prediction_path, 'rb') as f:
                df = pd.read_csv(f)
                
                # Clean column names
                df.columns = df.columns.str.strip()
                
                # Filter by roll number if provided
                if roll_number:
                    try:
                        roll_num = int(roll_number)
                        df = df[df['Roll Number'] == roll_num]
                        if df.empty:
                            return Response(
                                {"error": f"No predictions found for roll number {roll_number}"}, 
                                status=status.HTTP_404_NOT_FOUND
                            )
                    except ValueError:
                        return Response(
                            {"error": f"Invalid roll number: {roll_number}"}, 
                            status=status.HTTP_400_BAD_REQUEST
                        )
                
                # Map student IDs
                students_map = {}
                for index, row in df.iterrows():
                    row_roll_number = row['Roll Number']
                    try:
                        student = Student.objects.filter(
                            school=school,
                            roll_number=row_roll_number
                        ).first()
                        students_map[row_roll_number] = student.id if student else None
                    except:
                        students_map[row_roll_number] = None
                
                # Format predictions array
                predictions = []
                for _, row in df.iterrows():
                    student_data = {
                        'id': students_map.get(row['Roll Number']),
                        'roll_number': row['Roll Number'],
                        'name': row['Name'],
                    }
                    
                    # Add predicted subject scores
                    for col in df.columns:
                        if col.startswith('predicted_board_'):
                            subject_name = col.replace('predicted_board_', '').lower()
                            student_data[subject_name] = float(row[col])
                    
                    predictions.append(student_data)
                
                # Process statistics for each subject using the new format
                statistics = {}
                
                # Find all predicted columns
                subject_cols = [col for col in df.columns if col.startswith('predicted_board_')]
                
                for col in subject_cols:
                    subject = col.replace('predicted_board_', '')
                    values = df[col].dropna()
                    
                    if len(values) > 0:
                        # Create 10-point distribution bins
                        bins = list(range(0, 100, 10))  # 0, 10, 20, ..., 90
                        bin_labels = [f"{b}-{b+9}" for b in bins]  # "0-9", "10-19", etc.
                        
                        # Count values in each distribution bin
                        hist, _ = np.histogram(values, bins=bins + [100])  # Add 100 as the upper bound
                        
                        # Create qualitative ranges
                        excellent_count = int((values >= 90).sum())
                        good_count = int(((values >= 80) & (values < 90)).sum())
                        fair_count = int(((values >= 60) & (values < 80)).sum())
                        average_count = int(((values >= 40) & (values < 60)).sum())
                        poor_count = int((values < 40).sum())
                        
                        # Format statistics using the exact format requested
                        statistics[subject] = {
                            'distribution': dict(zip(bin_labels, hist.tolist())),
                            'mean': float(values.mean()),
                            'median': float(values.median()),
                            'min': int(values.min()),
                            'max': int(values.max()),
                            'count': len(values),
                            'ranges': {
                                'excellent': excellent_count,
                                'good': good_count,
                                'fair': fair_count,
                                'average': average_count,
                                'poor': poor_count
                            }
                        }
                
                # Prepare file info
                file_url = None
                try:
                    file_url = default_storage.url(prediction_path)
                except:
                    # If url method is not available
                    pass
                
                file_info = {
                    'filename': prediction_file,
                    'academic_year': academic_year,
                    'total_students': len(df),
                    'section': section,
                    'file_path': prediction_path,
                    'file_url': file_url
                }
                
                # Return complete response
                response_data = {
                    'predictions': predictions,
                    'statistics': statistics,
                    'file_info': file_info
                }
                
                return Response(response_data, status=status.HTTP_200_OK)
        
        except FileNotFoundError as e:
            return Response(
                {"error": f"File not found: {str(e)}"}, 
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error processing prediction file: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
class ResultsDisplayView(APIView):
    """
    API to fetch and display uploaded results for the dashboard
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Get uploaded exam results for display",
        manual_parameters=[
            openapi.Parameter(
                'exam_type', openapi.IN_QUERY, 
                description="Type of exam (pre_board_1, pre_board_2, half_yearly, board, pretest1, pretest2)", 
                type=openapi.TYPE_STRING, required=True
            ),
            openapi.Parameter(
                'academic_year', openapi.IN_QUERY, 
                description="Academic year of results", 
                type=openapi.TYPE_INTEGER, required=True
            ),
            openapi.Parameter(
                'roll_number', openapi.IN_QUERY, 
                description="Filter by student roll number", 
                type=openapi.TYPE_INTEGER, required=False
            )
        ],
        responses={
            200: "Results data",
            400: "Bad request",
            404: "No results found"
        }
    )
    def get(self, request, *args, **kwargs):
        # Validate parameters
        exam_type = request.query_params.get('exam_type')
        valid_exam_types = ['pre_board_1', 'pre_board_2', 'half_yearly', 'board', 'pretest1', 'pretest2']
        if not exam_type or exam_type not in valid_exam_types:
            return Response(
                {"error": "Invalid or missing exam_type parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        academic_year = request.query_params.get('academic_year')
        if not academic_year or not academic_year.isdigit():
            return Response(
                {"error": "Invalid or missing academic_year parameter"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        academic_year = int(academic_year)
        
        roll_number = request.query_params.get('roll_number')
        
        # Map parameter names to model fields
        file_field_mapping = {
            'pre_board_1': 'pre_board_1_result',
            'pretest1': 'pre_board_1_result',  # Add mapping for frontend name
            'pre_board_2': 'pre_board_2_result',
            'pretest2': 'pre_board_2_result',  # Add mapping for frontend name
            'half_yearly': 'half_yearly_result',
            'board': 'board_result'
        }
        
        # Determine user type and access permissions
        if hasattr(request.user, 'school_admin'):
            school = request.user.school_admin
        elif hasattr(request.user, 'student'):
            student = request.user.student
            school = student.school
            # If user is a student, they can only view their own results
            if not roll_number:
                roll_number = student.roll_number
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # For board exam type, check if we should show predicted or actual results
        current_year = now().year
        if exam_type == 'board' and academic_year == current_year:
            # Current year board results - redirect to predictions API
            return Response(
                {"error": "For current year board results, please use the board predictions API endpoint"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        # Find the results record
        try:
            results_obj = SchoolStudentResults.objects.get(
                school=school,
                year=academic_year
            )
        except SchoolStudentResults.DoesNotExist:
            return Response(
                {"error": f"No results found for academic year {academic_year}"}, 
                status=status.HTTP_404_NOT_FOUND
            )
            
        # Get the requested file
        field_name = file_field_mapping[exam_type]
        file_field = getattr(results_obj, field_name)
        
        if not file_field:
            return Response(
                {"error": f"No {exam_type} results found for academic year {academic_year}"}, 
                status=status.HTTP_404_NOT_FOUND
            )
            
        # Read the CSV file
        try:
            # Get file path string
            if hasattr(file_field, 'path'):
                file_path_str = file_field.path
            elif hasattr(file_field, 'name'):
                file_path_str = file_field.name
            else:
                file_path_str = str(file_field)
            
            print(f"Original file path from model: {file_path_str}")
            
            # Get the directory and filename
            directory = os.path.dirname(file_path_str)
            filename = os.path.basename(file_path_str)
            
            # Convert exam_type for file pattern matching
            exam_type_for_file = exam_type
            if exam_type == 'pretest1':
                exam_type_for_file = 'pretest1'
            elif exam_type == 'pretest2':
                exam_type_for_file = 'pretest2'
            elif exam_type == 'half_yearly':
                exam_type_for_file = 'half_yearly'
            elif exam_type == 'board':
                exam_type_for_file = 'board'
            
            # Look directly for Raw_ files matching the pattern
            raw_file_path = None
            found_raw_file = False
            
            # First, try direct name replacement if the file starts with 'Grades_'
            if 'Grades_' in filename:
                potential_raw_path = os.path.join(directory, filename.replace('Grades_', 'Raw_'))
                if default_storage.exists(potential_raw_path):
                    raw_file_path = potential_raw_path
                    found_raw_file = True
                    print(f"Found Raw file by replacing Grades_ prefix: {raw_file_path}")
            
            # If that doesn't work, look for files matching the pattern Raw_*{exam_type}*
            if not found_raw_file:
                try:
                    files_in_dir = default_storage.listdir(directory)[1]
                    for potential_file in files_in_dir:
                        if (potential_file.startswith('Raw_') and 
                            exam_type_for_file.lower() in potential_file.lower()):
                            potential_path = os.path.join(directory, potential_file)
                            raw_file_path = potential_path
                            found_raw_file = True
                            print(f"Found Raw file by scanning directory: {raw_file_path}")
                            break
                except Exception as e:
                    print(f"Error listing directory: {str(e)}")
            
            # If still not found, try hardcoded patterns based on your screenshot
            if not found_raw_file:
                # Based on your screenshot - direct mapping
                raw_file_mapping = {
                    'pretest1': 'Raw_Test_School_2025_10_A_pretest1.csv',
                    'pretest2': 'Raw_Test_School_2025_10_A_pretest2.csv',
                    'half_yearly': 'Raw_Test_School_2025_10_A_half_yearly.csv',
                    'pre_board_1': 'Raw_Test_School_2025_10_A_pretest1.csv',
                    'pre_board_2': 'Raw_Test_School_2025_10_A_pretest2.csv',
                    'board': f'Raw_{school.name}_{academic_year}_10_A_board.csv'
                }
                
                if exam_type in raw_file_mapping:
                    potential_raw_path = os.path.join(directory, raw_file_mapping[exam_type])
                    if default_storage.exists(potential_raw_path):
                        raw_file_path = potential_raw_path
                        found_raw_file = True
                        print(f"Found Raw file using hardcoded mapping: {raw_file_path}")
            
            # For board exams, we should always have a Raw file
            # For other exams, if no Raw file found, try to find any matching pattern
            if not found_raw_file:
                # Try to find any Raw file with similar naming pattern
                try:
                    files_in_dir = default_storage.listdir(directory)[1]
                    school_name_parts = school.name.split()
                    for potential_file in files_in_dir:
                        if (potential_file.startswith('Raw_') and 
                            str(academic_year) in potential_file and
                            any(part in potential_file for part in school_name_parts)):
                            # Check if exam type matches
                            if exam_type_for_file.lower() in potential_file.lower():
                                potential_path = os.path.join(directory, potential_file)
                                raw_file_path = potential_path
                                found_raw_file = True
                                print(f"Found Raw file by school name matching: {raw_file_path}")
                                break
                except Exception as e:
                    print(f"Error in school name matching: {str(e)}")
            
            # Use the raw file if found, otherwise throw an error
            if found_raw_file and raw_file_path:
                file_path_str = raw_file_path
                print(f"Using Raw file: {file_path_str}")
            else:
                print(f"No Raw file found for {exam_type} in year {academic_year}")
                return Response(
                    {"error": f"Raw marks data not available for {exam_type} in year {academic_year}. Only processed data is available."}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Finally, read the selected file
            with default_storage.open(file_path_str, 'rb') as f:
                df = pd.read_csv(f)
                
            # Clean column names
            df.columns = df.columns.str.strip()
            
            # Filter by roll number if provided
            if roll_number:
                try:
                    roll_num = int(roll_number)
                    filtered_df = df[df['Roll Number'] == roll_num]
                    if filtered_df.empty:
                        return Response(
                            {"error": f"No results found for roll number {roll_number}"}, 
                            status=status.HTTP_404_NOT_FOUND
                        )
                    df = filtered_df
                except ValueError:
                    return Response(
                        {"error": f"Invalid roll number: {roll_number}"}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
                    
            # Add student IDs to the results
            students_map = {}
            for index, row in df.iterrows():
                # Get roll_number from the current row
                row_roll_number = row['Roll Number']
                
                # Try to get the student ID from the database
                try:
                    student = Student.objects.get(
                        school=school,
                        roll_number=row_roll_number
                    )
                    students_map[row_roll_number] = student.id
                except Student.DoesNotExist:
                    students_map[row_roll_number] = None
                except Student.MultipleObjectsReturned:
                    # If multiple students found, get the most recent one
                    student = Student.objects.filter(
                        school=school,
                        roll_number=row_roll_number
                    ).order_by('-id').first()
                    students_map[row_roll_number] = student.id if student else None
            
            # Add the ID to each row in the results
            results_data = df.to_dict('records')
            for result in results_data:
                result['id'] = students_map.get(result['Roll Number'])
            
            # Add additional metadata
            response_data = {
                "exam_type": exam_type,
                "academic_year": academic_year,
                "school_name": school.name,
                "total_records": len(results_data),
                "file_url": file_field.url if hasattr(file_field, 'url') else None,
                "results": results_data,
                "file_used": file_path_str  # For debugging, to see which file was used
            }
            
            return Response(response_data, status=status.HTTP_200_OK)
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Error reading results file: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
class TestResultsUploadView(APIView):
    """Unified API view for uploading individual student test results"""
    permission_classes = [IsAuthenticated]  # Allow both admin and students
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Upload test result files for a single student",
        request_body=TestResultsUploadSerializer,
        responses={
            200: "Upload successful",
            400: "Invalid input data",
            500: "Processing error"
        }
    )
    def post(self, request, *args, **kwargs):
        """Process uploaded test result files for a single student"""
        serializer = TestResultsUploadSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # Determine user role and school
            if hasattr(request.user, 'school_admin'):
                # School admin can upload for any student in their school
                school = request.user.school_admin
                is_admin = True
                target_student = None
            elif hasattr(request.user, 'student_profile'):
                # Students can only upload their own results
                school = request.user.student_profile.school
                is_admin = False
                target_student = request.user.student_profile
            else:
                return Response({
                    "error": "User is neither a school admin nor a student"
                }, status=status.HTTP_403_FORBIDDEN)
            
            validated_data = serializer.validated_data
            academic_year = validated_data['academic_year']
            
            # Create upload batch tracker
            upload_batch = TestResultsUploadBatch.objects.create(
                school=school,
                academic_year=academic_year,
                uploaded_by=request.user,
                upload_type='single_student'
            )
            
            # Process each file type
            results = {}
            student_info = None
            all_storage_details = []
            
            if 'personality_test_file' in request.FILES:
                result = self._process_single_student_file(
                    request.FILES['personality_test_file'],
                    'personality_test',
                    school,
                    academic_year,
                    validated_data,
                    upload_batch,
                    target_student,
                    is_admin
                )
                results['personality_test'] = result
                if result.get('success') and result.get('student_info'):
                    student_info = result['student_info']
                if result.get('storage_details'):
                    all_storage_details.extend(result['storage_details'])
            
            if 'aptitude_test_file' in request.FILES:
                result = self._process_single_student_file(
                    request.FILES['aptitude_test_file'],
                    'aptitude_test',
                    school,
                    academic_year,
                    validated_data,
                    upload_batch,
                    target_student,
                    is_admin
                )
                results['aptitude_test'] = result
                if result.get('success') and result.get('student_info'):
                    student_info = result['student_info']
                if result.get('storage_details'):
                    all_storage_details.extend(result['storage_details'])
            
            if 'percentile_results_file' in request.FILES:
                result = self._process_single_student_file(
                    request.FILES['percentile_results_file'],
                    'percentile_results',
                    school,
                    academic_year,
                    validated_data,
                    upload_batch,
                    target_student,
                    is_admin
                )
                results['percentile_results'] = result
                if result.get('success') and result.get('student_info'):
                    student_info = result['student_info']
                if result.get('storage_details'):
                    all_storage_details.extend(result['storage_details'])
            
            # Update batch summary
            successful = sum(1 for r in results.values() if r.get('success', False))
            failed = len(results) - successful
            
            upload_batch.total_records = 1  # Single student
            upload_batch.successful_uploads = len(all_storage_details)
            upload_batch.failed_uploads = failed
            upload_batch.is_completed = True
            upload_batch.save()
            
            # Check for any critical errors
            critical_errors = [r for r in results.values() if not r.get('success', False)]
            if critical_errors:
                return Response({
                    "error": "Some files could not be processed",
                    "details": results,
                    "batch_id": upload_batch.id
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Group storage details by file type
            files_uploaded = {}
            for detail in all_storage_details:
                files_uploaded[detail['file_type']] = {
                    'file_path': detail['file_path'],
                    'file_url': detail['file_url']
                }
            
            # Return success response
            response_data = {
                "message": "Test results uploaded successfully",
                "batch_id": upload_batch.id,
                "student_info": student_info,
                "summary": {
                    "files_uploaded": len(all_storage_details),
                    "upload_type": "single_student",
                    "academic_year": academic_year,
                    "uploaded_by": "admin" if is_admin else "student"
                },
                "files": files_uploaded,
                "storage_details": {
                    "storage_location": "Azure Blob Storage",
                    "base_path": f"student_test_results/{school.id}/{student_info['student_id'] if student_info else 'unknown'}/{academic_year}/",
                    "total_files_stored": len(all_storage_details)
                }
            }
            
            return Response(response_data, status=status.HTTP_200_OK)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response({
                "error": f"Unexpected error during processing: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def _process_single_student_file(self, file, file_type, school, academic_year, validated_data, upload_batch, target_student, is_admin):
        """Process a single student's test result file"""
        try:
            # Read CSV file
            df = pd.read_csv(file)
            df.columns = df.columns.str.strip()
            
            # Validate single student entry
            if len(df) != 1:
                return {
                    'success': False,
                    'file_type': file_type,
                    'error': f'CSV must contain exactly one student record. Found {len(df)} records.'
                }
            
            # Get the single row
            row = df.iloc[0]
            
            # Process the student record
            student_result = self._process_single_student_record(
                row, file_type, school, academic_year, validated_data, target_student, is_admin
            )
            
            if not student_result['success']:
                return {
                    'success': False,
                    'file_type': file_type,
                    'error': student_result['error']
                }
            
            student = student_result['student']
            
            # Save the file to Azure storage
            try:
                storage_result = self._save_file_to_student(
                    student, 
                    file, 
                    file_type, 
                    academic_year
                )
                
                if not storage_result['success']:
                    return {
                        'success': False,
                        'file_type': file_type,
                        'error': f"Failed to save file: {storage_result.get('error', 'Unknown error')}"
                    }
                
                # Update upload batch
                upload_batch.students_processed.add(student)
                
                return {
                    'success': True,
                    'file_type': file_type,
                    'student_info': {
                        'student_id': student.id,
                        'student_name': student.user.name,
                        'student_email': student.user.email,
                        'roll_number': student.roll_number,
                        'school_name': student.school.name
                    },
                    'storage_details': [{
                        'student_id': storage_result['student_id'],
                        'student_name': storage_result['student_name'],
                        'file_path': storage_result['file_path'],
                        'file_url': storage_result['file_url'],
                        'file_type': file_type
                    }]
                }
                
            except Exception as e:
                return {
                    'success': False,
                    'file_type': file_type,
                    'error': f"Error saving file: {str(e)}"
                }
            
        except Exception as e:
            return {
                'success': False,
                'file_type': file_type,
                'error': f"Error processing file: {str(e)}"
            }
    
    def _process_single_student_record(self, row, file_type, school, academic_year, validated_data, target_student, is_admin):
        """Process a single student record with proper validation"""
        try:
            # Extract student info
            name = str(row['Name']).strip()
            email = str(row['Email']).strip()
            roll_number = int(row['Roll Number']) if not pd.isna(row['Roll Number']) else None
            
            # If user is a student, validate that the CSV is for them
            if not is_admin:
                if target_student.user.email.lower() != email.lower():
                    return {
                        'success': False,
                        'error': f'Students can only upload their own results. Expected email: {target_student.user.email}, found: {email}'
                    }
                
                if roll_number and target_student.roll_number and target_student.roll_number != roll_number:
                    return {
                        'success': False,
                        'error': f'Roll number mismatch. Expected: {target_student.roll_number}, found: {roll_number}'
                    }
                
                # Use the authenticated student
                student = target_student
            else:
                # Admin can upload for any student - find the student
                student = None
                
                # Try to find by email first
                try:
                    user = User.objects.get(email=email)
                    student = Student.objects.filter(user=user, school=school).first()
                except User.DoesNotExist:
                    pass
                
                # Try to find by roll number if not found by email
                if not student and roll_number:
                    try:
                        student = Student.objects.filter(
                            school=school, 
                            roll_number=roll_number
                        ).first()
                    except Exception:
                        pass
                
                # Create student if not found and creation is enabled
                if not student and validated_data.get('create_missing_students', True):
                    try:
                        student = self._create_student_from_row(row, school)
                    except Exception as e:
                        return {
                            'success': False,
                            'error': f'Failed to create student {name}: {str(e)}'
                        }
                
                if not student:
                    return {
                        'success': False,
                        'error': f'Student not found: {name} ({email}, Roll: {roll_number})'
                    }
            
            return {
                'success': True,
                'student': student
            }
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return {
                'success': False,
                'error': f'Error processing student record: {str(e)}'
            }
    
    def _create_student_from_row(self, row, school):
        """Create a new student from CSV row data"""
        try:
            # Extract data
            name = str(row['Name']).strip()
            email = str(row['Email']).strip()
            address = str(row['Address']).strip() if 'Address' in row else ''
            roll_number = int(row['Roll Number']) if not pd.isna(row['Roll Number']) else None
            mobile_number = str(row['Mobile Number']).strip() if 'Mobile Number' in row else ''
            student_class = int(row['Class']) if not pd.isna(row['Class']) else 10
            
            # Handle birth date
            birth_date = None
            if 'Birth Date' in row and not pd.isna(row['Birth Date']):
                try:
                    from dateutil import parser
                    birth_date = parser.parse(str(row['Birth Date'])).date()
                except:
                    pass
            
            # Check if user already exists
            user = None
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                # Create new user
                user = User.objects.create(
                    email=email,
                    name=name,
                    is_school_student=True,
                    is_active=True,
                    contact_number=mobile_number
                )
                
                # Set default password
                default_password = f"{name.split()[0].lower()}@123"
                user.set_password(default_password)
                user.save()
            
            # Check if student profile already exists
            existing_student = Student.objects.filter(user=user, school=school).first()
            if existing_student:
                return existing_student
            
            # Generate unique registration number
            registration_no = self._generate_unique_registration_number(school, roll_number, user.id)
            
            # Handle duplicate roll numbers
            final_roll_number = roll_number
            if roll_number:
                existing_roll = Student.objects.filter(school=school, roll_number=roll_number).first()
                if existing_roll:
                    final_roll_number = None  # Don't assign roll number if duplicate
            
            # Create student
            student = Student.objects.create(
                user=user,
                school=school,
                student_class=student_class,
                roll_number=final_roll_number,
                birth_date=birth_date,
                contact_number=mobile_number,
                address=address,
                registration_no=registration_no
            )
            
            return student
            
        except Exception as e:
            raise Exception(f"Failed to create student: {str(e)}")
    
    def _generate_unique_registration_number(self, school, roll_number, user_id):
        """Generate a unique registration number"""
        try:
            school_code = ''.join([word[0].upper() for word in school.name.split() if word])
            if len(school_code) <= 2:
                school_code = school.name[:3].upper()
            
            year_code = str(now().year)[-2:]
            identifier = str(roll_number).zfill(3) if roll_number else str(user_id).zfill(3)
            
            base_registration_no = f"{school_code}{year_code}{identifier}"
            registration_no = base_registration_no
            counter = 1
            
            while Student.objects.filter(registration_no=registration_no).exists():
                registration_no = f"{base_registration_no}_{counter}"
                counter += 1
                if counter > 1000:
                    registration_no = f"{base_registration_no}_{user_id}_{now().timestamp()}"
                    break
            
            return registration_no
            
        except Exception:
            return f"REG_{school.id}_{user_id}_{now().timestamp()}"
    
    def _save_file_to_student(self, student, file, file_type, academic_year):
        """Save the uploaded file to Azure storage without deleting the same file"""
        try:
            print(f"Starting file save for student {student.id}, file_type: {file_type}")
            
            # Import Azure storage backend
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            
            print(f"Azure storage initialized: {azure_storage.__class__.__name__}")
            print(f"Azure account: {getattr(azure_storage, 'account_name', 'Unknown')}")
            print(f"Azure container: {getattr(azure_storage, 'azure_container', 'Unknown')}")
            
            # Generate file path
            file_path = f"student_test_results/{student.school.id}/{student.id}/{academic_year}/{file_type}.csv"
            print(f"Generated file path: {file_path}")
            
            # Get or create StudentTestResults record FIRST
            test_results, created = StudentTestResults.objects.get_or_create(
                student=student,
                academic_year=academic_year,
                defaults={'uploaded_by': self.request.user}
            )
            
            print(f"StudentTestResults record: {'created' if created else 'found existing'}")
            
            if not created:
                test_results.uploaded_by = self.request.user
            
            # Store old file path for deletion BEFORE saving new file
            old_file_path = None
            if file_type == 'personality_test' and test_results.personality_test_file:
                old_file_path = test_results.personality_test_file.name
            elif file_type == 'aptitude_test' and test_results.aptitude_test_file:
                old_file_path = test_results.aptitude_test_file.name
            elif file_type == 'percentile_results' and test_results.percentile_results_file:
                old_file_path = test_results.percentile_results_file.name
            
            print(f"Old file path: {old_file_path}")
            
            # Reset file pointer and read content
            file.seek(0)
            file_content = ContentFile(file.read())
            file_content.name = f"{file_type}.csv"
            
            print(f"File content size: {len(file_content.read())} bytes")
            file_content.seek(0)  # Reset after reading for size check
            
            # Check if Azure storage is working
            try:
                print("Testing Azure storage connection...")
                
                # Try to save to Azure storage
                print(f"Attempting to save file to Azure: {file_path}")
                saved_path = azure_storage.save(file_path, file_content)
                print(f"Azure save successful. Saved path: {saved_path}")
                
                # Generate URL
                file_url = azure_storage.url(saved_path)
                print(f"Generated Azure URL: {file_url}")
                
                # Verify file exists in Azure
                try:
                    exists = azure_storage.exists(saved_path)
                    print(f"File exists in Azure: {exists}")
                    
                    if exists:
                        try:
                            size = azure_storage.size(saved_path)
                            print(f"File size in Azure: {size} bytes")
                        except Exception as size_e:
                            print(f"Could not get file size: {size_e}")
                    else:
                        print("WARNING: File was 'saved' but doesn't exist in Azure!")
                        
                except Exception as exists_e:
                    print(f"Error checking if file exists: {exists_e}")
                
            except Exception as azure_e:
                print(f"Azure storage error: {azure_e}")
                import traceback
                traceback.print_exc()
                raise azure_e
            
            # Update the appropriate field with the saved path
            if file_type == 'personality_test':
                test_results.personality_test_file = saved_path
            elif file_type == 'aptitude_test':
                test_results.aptitude_test_file = saved_path
            elif file_type == 'percentile_results':
                test_results.percentile_results_file = saved_path
            
            # Save the model
            test_results.save()
            print(f"StudentTestResults model saved successfully")
            
            # NOW delete the old file (if it exists and is different from the new one)
            if old_file_path and old_file_path != saved_path:
                try:
                    print(f"Deleting old {file_type} file: {old_file_path}")
                    azure_storage.delete(old_file_path)
                    print(f"Old file deleted successfully")
                except Exception as del_e:
                    print(f"Could not delete old file (this is OK): {del_e}")
            elif old_file_path == saved_path:
                print(f"Skipping deletion - old and new file paths are the same: {old_file_path}")
            else:
                print("No old file to delete")
            
            return {
                'success': True,
                'file_path': saved_path,
                'file_url': file_url,
                'student_id': student.id,
                'student_name': student.user.name
            }
            
        except Exception as e:
            print(f"Critical error in _save_file_to_student: {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                'success': False,
                'error': str(e)
            }
    
    def _manual_azure_upload(self, file_content, file_path):
        """Manual Azure blob upload as fallback"""
        try:
            from azure.storage.blob import BlobServiceClient
            from django.conf import settings
            
            # Get Azure credentials from settings
            account_name = getattr(settings, 'AZURE_ACCOUNT_NAME', None)
            account_key = getattr(settings, 'AZURE_ACCOUNT_KEY', None)
            container_name = getattr(settings, 'AZURE_CONTAINER', 'media')
            
            if not account_name or not account_key:
                return {
                    'success': False,
                    'error': 'Azure credentials not found in settings'
                }
            
            print(f"Manual upload - Account: {account_name}, Container: {container_name}")
            
            # Create blob service client
            blob_service_client = BlobServiceClient(
                account_url=f"https://{account_name}.blob.core.windows.net",
                credential=account_key
            )
            
            # Upload file
            blob_client = blob_service_client.get_blob_client(
                container=container_name,
                blob=file_path
            )
            
            file_content.seek(0)
            blob_client.upload_blob(file_content.read(), overwrite=True)
            
            # Generate URL
            file_url = f"https://{account_name}.blob.core.windows.net/{container_name}/{file_path}"
            
            print(f"Manual upload successful: {file_url}")
            
            return {
                'success': True,
                'saved_path': file_path,
                'file_url': file_url
            }
            
        except Exception as e:
            print(f"Manual Azure upload error: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }


class TestResultsListView(APIView):
    """API to list uploaded test results"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, *args, **kwargs):
        """List test results based on user role"""
        if hasattr(request.user, 'school_admin'):
            # School admin can see all students' results
            school = request.user.school_admin
            test_results = serializers.StudentTestResults.objects.filter(
                student__school=school
            ).select_related('student__user')
            
        elif hasattr(request.user, 'student_profile'):
            # Students can only see their own results
            student = request.user.student_profile
            test_results = serializers.StudentTestResults.objects.filter(student=student)
            
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Apply filters
        academic_year = request.query_params.get('academic_year')
        if academic_year:
            test_results = test_results.filter(academic_year=academic_year)
        
        serializer = StudentTestResultsSerializer(test_results, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
class TestResultsSummaryView(APIView):
    """API to get processed summary of test results for a student"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, student_id, *args, **kwargs):
        """Get test results summary for a specific student"""
        # Check permissions
        if hasattr(request.user, 'school_admin'):
            # School admin can view any student in their school
            try:
                student = Student.objects.get(
                    id=student_id, 
                    school=request.user.school_admin
                )
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        elif hasattr(request.user, 'student_profile'):
            # Students can only view their own summary
            student = request.user.student_profile
            if student.id != student_id:
                return Response(
                    {"error": "You can only view your own test results"}, 
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            return Response(
                {"error": "User is neither a school admin nor a student"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Get academic year filter
        academic_year = request.query_params.get('academic_year', now().year)
        
        try:
            # Get test results
            test_results = StudentTestResults.objects.get(
                student=student, 
                academic_year=academic_year
            )
            
            # Get or create summary
            summary, created = StudentTestResultsSummary.objects.get_or_create(
                student_test_results=test_results
            )
            
            # If summary was just created or needs updating, process the files
            if created or not summary.processed_at:
                self._process_test_results_summary(test_results, summary)
            
            # Serialize and return
            serializer = StudentTestResultsSummarySerializer(summary)
            return Response(serializer.data, status=status.HTTP_200_OK)
            
        except StudentTestResults.DoesNotExist:
            return Response(
                {"error": f"No test results found for student in year {academic_year}"}, 
                status=status.HTTP_404_NOT_FOUND
            )
    
    def _process_test_results_summary(self, test_results, summary):
        """Process the uploaded files and generate summary data"""
        try:
            # Process personality test file
            if test_results.personality_test_file:
                personality_data = self._process_personality_file(test_results.personality_test_file)
                summary.personality_type = personality_data.get('personality_type')
                summary.personality_dimensions = personality_data.get('dimensions', {})
            
            # Process aptitude test file
            if test_results.aptitude_test_file:
                aptitude_data = self._process_aptitude_file(test_results.aptitude_test_file)
                summary.total_aptitude_score = aptitude_data.get('total_score')
                summary.aptitude_scores = aptitude_data.get('scores', {})
                summary.aptitude_percentiles = aptitude_data.get('percentiles', {})
            
            # Process percentile results file
            if test_results.percentile_results_file:
                percentile_data = self._process_percentile_file(test_results.percentile_results_file)
                summary.academic_percentiles = percentile_data.get('percentiles', {})
                summary.overall_academic_percentile = percentile_data.get('overall_percentile')
                summary.academic_grade = percentile_data.get('grade')
            
            # Calculate rankings (if needed)
            self._calculate_rankings(test_results.student, summary)
            
            # Mark as processed
            test_results.is_processed = True
            test_results.save()
            summary.save()
            
        except Exception as e:
            # Log error and mark as failed
            test_results.processing_errors = {'summary_error': str(e)}
            test_results.save()
            raise
    
    def _process_personality_file(self, file):
        """Extract personality data from uploaded file"""
        try:
            with default_storage.open(file.name, 'rb') as f:
                df = pd.read_csv(f)
                
            # This is a placeholder - implement based on your personality test format
            # For now, return mock data
            return {
                'personality_type': 'INTJ',  # Calculate from file data
                'dimensions': {
                    'Extraversion_Introversion': {'Extraversion': 30, 'Introversion': 70},
                    'Sensing_Intuition': {'Sensing': 25, 'Intuition': 75},
                    'Thinking_Feeling': {'Thinking': 80, 'Feeling': 20},
                    'Judging_Perceiving': {'Judging': 60, 'Perceiving': 40}
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _process_aptitude_file(self, file):
        """Extract aptitude data from uploaded file"""
        try:
            with default_storage.open(file.name, 'rb') as f:
                df = pd.read_csv(f)
                
            # Extract scores from the CSV
            row = df.iloc[0]  # Assuming single student file
            
            scores = {
                'Numerical Aptitude': int(row.get('Numerical Aptitude', 0)),
                'Verbal Aptitude': int(row.get('Verbal Aptitude', 0)),
                'Logical Aptitude': int(row.get('Logical Aptitude', 0)),
                'Abstract Reasoning': int(row.get('Abstract Reasoning', 0)),
                'Spatial Aptitude': int(row.get('Spatial Aptitude', 0)),
                'Mechanical Aptitude': int(row.get('Mechanical Aptitude', 0)),
                'Clerical Aptitude': int(row.get('Clerical Aptitude', 0)),
                'Attention to Details': int(row.get('Attention to Details', 0)),
                'General Knowledge And Awareness': int(row.get('General Knowledge And Awareness', 0)),
                'Technical Aptitude': int(row.get('Technical Aptitude', 0)),
                'Situational Judgement': int(row.get('Situtational Judgement', 0)),
                'Memory Retention': int(row.get('Memory Retention', 0))
            }
            
            total_score = int(row.get('Total', sum(scores.values())))
            
            # Calculate percentiles (this would need actual comparison data)
            percentiles = {key: self._calculate_percentile(value) for key, value in scores.items()}
            
            return {
                'total_score': total_score,
                'scores': scores,
                'percentiles': percentiles
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _process_percentile_file(self, file):
        """Extract percentile data from uploaded file"""
        try:
            with default_storage.open(file.name, 'rb') as f:
                df = pd.read_csv(f)
                
            # Extract percentiles from the CSV
            row = df.iloc[0]  # Assuming single student file
            
            percentiles = {
                'Literature': float(row.get('Literature', 0)),
                'Grammar': float(row.get('Grammer', 0)),  # Note: typo in original
                'History': float(row.get('History', 0)),
                'Geography': float(row.get('Geography', 0)),
                'Math': float(row.get('Math', 0)),
                'Biology': float(row.get('Biology', 0)),
                'Physics': float(row.get('Physics', 0)),
                'Chemistry': float(row.get('Chemistry', 0))
            }
            
            # Calculate overall percentile
            overall_percentile = sum(percentiles.values()) / len(percentiles)
            
            # Determine grade based on overall percentile
            if overall_percentile >= 90:
                grade = 'Excellent'
            elif overall_percentile >= 80:
                grade = 'Good'
            elif overall_percentile >= 70:
                grade = 'Above Average'
            elif overall_percentile >= 60:
                grade = 'Average'
            else:
                grade = 'Below Average'
            
            return {
                'percentiles': percentiles,
                'overall_percentile': round(overall_percentile, 2),
                'grade': grade
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _calculate_percentile(self, score, max_score=100):
        """Calculate percentile for a given score (placeholder implementation)"""
        # This is a simplified calculation - in reality, you'd compare against 
        # a larger dataset of scores
        return min(100, max(0, (score / max_score) * 100))
    
    def _calculate_rankings(self, student, summary):
        """Calculate school and class rankings"""
        # This would require comparing with other students' results
        # For now, set placeholder values
        summary.school_rank = 1  # Placeholder
        summary.class_rank = 1   # Placeholder

class TestResultsBatchDetailView(APIView):
    """API to get details of a specific upload batch"""
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, batch_id, *args, **kwargs):
        """Get detailed information about an upload batch"""
        try:
            batch = TestResultsUploadBatch.objects.get(
                id=batch_id, 
                school=request.user.school_admin
            )
            
            serializer = TestResultsUploadBatchSerializer(batch)
            return Response(serializer.data, status=status.HTTP_200_OK)
            
        except TestResultsUploadBatch.DoesNotExist:
            return Response(
                {"error": "Upload batch not found"}, 
                status=status.HTTP_404_NOT_FOUND
            )

# Replace the TestResultsDownloadView with this version that returns download URLs

class TestResultsDownloadView(APIView):
    """API to get download URL for test result files"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, student_id, file_type, *args, **kwargs):
        """Get download URL for a specific test result file"""
        # Check permissions
        if hasattr(request.user, 'school_admin'):
            try:
                student = Student.objects.get(
                    id=student_id, 
                    school=request.user.school_admin
                )
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        elif hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            if student.id != student_id:
                return Response(
                    {"error": "You can only download your own files"}, 
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            return Response(
                {"error": "Permission denied"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Get academic year
        academic_year = request.query_params.get('academic_year', now().year)
        
        try:
            test_results = StudentTestResults.objects.get(
                student=student, 
                academic_year=academic_year
            )
            
            # Get the requested file field
            file_field = None
            if file_type == 'personality_test':
                file_field = test_results.personality_test_file
            elif file_type == 'aptitude_test':
                file_field = test_results.aptitude_test_file
            elif file_type == 'percentile_results':
                file_field = test_results.percentile_results_file
            else:
                return Response(
                    {"error": "Invalid file type. Must be: personality_test, aptitude_test, or percentile_results"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if not file_field or not file_field.name:
                return Response(
                    {"error": f"No {file_type} file found for this student"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get Azure download URL
            try:
                from storage_backends import AzureMediaStorage
                azure_storage = AzureMediaStorage()
                
                file_path = file_field.name
                print(f"Getting download URL for file: {file_path}")
                
                # Check if file exists
                if not azure_storage.exists(file_path):
                    return Response(
                        {"error": "File not found in storage"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Generate Azure URL with proper headers for download
                file_url = azure_storage.url(file_path)
                
                # Create a direct download URL that bypasses our API
                direct_download_url = f"{request.build_absolute_uri().replace('/download/', '/direct-download/')}"
                
                # Generate safe filename
                safe_student_name = student.user.name.replace(' ', '_').replace('/', '_')
                filename = f"{safe_student_name}_{file_type}_{academic_year}.csv"
                
                # Get file size safely
                file_size = None
                try:
                    file_size = azure_storage.size(file_path)
                except Exception as size_e:
                    print(f"Could not get file size: {size_e}")
                
                return Response({
                    "download_url": direct_download_url,
                    "azure_download_url": file_url,
                    "filename": filename,
                    "file_path": file_path,
                    "storage_type": "Azure Blob Storage",
                    "file_size": file_size,
                    "student_info": {
                        "id": student.id,
                        "name": student.user.name,
                        "email": student.user.email,
                        "roll_number": student.roll_number
                    },
                    "download_instructions": {
                        "method": "GET",
                        "url": direct_download_url,
                        "description": "Use this URL to automatically download the file"
                    }
                }, status=status.HTTP_200_OK)
                
            except Exception as e:
                print(f"Error getting download URL: {str(e)}")
                import traceback
                traceback.print_exc()
                
                return Response(
                    {"error": f"Error generating download URL: {str(e)}"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
        except StudentTestResults.DoesNotExist:
            return Response(
                {"error": "No test results found for this student"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class TestResultsDirectDownloadView(APIView):
    """Direct download endpoint that returns file content for automatic download"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request, student_id, file_type, *args, **kwargs):
        """Directly download file content with proper headers"""
        # Check permissions (same logic as above)
        if hasattr(request.user, 'school_admin'):
            try:
                student = Student.objects.get(
                    id=student_id, 
                    school=request.user.school_admin
                )
            except Student.DoesNotExist:
                raise Http404("Student not found")
        elif hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            if student.id != student_id:
                return HttpResponse("Permission denied", status=403)
        else:
            return HttpResponse("Permission denied", status=403)
        
        # Get academic year
        academic_year = request.GET.get('academic_year', now().year)
        
        try:
            test_results = StudentTestResults.objects.get(
                student=student, 
                academic_year=academic_year
            )
            
            # Get the requested file field
            file_field = None
            if file_type == 'personality_test':
                file_field = test_results.personality_test_file
            elif file_type == 'aptitude_test':
                file_field = test_results.aptitude_test_file
            elif file_type == 'percentile_results':
                file_field = test_results.percentile_results_file
            else:
                return HttpResponse("Invalid file type", status=400)
            
            if not file_field or not file_field.name:
                raise Http404("File not found")
            
            # Download file content from Azure
            try:
                from storage_backends import AzureMediaStorage
                azure_storage = AzureMediaStorage()
                
                file_path = file_field.name
                print(f"Direct downloading file from Azure: {file_path}")
                
                # Check if file exists
                if not azure_storage.exists(file_path):
                    raise Http404("File not found in storage")
                
                # Read file content from Azure
                with azure_storage.open(file_path, 'rb') as azure_file:
                    file_content = azure_file.read()
                
                print(f"Successfully read {len(file_content)} bytes from Azure for direct download")
                
                # Generate safe filename
                safe_student_name = student.user.name.replace(' ', '_').replace('/', '_')
                filename = f"{safe_student_name}_{file_type}_{academic_year}.csv"
                
                # Create HTTP response with file content and download headers
                response = HttpResponse(
                    file_content,
                    content_type='text/csv'
                )
                response['Content-Disposition'] = f'attachment; filename="{filename}"'
                response['Content-Length'] = len(file_content)
                response['Cache-Control'] = 'no-cache'
                
                print(f"Sending direct file download: {filename}")
                return response
                
            except Exception as e:
                print(f"Error in direct download: {str(e)}")
                return HttpResponse(f"Error downloading file: {str(e)}", status=500)
            
        except StudentTestResults.DoesNotExist:
            raise Http404("No test results found for this student")

class TestResultsRedirectDownloadView(APIView):
    """Redirect to Azure blob URL for direct download"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request, student_id, file_type, *args, **kwargs):
        """Redirect to Azure blob URL with download headers"""
        # Check permissions (same logic as above)
        if hasattr(request.user, 'school_admin'):
            try:
                student = Student.objects.get(
                    id=student_id, 
                    school=request.user.school_admin
                )
            except Student.DoesNotExist:
                raise Http404("Student not found")
        elif hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            if student.id != student_id:
                return HttpResponse("Permission denied", status=403)
        else:
            return HttpResponse("Permission denied", status=403)
        
        # Get academic year
        academic_year = request.GET.get('academic_year', now().year)
        
        try:
            test_results = StudentTestResults.objects.get(
                student=student, 
                academic_year=academic_year
            )
            
            # Get the requested file field
            file_field = None
            if file_type == 'personality_test':
                file_field = test_results.personality_test_file
            elif file_type == 'aptitude_test':
                file_field = test_results.aptitude_test_file
            elif file_type == 'percentile_results':
                file_field = test_results.percentile_results_file
            else:
                return HttpResponse("Invalid file type", status=400)
            
            if not file_field or not file_field.name:
                raise Http404("File not found")
            
            # Get Azure URL and redirect
            try:
                from storage_backends import AzureMediaStorage
                from django.http import HttpResponseRedirect
                
                azure_storage = AzureMediaStorage()
                file_path = file_field.name
                
                if not azure_storage.exists(file_path):
                    raise Http404("File not found in storage")
                
                # Get Azure blob URL
                azure_url = azure_storage.url(file_path)
                
                print(f"Redirecting to Azure URL: {azure_url}")
                
                # Redirect to Azure blob URL
                return HttpResponseRedirect(azure_url)
                
            except Exception as e:
                print(f"Error in redirect download: {str(e)}")
                return HttpResponse(f"Error accessing file: {str(e)}", status=500)
            
        except StudentTestResults.DoesNotExist:
            raise Http404("No test results found for this student")

class TestResultsStorageStatsView(APIView):
    """API to get storage statistics for test results with proper Azure handling"""
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, *args, **kwargs):
        """Get storage statistics for the school"""
        school = request.user.school_admin
        academic_year = request.query_params.get('academic_year')
        
        # Base queryset
        queryset = StudentTestResults.objects.filter(student__school=school)
        if academic_year:
            queryset = queryset.filter(academic_year=academic_year)
        
        # Calculate statistics
        total_students_with_files = queryset.count()
        personality_files = queryset.filter(personality_test_file__isnull=False).exclude(personality_test_file='').count()
        aptitude_files = queryset.filter(aptitude_test_file__isnull=False).exclude(aptitude_test_file='').count()
        percentile_files = queryset.filter(percentile_results_file__isnull=False).exclude(percentile_results_file='').count()
        
        # Get storage paths safely
        storage_paths = []
        
        # Get Azure storage info
        try:
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            account_name = azure_storage.account_name
            container_name = azure_storage.azure_container
        except:
            from django.conf import settings
            account_name = getattr(settings, 'AZURE_ACCOUNT_NAME', 'unknown')
            container_name = getattr(settings, 'AZURE_CONTAINER', 'media')
        
        for result in queryset.select_related('student__user'):
            student_info = {
                'student_id': result.student.id,
                'student_name': result.student.user.name,
                'academic_year': result.academic_year,
                'files': {}
            }
            
            # Safely handle each file type
            if result.personality_test_file and result.personality_test_file.name:
                file_path = result.personality_test_file.name
                url = f"https://{account_name}.blob.core.windows.net/{container_name}/{file_path}"
                student_info['files']['personality_test'] = {
                    'path': file_path,
                    'url': url
                }
            
            if result.aptitude_test_file and result.aptitude_test_file.name:
                file_path = result.aptitude_test_file.name
                url = f"https://{account_name}.blob.core.windows.net/{container_name}/{file_path}"
                student_info['files']['aptitude_test'] = {
                    'path': file_path,
                    'url': url
                }
            
            if result.percentile_results_file and result.percentile_results_file.name:
                file_path = result.percentile_results_file.name
                url = f"https://{account_name}.blob.core.windows.net/{container_name}/{file_path}"
                student_info['files']['percentile_results'] = {
                    'path': file_path,
                    'url': url
                }
            
            if student_info['files']:  # Only add if student has files
                storage_paths.append(student_info)
        
        return Response({
            "school_info": {
                "school_id": school.id,
                "school_name": school.name,
                "academic_year_filter": academic_year
            },
            "storage_summary": {
                "total_students_with_files": total_students_with_files,
                "personality_test_files": personality_files,
                "aptitude_test_files": aptitude_files,
                "percentile_results_files": percentile_files,
                "total_files": personality_files + aptitude_files + percentile_files,
                "storage_location": "Azure Blob Storage",
                "base_path": f"student_test_results/{school.id}/",
                "azure_account": account_name,
                "azure_container": container_name
            },
            "student_files": storage_paths
        }, status=status.HTTP_200_OK)
    

class TestAzureStorageView(APIView):
    """Test endpoint to debug Azure storage"""
    permission_classes = [IsAuthenticated, IsSchoolAdmin]
    
    def post(self, request):
        """Test Azure storage upload"""
        try:
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            
            # Create test file
            test_content = ContentFile(b"Test file content for debugging Azure storage")
            test_content.name = "test.txt"
            test_path = "test_uploads/debug_test.txt"
            
            print(f"Testing Azure storage...")
            print(f"Account: {getattr(azure_storage, 'account_name', 'Unknown')}")
            print(f"Container: {getattr(azure_storage, 'azure_container', 'Unknown')}")
            
            # Try to save
            saved_path = azure_storage.save(test_path, test_content)
            print(f"Saved to: {saved_path}")
            
            # Try to get URL
            file_url = azure_storage.url(saved_path)
            print(f"URL: {file_url}")
            
            # Check if exists
            exists = azure_storage.exists(saved_path)
            print(f"Exists: {exists}")
            
            # Get size
            try:
                size = azure_storage.size(saved_path)
                print(f"Size: {size}")
            except Exception as size_e:
                print(f"Size error: {size_e}")
                size = None
            
            # Try to delete test file
            try:
                azure_storage.delete(saved_path)
                print("Test file deleted")
            except Exception as del_e:
                print(f"Delete error: {del_e}")
            
            return Response({
                "success": True,
                "azure_account": getattr(azure_storage, 'account_name', 'Unknown'),
                "azure_container": getattr(azure_storage, 'azure_container', 'Unknown'),
                "test_path": saved_path,
                "test_url": file_url,
                "file_exists": exists,
                "file_size": size,
                "message": "Azure storage test completed successfully"
            })
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            
            return Response({
                "success": False,
                "error": str(e),
                "traceback": traceback.format_exc()
            }, status=500)
        
class TestResultsFileInfoView(APIView):
    """API to get file information without downloading"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request, student_id, file_type, *args, **kwargs):
        """Get file information without downloading the file"""
        # Check permissions (same as download view)
        if hasattr(request.user, 'school_admin'):
            try:
                student = Student.objects.get(
                    id=student_id, 
                    school=request.user.school_admin
                )
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        elif hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
            if student.id != student_id:
                return Response(
                    {"error": "You can only access your own files"}, 
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            return Response(
                {"error": "Permission denied"}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Get academic year
        academic_year = request.query_params.get('academic_year', now().year)
        
        try:
            test_results = StudentTestResults.objects.get(
                student=student, 
                academic_year=academic_year
            )
            
            # Get the requested file field
            file_field = None
            if file_type == 'personality_test':
                file_field = test_results.personality_test_file
            elif file_type == 'aptitude_test':
                file_field = test_results.aptitude_test_file
            elif file_type == 'percentile_results':
                file_field = test_results.percentile_results_file
            else:
                return Response(
                    {"error": "Invalid file type"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if not file_field or not file_field.name:
                return Response(
                    {"error": f"No {file_type} file found for this student"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Get file info from Azure
            try:
                from storage_backends import AzureMediaStorage
                azure_storage = AzureMediaStorage()
                
                file_path = file_field.name
                
                # Check if file exists and get info
                if not azure_storage.exists(file_path):
                    return Response(
                        {"error": "File not found in storage"}, 
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Get file size
                try:
                    file_size = azure_storage.size(file_path)
                except:
                    file_size = None
                
                # Get file URL (for viewing, not downloading)
                file_url = azure_storage.url(file_path)
                
                # Generate filename
                safe_student_name = student.user.name.replace(' ', '_').replace('/', '_')
                filename = f"{safe_student_name}_{file_type}_{academic_year}.csv"
                
                return Response({
                    "file_info": {
                        "filename": filename,
                        "file_path": file_path,
                        "file_size": file_size,
                        "file_type": file_type,
                        "academic_year": academic_year,
                        "view_url": file_url,
                        "download_url": f"{request.build_absolute_uri().replace('/info/', '/')}",
                    },
                    "student_info": {
                        "id": student.id,
                        "name": student.user.name,
                        "email": student.user.email,
                        "roll_number": student.roll_number
                    },
                    "storage_info": {
                        "storage_type": "Azure Blob Storage",
                        "container": azure_storage.azure_container,
                        "account": azure_storage.account_name
                    }
                }, status=status.HTTP_200_OK)
                
            except Exception as e:
                return Response(
                    {"error": f"Error accessing file info: {str(e)}"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
                
        except StudentTestResults.DoesNotExist:
            return Response(
                {"error": "No test results found for this student"}, 
                status=status.HTTP_404_NOT_FOUND
            )

class TalkToCareerExpertView(APIView):
    """API view for students to submit career counseling requests"""
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    @swagger_auto_schema(
        operation_description="Submit a career counseling request",
        request_body=CareerCounselingRequestSerializer,
        responses={
            201: CareerCounselingRequestResponseSerializer,
            400: "Bad Request - Validation errors",
            500: "Internal Server Error"
        }
    )
    def post(self, request, *args, **kwargs):
        """Handle career counseling request submission"""
        try:
            # Get the authenticated student
            try:
                student = Student.objects.get(user=request.user)
            except Student.DoesNotExist:
                return Response(
                    {"error": "Student profile not found"}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Validate the request data
            serializer = CareerCounselingRequestSerializer(data=request.data)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            # Extract validated data
            validated_data = serializer.validated_data
            name = validated_data['name']
            email = validated_data['email']
            phone = validated_data['phone']
            career_field = validated_data['career_field']
            pdf_file = validated_data['pdf_file']
            
            print(f"Processing career counseling request for student: {student.user.name}")
            
            # Create the CareerCounselingRequest object (without saving files yet)
            counseling_request = CareerCounselingRequest(
                student=student,
                name=name,
                email=email,
                phone=phone,
                career_field=career_field,
                counselor_email=getattr(settings, 'DEFAULT_COUNSELOR_EMAIL', 'counselor@example.com')
            )
            
            # Save files to Azure storage
            try:
                # Save PDF file
                pdf_result = self._save_pdf_to_azure(counseling_request, pdf_file)
                if not pdf_result['success']:
                    return Response(
                        {"error": f"Failed to save PDF file: {pdf_result['error']}"}, 
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )
                
                # Save JSON response data
                json_result = self._save_json_to_azure(counseling_request, validated_data)
                if not json_result['success']:
                    return Response(
                        {"error": f"Failed to save response data: {json_result['error']}"}, 
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )
                
                # Update the counseling request with file paths
                counseling_request.pdf_file = pdf_result['file_path']
                counseling_request.response_json = json_result['file_path']
                counseling_request.save()
                
                print(f"Files saved successfully for request ID: {counseling_request.id}")
                
            except Exception as e:
                print(f"Error saving files: {str(e)}")
                return Response(
                    {"error": f"File storage error: {str(e)}"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Send email to counselor
            try:
                email_result = self._send_counselor_email(counseling_request)
                if email_result['success']:
                    counseling_request.email_status = 'sent'
                    counseling_request.email_sent_at = now()
                    counseling_request.mailchimp_email_id = email_result.get('email_id')
                    counseling_request.email_content = email_result.get('email_content')
                else:
                    counseling_request.email_status = 'failed'
                    return Response(
                        {"error": f"Failed to send email: {email_result['error']}"}, 
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )
                
                counseling_request.save()
                print(f"Email sent successfully for request ID: {counseling_request.id}")
                
            except Exception as e:
                counseling_request.email_status = 'failed'
                counseling_request.save()
                print(f"Email sending error: {str(e)}")
                return Response(
                    {"error": f"Email sending error: {str(e)}"}, 
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Return success response
            response_serializer = CareerCounselingRequestResponseSerializer(counseling_request)
            return Response({
                "success": True,
                "message": "Career counseling request submitted successfully",
                "data": response_serializer.data
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response(
                {"error": f"Unexpected error: {str(e)}"}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def _save_pdf_to_azure(self, counseling_request, pdf_file):
        """Save the PDF file to Azure storage"""
        try:
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            
            # Generate file path
            timestamp = now().strftime('%Y%m%d_%H%M%S')
            file_path = f"career_counseling/{counseling_request.student.school.id}/{counseling_request.student.id}/{timestamp}/career_council.pdf"
            
            # Reset file pointer and save
            pdf_file.seek(0)
            file_content = ContentFile(pdf_file.read())
            file_content.name = "career_council.pdf"
            
            # Save to Azure
            saved_path = azure_storage.save(file_path, file_content)
            
            # Verify file exists
            if not azure_storage.exists(saved_path):
                return {
                    'success': False,
                    'error': 'File was not saved to Azure storage'
                }
            
            return {
                'success': True,
                'file_path': saved_path,
                'file_url': azure_storage.url(saved_path)
            }
            
        except Exception as e:
            print(f"Error saving PDF to Azure: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _save_json_to_azure(self, counseling_request, form_data):
        """Save the form response as JSON to Azure storage"""
        try:
            from storage_backends import AzureMediaStorage
            azure_storage = AzureMediaStorage()
            
            # Prepare JSON data
            json_data = {
                'student_info': {
                    'student_id': counseling_request.student.id,
                    'student_name': counseling_request.student.user.name,
                    'school_name': counseling_request.student.school.name,
                    'school_id': counseling_request.student.school.id
                },
                'form_data': {
                    'name': form_data['name'],
                    'email': form_data['email'],
                    'phone': form_data['phone'],
                    'career_field': form_data['career_field']
                },
                'metadata': {
                    'submitted_at': now().isoformat(),
                    'user_agent': self.request.META.get('HTTP_USER_AGENT', ''),
                    'ip_address': self.request.META.get('REMOTE_ADDR', '')
                }
            }
            
            # Generate file path
            timestamp = now().strftime('%Y%m%d_%H%M%S')
            file_path = f"career_counseling/{counseling_request.student.school.id}/{counseling_request.student.id}/{timestamp}/form_data.json"
            
            # Create JSON content
            json_content = ContentFile(json.dumps(json_data, indent=2).encode('utf-8'))
            json_content.name = "form_data.json"
            
            # Save to Azure
            saved_path = azure_storage.save(file_path, json_content)
            
            return {
                'success': True,
                'file_path': saved_path,
                'file_url': azure_storage.url(saved_path)
            }
            
        except Exception as e:
            print(f"Error saving JSON to Azure: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _send_counselor_email(self, counseling_request):
        """Send email to career counselor using Mailchimp"""
        try:
            # Get Mailchimp configuration
            api_key = getattr(settings, 'MAILCHIMP_TRANSACTIONAL_API_KEY', None)

            print(f"DEBUG: API Key from settings: {api_key}")
            print(f"DEBUG: API Key length: {len(api_key) if api_key else 0}")
            print(f"DEBUG: API Key starts with: {api_key[:10] if api_key else 'None'}...")

            from_email = getattr(settings, 'FROM_EMAIL', 'noreply@mycarermyway.com')
            from_name = getattr(settings, 'FROM_NAME', 'Career Guidance System')
            
            if not api_key:
                return {
                    'success': False,
                    'error': 'Mailchimp API key not configured'
                }
            
            # Initialize Mailchimp client
            mailchimp = MailchimpTransactional.Client(api_key)
            
            # Create email content using the same template as run.py
            subject, html_body, text_body = self._create_email_template(counseling_request)
            
            # Prepare message
            message = {
                "html": html_body,
                "text": text_body,
                "subject": subject,
                "from_email": from_email,
                "from_name": from_name,
                "to": [
                    {
                        "email": counseling_request.counselor_email,
                        "name": "Career Counselor",
                        "type": "to"
                    }
                ],
                "headers": {"Reply-To": counseling_request.email},
                "important": True,
                "track_opens": True,
                "track_clicks": True,
                "auto_text": True,
                "auto_html": False,
                "inline_css": True,
            }
            
            # Add PDF attachment if available
            if counseling_request.pdf_file:
                try:
                    attachment = self._prepare_email_attachment(counseling_request.pdf_file)
                    if attachment:
                        message["attachments"] = [attachment]
                except Exception as e:
                    print(f"Warning: Could not attach PDF file: {str(e)}")
            
            # Send email
            response = mailchimp.messages.send({
                "message": message,
                "async": False,
                "ip_pool": "Main Pool"
            })
            
            # Check response
            if response and len(response) > 0:
                result = response[0]
                if result['status'] in ['sent', 'queued', 'scheduled']:
                    return {
                        'success': True,
                        'email_id': result.get('_id'),
                        'status': result['status'],
                        'recipient': result['email'],
                        'email_content': html_body
                    }
                else:
                    return {
                        'success': False,
                        'error': f"Email failed to send. Status: {result['status']}, Reason: {result.get('reject_reason', 'Unknown')}"
                    }
            else:
                return {
                    'success': False,
                    'error': "No response from email service"
                }
                
        except ApiClientError as error:
            return {
                'success': False,
                'error': f"Mailchimp API error: {error.text}"
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"Email error: {str(e)}"
            }
    
    def _create_email_template(self, counseling_request):
        """Create email template similar to run.py"""
        name = counseling_request.name
        career = counseling_request.career_field
        email = counseling_request.email
        phone = counseling_request.phone
        
        subject = "Request for Career Guidance Based on Aptitude and Personality Test Results"
        
        html_body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #2c3e50;">Career Guidance Request</h2>
                
                <p>Dear Career Counselor,</p>
                
                <p>I hope this message finds you well.</p>
                
                <p>I recently completed a series of aptitude and personality assessments and have attached the results for your review. I am currently exploring potential career paths that align well with my strengths, interests, and personal traits, and I would greatly appreciate your expert guidance.</p>
                
                <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <h3 style="margin-top: 0; color: #495057;">Student Information:</h3>
                    <p><strong>Name:</strong> {name}</p>
                    <p><strong>Email:</strong> {email}</p>
                    <p><strong>Phone:</strong> {phone}</p>
                    <p><strong>Suggested Career Path:</strong> {career}</p>
                    <p><strong>School:</strong> {counseling_request.student.school.name}</p>
                    <p><strong>Student ID:</strong> {counseling_request.student.registration_no or counseling_request.student.id}</p>
                </div>
                
                <p>Please let me know your thoughts based on the attached reports. I am open to scheduling a meeting or call at your convenience to discuss this further.</p>
                
                <p>Thank you in advance for your time and support.</p>
                
                <p>Warm regards,<br>
                <strong>{name}</strong><br>
                {email}<br>
                {phone}</p>
                
                <hr style="border: none; border-top: 1px solid #dee2e6; margin: 30px 0;">
                <p style="font-size: 12px; color: #6c757d;">
                    This email was sent through the Career Guidance System at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                </p>
            </div>
        </body>
        </html>
        """
        
        text_body = f"""
Dear Career Counselor,

I hope this message finds you well.

I recently completed a series of aptitude and personality assessments and have attached the results for your review. I am currently exploring potential career paths that align well with my strengths, interests, and personal traits, and I would greatly appreciate your expert guidance.

Student Information:
- Name: {name}
- Email: {email}
- Phone: {phone}
- Suggested Career Path: {career}
- School: {counseling_request.student.school.name}
- Student ID: {counseling_request.student.registration_no or counseling_request.student.id}

Please let me know your thoughts based on the attached reports. I am open to scheduling a meeting or call at your convenience to discuss this further.

Thank you in advance for your time and support.

Warm regards,
{name}
{email}
{phone}

---
This email was sent through the Career Guidance System at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        return subject, html_body, text_body
    
    def _prepare_email_attachment(self, file_field):
        """Prepare file attachment for email"""
        try:
            import base64
            from storage_backends import AzureMediaStorage
            
            azure_storage = AzureMediaStorage()
            
            # Read file content from Azure
            with azure_storage.open(file_field.name, 'rb') as f:
                file_content = f.read()
            
            # Encode to base64
            content = base64.b64encode(file_content).decode('utf-8')
            
            return {
                "type": "application/pdf",
                "name": "career_council.pdf",
                "content": content
            }
            
        except Exception as e:
            print(f"Error preparing attachment: {e}")
            return None

# new api feedback models

class FeedbackQuestionsView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    def get(self, request, fid, *args, **kwargs):
        questions = FeedbackQuestion.objects.filter(fid=fid)
        if not questions.exists():
            return Response({'message': 'No data found'}, status=404)
        serializer = serializers.FeedbackQuestionSerializer(questions, many=True)
        return Response(serializer.data)


class SubmitFeedbackView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(request_body=FeedbackSubmissionSerializer)
    def post(self, request, *args, **kwargs):
        serializer = FeedbackSubmissionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'message': 'Feedback submitted successfully'}, status=status.HTTP_201_CREATED)

class FeedbackSubmissionRetrieveView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request, user_id, fid):
        try:
            submission = FeedbackSubmission.objects.get(user_id=user_id, fid=fid)
            data = {
                "user_id": submission.user_id,
                "fid": submission.fid,
                "responses": submission.responses,
                "submitted_at": submission.submitted_at,
            }
            return Response(data, status=status.HTTP_200_OK)
        except FeedbackSubmission.DoesNotExist:
            return Response({"message": "No submission found"}, status=status.HTTP_404_NOT_FOUND)
        
# leadership trait get api
class LeadershipTraitDetailView(APIView):
    """
    Retrieve a single leadership trait by its name
    """
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                'leadership_trait_name',
                openapi.IN_PATH,
                description="Name of the leadership trait (case-sensitive)",
                type=openapi.TYPE_STRING
            )
        ],
        responses={200: LeadershipTraitSerializer()}
    )
    def get(self, request, leadership_trait_name, *args, **kwargs):
        try:
            trait = LeadershipTrait.objects.get(leadership_trait_name=leadership_trait_name)
        except LeadershipTrait.DoesNotExist:
            return Response({"error": "Leadership trait not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = LeadershipTraitSerializer(trait)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
#leadership trait list api
class LeadershipTraitListView(APIView):
    """
    GET: Return all leadership traits with their details
    """
    permission_classes = [IsAuthenticated]
    @swagger_auto_schema(
        operation_description="List all leadership traits with full details",
        responses={200: LeadershipTraitSerializer(many=True)}
    )
    def get(self, request):
        traits = LeadershipTrait.objects.all()
        serializer = LeadershipTraitSerializer(traits, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

class StudentPercentileMarksSubmitView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    def post(self, request):
        student_id = request.data.get('student_id')
        try:
            instance = StudentPercentileMarks.objects.get(student_id=student_id)
            serializer = StudentPercentileMarksSerializer(instance, data=request.data)
        except StudentPercentileMarks.DoesNotExist:
            serializer = StudentPercentileMarksSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(
                {
                    "message": "Mark submitted successfully",
                    "data": serializer.data
                },
                status=status.HTTP_200_OK
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class StudentPercentileMarksRetrieveView(APIView):
    permission_classes = [IsAuthenticated]
    renderer_classes = [ResponseRenderer]

    def get(self, request, student_id):
        try:
            obj = StudentPercentileMarks.objects.get(student_id=student_id)
        except StudentPercentileMarks.DoesNotExist:
            return Response(
                {"message": "Student data not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        serializer = StudentPercentileMarksSerializer(obj)
        return Response(serializer.data, status=status.HTTP_200_OK)