from django.utils.timezone import now
from django.db import models
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.core.files.base import ContentFile
import json
from . import openai_service
import logging
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.files.storage import default_storage
import csv
from django.http import HttpResponse
from textblob import TextBlob
from fuzzywuzzy import fuzz

from storage_backends import AzureMediaStorage
from .models import (
    PersonalityTestChatMessage, Student, Career, AdaptiveTestQuestion, AdaptiveTestSession, 
    AdaptiveTestResponse, AdaptiveTestChatMessage,
    PersonalityTestQuestion, PersonalityTestSession, PersonalityTestResponse, GeneralTestSession, GeneralTestChatMessage, GeneralTestQuestion, GeneralTestResponse, GeneralTestAIAnalysis
)
from .permissions import IsSchoolStudent
from api.renderers import ResponseRenderer
logger = logging.getLogger(__name__)

class ChatAPIView(APIView):
    
    """
    Unified ChatBot API for both adaptive and personality tests.
    
    GET: Returns the conversation history and current state
    POST: Processes user messages and advances the conversation
    """
    permission_classes = [IsAuthenticated, IsSchoolStudent]
    renderer_classes = [ResponseRenderer]
    
    def get(self, request):
        """Get the current conversation and test state or report"""
        try:
            # Check if this is a report request
            path = request.path
            if path.endswith('/report/'):
                return self.get_report(request)
                
            student = request.user.student_profile
            session_id = request.query_params.get('session_id')
            test_type = request.query_params.get('test_type')
            
            if not test_type:
                return Response(
                    {"error": "test_type is required. Please specify 'adaptive', 'personality', or 'general'"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Check if test_type is valid
            if test_type not in ['adaptive', 'personality', 'general']:
                return Response(
                    {"error": "Invalid test_type. Must be 'adaptive', 'personality', or 'general'"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Route to the appropriate handler based on test_type
            if test_type == 'adaptive':
                return self._get_adaptive_test(request, student, session_id)
            elif test_type == 'personality':
                return self._get_personality_test(request, student, session_id)
            elif test_type == 'general':
                return self._get_general_test(request, student, session_id)
            
        except Exception as e:
            print(f"Error in GET /api/chat: {str(e)}")
            import traceback
            traceback.print_exc()
            return Response(
                {
                    "status": "error",
                    "message": f"An error occurred: {str(e)}"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request):
        """Process user messages"""
        try:
            # Extract basic data
            session_id = request.data.get('session_id')
            message = request.data.get('message')
            test_type = request.data.get('test_type')
            
            if not test_type:
                return Response(
                    {"error": "test_type is required. Please specify 'adaptive', 'personality', or 'general'"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Check if test_type is valid
            if test_type not in ['adaptive', 'personality', 'general']:
                return Response(
                    {"error": "Invalid test_type. Must be 'adaptive', 'personality', or 'general'"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if not message:
                return Response(
                    {
                        "status": "error",
                        "message": "Message is required"
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            student = request.user.student_profile

            # Route to the appropriate handler based on test_type
            if test_type == 'adaptive':
                return self._post_adaptive_test(request, student, session_id, message, test_type)
            elif test_type == 'personality':
                return self._post_personality_test(request, student, session_id, message, test_type)
            elif test_type == 'general':
                return self._post_general_test(request, student, session_id, message, test_type)
                
        except Exception as e:
            print(f"Error in POST /api/chat: {str(e)}")
            import traceback
            traceback.print_exc()
            return Response(
                {
                    "status": "error",
                    "message": f"An error occurred: {str(e)}"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def get_report(self, request):
        """Get test reports"""
        try:
            student = request.user.student_profile
            session_id = request.query_params.get('session_id')
            test_type = request.query_params.get('test_type')
            student_id = request.query_params.get('student_id')
            
            if not test_type:
                return Response(
                    {"error": "test_type is required. Please specify 'adaptive' or 'personality'"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Report by student_id (admin functionality)
            if student_id:
                if test_type == 'personality':
                    return self._get_personality_report_by_student(request, student_id)
                else:
                    return self._get_adaptive_report_by_student(request, student_id)
            
            # Report by session_id
            if session_id:
                if test_type == 'personality':
                    return self._get_personality_report_by_session(student, session_id)
                else:
                    return self._get_adaptive_report_by_session(student, session_id)
            
            # Invalid request
            return Response(
                {"error": "Please provide either session_id or student_id"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        except Exception as e:
            print(f"Error in GET /api/chat/report: {str(e)}")
            import traceback
            traceback.print_exc()
            return Response(
                {
                    "status": "error",
                    "message": f"An error occurred: {str(e)}"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )  
    
    # Handler methods for GET requests
    
    def _get_adaptive_test(self, request, student, session_id):
        """Handle GET request for adaptive test"""
        # If session_id provided, get that session
        if session_id:
            try:
                session = AdaptiveTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
            except AdaptiveTestSession.DoesNotExist:
                # Create a new session if the requested one doesn't exist
                session = self._create_new_adaptive_session(student)
        else:
            # CHANGE HERE: First look for any session, including inactive ones
            # If no session found or only completed ones exist, create a new one
            session = AdaptiveTestSession.objects.filter(
                student=student
            ).order_by('-created_at').first()
            
            if not session:
                session = self._create_new_adaptive_session(student)
        
        # Get the conversation history
        chat_messages = AdaptiveTestChatMessage.objects.filter(
            session=session
        ).order_by('timestamp')
        
        conversation = []
        next_question = None
        current_message = "Welcome to the Adaptive Aptitude Test!"
        
        for msg in chat_messages:
            # Format message for the conversation array
            chat_msg = {
                'sender': msg.sender,
                'message_type': msg.message_type,
                'content': msg.content,
                'timestamp': msg.timestamp
            }
            
            # Add options if it's a question
            if msg.message_type == 'question' and msg.metadata and 'options' in msg.metadata:
                # Transform options to use letter keys (a, b, c, d) while preserving values
                original_options = msg.metadata['options']
                transformed_options = {}
                
                # Create letter keys for options (a, b, c, d)
                option_keys = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
                
                # Map letter keys to their values
                for i, (key, value) in enumerate(original_options.items()):
                    if i < len(option_keys):
                        transformed_options[option_keys[i]] = str(value)
                
                chat_msg['options'] = transformed_options
                chat_msg['original_options_mapping'] = original_options  # Keep original mapping
                
                # Set as the current question if it's the most recent question without an answer
                if not AdaptiveTestResponse.objects.filter(
                    session=session,
                    question_id=msg.metadata.get('question_id')
                ).exists():
                    next_question = {
                        'question_id': msg.metadata.get('question_id'),
                        'question_text': msg.content,
                        'options': transformed_options,
                        'original_options_mapping': original_options  # Keep original mapping
                    }
                    if 'image' in msg.metadata and msg.metadata['image']:
                        next_question['image_url'] = self._get_image_url(request, msg.metadata['image'])
            
            # Add image URL if present
            if msg.metadata and 'image' in msg.metadata and msg.metadata['image']:
                chat_msg['image_url'] = self._get_image_url(request, msg.metadata['image'])
            
            conversation.append(chat_msg)
            
            # Update current message based on most recent message
            if msg.message_type in ['explanation', 'greeting', 'category_selection']:
                current_message = msg.content
        
        # Determine status
        status_value = "success"
        
        # First check if session is completed - prioritize showing the test report
        if not session.is_active and session.completed_at:
            # Generate test report
            test_report = self._generate_adaptive_test_report(session)
            
            return Response({
                "status": status_value,
                "message": "Test completed!",
                "conversation": conversation,
                "test_report": test_report,
                "session_id": str(session.session_id),
                "test_type": "adaptive"
            })
        
        # Then check if no category selected (moved this to second priority)
        if not session.current_category and not next_question:
            # Get categories
            categories = AdaptiveTestQuestion.objects.values_list(
                'category', flat=True
            ).distinct()
            
            # Filter out completed categories
            completed_categories = []
            if session.metrics and 'completed_categories' in session.metrics:
                completed_categories = session.metrics['completed_categories']
            
            # Filter available categories to remove completed ones
            categories = [c for c in categories if c not in completed_categories]
            
            # Format category data as direct key-value pairs
            # The key is the category ID which will be sent back from frontend
            category_options = {}
            for category in categories:
                display_name = category.replace('_', ' ').title()
                category_options[category] = display_name
            
            # Include completed categories for reference
            completed_category_names = [c.replace('_', ' ').title() for c in completed_categories]
            
            # If no categories left, add completion message
            if not categories:
                message = "You've completed all available categories! Here's your overall test report."
                # Generate final test report
                test_report = self._generate_adaptive_test_report(session)
                
                # Mark session as fully completed if all categories are done
                session.is_active = False
                session.completed_at = now()
                session.save()

                # Add completion message to conversation
                conversation.append({
                    'sender': 'system',
                    'message_type': 'completion',
                    'content': message,
                    'timestamp': now()
                })
                
                return Response({
                    "status": "success",
                    "message": message,
                    "conversation": conversation,
                    "test_report": test_report,
                    "session_id": str(session.session_id),
                    "test_type": "adaptive"
                })
            
            # Add available categories as a message in the conversation
            category_message = {
                'sender': 'system',
                'message_type': 'categories',
                'content': "Please select a category to begin.",
                'timestamp': now(),
                'options': category_options,
                'completed_categories': completed_category_names
            }
            
            # Add to conversation
            conversation.append(category_message)
            
            # Set as next_question
            next_question = {
                'question_id': 'category_selection',
                'question_text': "Please select a category to begin.",
                'options': category_options,
                'completed_categories': completed_category_names,
                'is_category_selection': True
            }
            
            # Normal response with available categories in conversation
            return Response({
                "status": "success",
                "message": current_message,
                "conversation": conversation,
                "next_question": next_question,
                "session_id": str(session.session_id),
                "test_type": "adaptive"
            })
        
        # Regular response with next question
        response_data = {
            "status": status_value,
            "message": current_message,
            "conversation": conversation,
            "session_id": str(session.session_id),
            "test_type": "adaptive"
        }
        
        # Add next question if available
        if next_question:
            response_data["next_question"] = next_question
        
        return Response(response_data)
    
    def _get_personality_test(self, request, student, session_id):
        """Handle GET request for personality test"""
        # If session_id provided, get that session
        if session_id:
            try:
                session = PersonalityTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
            except PersonalityTestSession.DoesNotExist:
                # Create a new session if the requested one doesn't exist
                session = self._create_new_personality_session(student)
        else:
            # Look for any existing personality session
            session = PersonalityTestSession.objects.filter(
                student=student
            ).order_by('-created_at').first()
            
            if not session:
                session = self._create_new_personality_session(student)
        
        # Get the conversation history
        chat_messages = PersonalityTestChatMessage.objects.filter(
            session=session
        ).order_by('timestamp')
        
        conversation = []
        next_question = None
        current_message = "Welcome to your personality test!"
        
        for msg in chat_messages:
            # Format message for the conversation array
            chat_msg = {
                'sender': msg.sender,
                'message_type': msg.message_type,
                'content': msg.content,
                'timestamp': msg.timestamp
            }
            
            # Add options if it's a question
            if msg.message_type == 'question' and msg.metadata and 'options' in msg.metadata:
                chat_msg['options'] = msg.metadata['options']
                
                # Set as the current question if it's the most recent question without an answer
                if not PersonalityTestResponse.objects.filter(
                    session=session,
                    question_id=msg.metadata.get('question_id')
                ).exists():
                    next_question = {
                        'question_id': msg.metadata.get('question_id'),
                        'question_text': msg.content,
                        'options': msg.metadata['options']
                    }
            
            conversation.append(chat_msg)
            
            # Update current message based on most recent message
            if msg.message_type in ['greeting', 'question']:
                current_message = msg.content
        
        # If session is completed, return the results
        if not session.is_active and session.completed_at:
            # Add completion message if not already in conversation
            completion_msg_exists = any(
                msg.message_type == 'completion' for msg in chat_messages
            )
            
            if not completion_msg_exists:
                completion_message = {
                    'sender': 'system',
                    'message_type': 'completion',
                    'content': f"Personality test completed! Your personality type is {session.personality_type}.",
                    'timestamp': session.completed_at
                }
                conversation.append(completion_message)
            
            # Generate personality test report
            personality_report = self._generate_personality_test_report(session)
            
            return Response({
                "status": "success",
                "message": f"Personality test completed! Your personality type is {session.personality_type}.",
                "conversation": conversation,
                "test_report": personality_report,
                "session_id": str(session.session_id),
                "test_type": "personality",
                "is_complete": True,
                "personality_type": session.personality_type
            })
        
        # Get the next question if no current question in conversation
        if not next_question:
            current_question = session.get_next_question()
            
            if current_question:
                # Add question to conversation if it's not already there
                question_in_conversation = any(
                    msg.metadata and msg.metadata.get('question_id') == current_question.id 
                    for msg in chat_messages if msg.metadata
                )
                
                if not question_in_conversation:
                    # Add question to chat
                    PersonalityTestChatMessage.objects.create(
                        session=session,
                        sender='system',
                        content=f"Question {session.responses.count() + 1}: Choose the option that best describes you.",
                        message_type='question',
                        metadata={
                            'question_id': current_question.id,
                            'options': current_question.options,
                            'dimension': current_question.dimension_display
                        }
                    )
                    
                    # Add to conversation
                    question_msg = {
                        'sender': 'system',
                        'message_type': 'question',
                        'content': f"Question {session.responses.count() + 1}: Choose the option that best describes you.",
                        'timestamp': now(),
                        'options': current_question.options
                    }
                    conversation.append(question_msg)
                    
                    next_question = {
                        'question_id': current_question.id,
                        'question_text': f"Question {session.responses.count() + 1}: Choose the option that best describes you.",
                        'options': current_question.options,
                        'dimension': current_question.dimension_display,
                        'question_number': session.responses.count() + 1,
                        'total_questions': PersonalityTestQuestion.objects.count()
                    }
            else:
                # No more questions but session not marked as completed
                if session.is_active:
                    session.is_active = False
                    session.completed_at = now()
                    session.calculate_result()
                    session.save()
                    
                    # Add completion message
                    PersonalityTestChatMessage.objects.create(
                        session=session,
                        sender='system',
                        content=f"Personality test completed! Your personality type is {session.personality_type}.",
                        message_type='completion'
                    )
                    
                    completion_message = {
                        'sender': 'system',
                        'message_type': 'completion',
                        'content': f"Personality test completed! Your personality type is {session.personality_type}.",
                        'timestamp': now()
                    }
                    conversation.append(completion_message)
                    
                    # Generate personality test report
                    personality_report = self._generate_personality_test_report(session)
                    
                    return Response({
                        "status": "success",
                        "message": f"Personality test completed! Your personality type is {session.personality_type}.",
                        "conversation": conversation,
                        "test_report": personality_report,
                        "session_id": str(session.session_id),
                        "test_type": "personality",
                        "is_complete": True,
                        "personality_type": session.personality_type
                    })
        
        # Regular response with conversation and next question
        response_data = {
            "status": "success",
            "message": current_message,
            "conversation": conversation,
            "session_id": str(session.session_id),
            "test_type": "personality"
        }
        
        # Add next question if available
        if next_question:
            response_data["next_question"] = next_question
        
        return Response(response_data)
    
    # Handler methods for POST requests
    
    def _post_adaptive_test(self, request, student, session_id, message, test_type):
        """Handle POST request for adaptive test"""
        # Get or create session
        if session_id:
            try:
                session = AdaptiveTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
            except AdaptiveTestSession.DoesNotExist:
                return Response(
                    {
                        "status": "error",
                        "message": f"Session with ID {session_id} not found"
                    },
                    status=status.HTTP_404_NOT_FOUND
                )
        else:
            # Create a new session if none specified
            session = self._create_new_adaptive_session(student)
        
        # Check for command keywords FIRST
        if message.lower() in ['exit', 'quit', 'finish', 'complete', 'end']:
            return self._handle_complete_adaptive_test(request, session, student, test_type)
            
        if message.lower() in ['start over', 'new test', 'reset', 'restart', 'start']:
            # Create a new session
            new_session = self._create_new_adaptive_session(student)
            
            # Add message to chat
            AdaptiveTestChatMessage.objects.create(
                session=new_session,
                sender='student',
                content=message,
                message_type='message'
            )
            
            # Add system response
            AdaptiveTestChatMessage.objects.create(
                session=new_session,
                sender='system',
                content="Starting a new test. Previous test data has been saved.",
                message_type='message'
            )
            
            # Return the new session state
            return self._get_adaptive_test(request, student, str(new_session.session_id))
        
        # Determine what to do based on the current state and message
        # 1. If no category selected, try to select a category
        if not session.current_category:
            return self._handle_adaptive_category_selection(request, session, message, student, test_type)
        
        # 2. If we have a current question, handle the answer
        # Get the latest question from chat history
        latest_question = AdaptiveTestChatMessage.objects.filter(
            session=session,
            message_type='question'
        ).order_by('-timestamp').first()
        
        if latest_question and latest_question.metadata and 'question_id' in latest_question.metadata:
            question_id = latest_question.metadata['question_id']
            
            # Check if this question has already been answered
            existing_response = AdaptiveTestResponse.objects.filter(
                session=session,
                question_id=question_id
            ).exists()
            
            if not existing_response:
                # This is an answer to the current question
                return self._handle_adaptive_answer_submission(
                    request,
                    session, 
                    question_id, 
                    message,
                    student,
                    test_type
                )
        
        # Otherwise, treat as general chat message
        # Add user message to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=message,
            message_type='message'
        )
        
        # Add a generic response
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content="Please answer the current question to continue.",
            message_type='message'
        )
        
        # Return updated conversation
        return self._get_adaptive_test(request, student, str(session.session_id))
    
    def _post_personality_test(self, request, student, session_id, message, test_type):
        """Handle POST request for personality test"""
        # Create new session if message is "start" and no session_id
        if message.lower() == "start" and not session_id:
            # Delete old reports from blob storage
            self._delete_previous_reports(student.id, 'personality')
            
            # Create new session
            session = self._create_new_personality_session(student)
            return self._get_personality_test(request, student, str(session.session_id))
        
        # Get existing session
        if session_id:
            try:
                session = PersonalityTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
            except PersonalityTestSession.DoesNotExist:
                return Response(
                    {
                        "status": "error",
                        "message": f"Session with ID {session_id} not found"
                    },
                    status=status.HTTP_404_NOT_FOUND
                )
        else:
            return Response(
                {
                    "status": "error",
                    "message": "Please provide a session_id or send 'start' to create a new session"
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Check for completed session
        if not session.is_active:
            return Response({
                "status": "error",
                "message": "This session has already been completed. Please start a new session.",
                "personality_type": session.personality_type,
                "is_complete": True,
                "test_type": "personality",
                "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=personality"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Check for command keywords
        if message.lower() in ['exit', 'quit', 'finish', 'complete', 'end']:
            return self._handle_complete_personality_test(request, session, student, test_type)
            
        if message.lower() in ['start over', 'new test', 'reset', 'restart']:
            # Delete old reports
            self._delete_previous_reports(student.id, 'personality')
            
            # Create a new session
            new_session = self._create_new_personality_session(student)
            return self._get_personality_test(request, student, str(new_session.session_id))
        
        # Process answer submission
        # Get current question from the latest question message
        latest_question_msg = PersonalityTestChatMessage.objects.filter(
            session=session,
            message_type='question'
        ).order_by('-timestamp').first()
        
        if not latest_question_msg or not latest_question_msg.metadata:
            return Response(
                {"error": "No current question found"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        question_id = latest_question_msg.metadata.get('question_id')
        
        # Check if this question has already been answered
        existing_response = PersonalityTestResponse.objects.filter(
            session=session,
            question_id=question_id
        ).exists()
        
        if existing_response:
            return Response(
                {"error": "This question has already been answered"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get the actual question
        try:
            current_question = PersonalityTestQuestion.objects.get(id=question_id)
        except PersonalityTestQuestion.DoesNotExist:
            return Response(
                {"error": "Question not found"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate answer (should be A or B)
        if message.upper() not in ['A', 'B']:
            return Response(
                {"error": "Invalid answer. Please select A or B."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Normalize answer
        selected_option = message.upper()
        
        # Add user answer to chat
        answer_text = current_question.options.get(selected_option, selected_option)
        PersonalityTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=f"{selected_option}: {answer_text}",
            message_type='answer'
        )
        
        # Save response
        PersonalityTestResponse.objects.create(
            session=session,
            question=current_question,
            selected_option=selected_option
        )
        
        # Get next question
        next_question = session.get_next_question()
        total_questions = PersonalityTestQuestion.objects.count()
        current_count = session.responses.count()
        
        if next_question:
            # There are more questions - add next question to chat
            PersonalityTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=f"Question {current_count + 1}: Choose the option that best describes you.",
                message_type='question',
                metadata={
                    'question_id': next_question.id,
                    'options': next_question.options,
                    'dimension': next_question.dimension_display
                }
            )
            
            # Return updated conversation
            return self._get_personality_test(request, student, str(session.session_id))
        else:
            # Test is complete
            session.completed_at = now()
            session.is_active = False
            results = session.calculate_result()
            
            # Add completion message to chat
            PersonalityTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=f"Personality test completed! Your personality type is {results['personality_type']}.",
                message_type='completion'
            )
            
            # Return final conversation with completion
            return self._get_personality_test(request, student, str(session.session_id))
        
        # Check for completed session
        if not session.is_active:
            return Response({
                "status": "error",
                "message": "This session has already been completed. Please start a new session.",
                "personality_type": session.personality_type,
                "is_complete": True,
                "test_type": "personality",
                "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=personality"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Check for command keywords
        if message.lower() in ['exit', 'quit', 'finish', 'complete', 'end']:
            return self._handle_complete_personality_test(request, session, student, test_type)
            
        if message.lower() in ['start over', 'new test', 'reset', 'restart', 'start']:
            # Delete old reports
            self._delete_previous_reports(student.id, 'personality')
            
            # Create a new session
            new_session = self._create_new_personality_session(student)
            return self._get_personality_test(request, student, str(new_session.session_id))
        
        # Process answer submission
        # Get current question
        current_question = session.get_next_question()
        
        if not current_question:
            return Response(
                {"error": "No more questions available"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate answer (should be A or B)
        if message.upper() not in ['A', 'B']:
            return Response(
                {"error": "Invalid answer. Please select A or B."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Normalize answer
        selected_option = message.upper()
        
        # Save response
        PersonalityTestResponse.objects.create(
            session=session,
            question=current_question,
            selected_option=selected_option
        )
        
        # Get next question
        next_question = session.get_next_question()
        total_questions = PersonalityTestQuestion.objects.count()
        current_count = session.responses.count()
        
        if next_question:
            # There are more questions
            question_data = {
                'question_id': next_question.id,
                'dimension': next_question.dimension_display,
                'options': next_question.options,
                'question_number': current_count + 1,
                'total_questions': total_questions
            }
            
            return Response({
                "status": "success",
                "answer_saved": True,
                "session_id": str(session.session_id),
                "is_complete": False,
                "test_type": "personality",
                "question": question_data,
                "progress": {
                    "completed": current_count,
                    "total": total_questions
                }
            })
        else:
            # Test is complete
            session.completed_at = now()
            session.is_active = False
            results = session.calculate_result()
            
            # Generate report
            report = self._generate_personality_test_report(session)
            
            return Response({
                "status": "success",
                "answer_saved": True,
                "session_id": str(session.session_id),
                "is_complete": True,
                "test_type": "personality",
                "message": "Thank you for completing the personality test! Your results are ready.",
                "personality_type": results["personality_type"],
                "test_report": report,
                "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=personality"
            })
    
    # Helper methods for adaptive test
    
    def _create_new_adaptive_session(self, student):
        """Create a new adaptive test session with welcome message"""
        # Delete old reports from blob storage
        self._delete_previous_reports(student.id, 'adaptive')
        
        session = AdaptiveTestSession.objects.create(
            student=student,
            is_active=True
        )
        
        # Add welcome message
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content='Welcome to the Adaptive Aptitude Test! Choose a category to begin.',
            message_type='greeting'
        )
        
        return session
    
    def _handle_adaptive_category_selection(self, request, session, message, student, test_type):
        """Handle category selection for adaptive test"""
        # Find the category that best matches the message
        categories = AdaptiveTestQuestion.objects.values_list(
            'category', flat=True
        ).distinct()
        
        selected_category = None
        for category in categories:
            display_name = category.replace('_', ' ').title()
            if message.lower() == category.lower() or message.lower() == display_name.lower():
                selected_category = category
                break
        
        # If no direct match, try fuzzy matching
        if not selected_category:
            for category in categories:
                display_name = category.replace('_', ' ').title()
                if fuzz.ratio(message.lower(), category.lower()) > 80 or \
                   fuzz.ratio(message.lower(), display_name.lower()) > 80:
                    selected_category = category
                    break
        
        if not selected_category:
            # No category match found
            # Add user message to chat
            AdaptiveTestChatMessage.objects.create(
                session=session,
                sender='student',
                content=message,
                message_type='message'
            )
            
            # Add response message
            AdaptiveTestChatMessage.objects.create(
                session=session,
                sender='system',
                content="I'm not sure which category you want to select. Please choose from the available categories.",
                message_type='message'
            )
            
            return self._get_adaptive_test(request, student, str(session.session_id))
        
        # Valid category selected
        # Update session
        session.current_category = selected_category
        session.save()
        
        # Add user message to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=message,
            message_type='message'
        )
        
        # Add category selection message
        display_name = selected_category.replace('_', ' ').title()
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=f"You've selected {display_name}. Let's begin!",
            message_type='category_selection'
        )
        
        # Get first question
        question = self._get_next_adaptive_question(session)
        
        if not question:
            # No questions found
            AdaptiveTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=f"Sorry, there are no questions available in the {display_name} category.",
                message_type='message'
            )
            
            return self._get_adaptive_test(request, student, str(session.session_id))
        
        # Add question to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=question.question_text,
            message_type='question',
            metadata={
                'question_id': question.id,
                'options': question.options,
                'image': question.image
            }
        )
        
        # Return updated conversation with question
        return self._get_adaptive_test(request, student, str(session.session_id))
    
    def _handle_adaptive_answer_submission(self, request, session, question_id, answer, student, test_type):
        """Handle answer submission for adaptive test"""
        # Get the question
        try:
            question = AdaptiveTestQuestion.objects.get(id=question_id)
        except AdaptiveTestQuestion.DoesNotExist:
            return Response(
                {
                    "status": "error",
                    "message": f"Question with ID {question_id} not found"
                },
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Process the answer
        start_time = AdaptiveTestChatMessage.objects.filter(
            session=session,
            message_type='question',
            metadata__question_id=question_id
        ).order_by('-timestamp').first().timestamp
        
        # Calculate response time (in seconds)
        response_time = (now() - start_time).total_seconds()
        
        # First try to check if the answer is the actual value not a letter key
        # Find out which letter key this answer corresponds to
        letter_key = None
        for key, value in question.options.items():
            if str(answer).strip() == str(value).strip():
                letter_key = key
                break
        
        # If we found a matching value, use the letter key
        if letter_key:
            answer = letter_key
        
        is_correct, corrected_answer = self._process_adaptive_answer(answer, question)
        
        # Add user answer to chat with the actual content, not just the letter
        # Get the full text of what the user selected
        answer_content = answer
        if answer.lower() in ['a', 'b', 'c', 'd', 'e'] and question.options:
            answer_content = question.options.get(answer.lower(), answer)
        
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=answer_content,  # Use the full text of the option
            message_type='answer'
        )
        
        # Store the response
        AdaptiveTestResponse.objects.create(
            session=session,
            question=question,
            student_answer=answer,
            corrected_answer=corrected_answer,
            is_correct=is_correct,
            response_time=response_time
        )
        
        # Add explanation to chat
        explanation = question.explanation or "Moving to next question."
        
        # Get the full text of the correct answer
        correct_option_text = question.options.get(question.correct_answer.lower(), question.correct_answer)
        feedback = "Correct answer! " if is_correct else f"Not quite correct. The answer is {correct_option_text}. "
        
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=f"{feedback}{explanation}",
            message_type='explanation'
        )
        
        # Update session metrics
        self._update_adaptive_session_metrics(session)
        
        # Get next question
        next_question = self._get_next_adaptive_question(session)
        
        # Check if test is complete (no more questions)
        if not next_question:
            # Don't mark session as inactive, just mark this category as completed
            # and clear current_category to allow selection of a new one
            
            # Initialize metrics if not exist
            if not session.metrics:
                session.metrics = {}
            
            # Initialize completed_categories if not exist    
            if 'completed_categories' not in session.metrics:
                session.metrics['completed_categories'] = []
            
            # Add current category to completed list if not already there
            if session.current_category not in session.metrics['completed_categories']:
                session.metrics['completed_categories'].append(session.current_category)
            
            # Mark category completion time
            category_completion_time = now()
            if 'category_completion_times' not in session.metrics:
                session.metrics['category_completion_times'] = {}
            
            session.metrics['category_completion_times'][session.current_category] = category_completion_time.isoformat()
            
            # Clear current category to allow selection of a new one
            completed_category = session.current_category
            session.current_category = None
            
            # Check if all categories are completed
            all_categories = set(AdaptiveTestQuestion.objects.values_list('category', flat=True).distinct())
            completed_categories = set(session.metrics['completed_categories'])
            remaining_categories = all_categories - completed_categories
            
            completion_message = ""
            
            if not remaining_categories:
                # All categories completed, mark session as completed
                session.is_active = False
                session.completed_at = now()
                completion_message = "You've completed all available categories! Here's your overall test report."
                
                # Add completion message to chat
                AdaptiveTestChatMessage.objects.create(
                    session=session,
                    sender='system',
                    content=completion_message,
                    message_type='completion'
                )
            else:
                # Some categories remain
                completion_message = f"You've completed all questions in the {completed_category.replace('_', ' ').title()} category! You can now select another category."
                
                # Add completion message to chat
                AdaptiveTestChatMessage.objects.create(
                    session=session,
                    sender='system',
                    content=completion_message,
                    message_type='completion'
                )
            
            # Save session changes
            session.save()
            
            # Return updated state with available categories
            return self._get_adaptive_test(request, student, str(session.session_id))
        
        # Add next question to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content=next_question.question_text,
            message_type='question',
            metadata={
                'question_id': next_question.id,
                'options': next_question.options,
                'image': next_question.image
            }
        )
        
        # Return updated conversation with feedback and next question
        return self._get_adaptive_test(request, student, str(session.session_id))
    
    def _handle_complete_adaptive_test(self, request, session, student, test_type):
        """Handle completion of adaptive test"""
        if not session.is_active:
            return Response(
                {
                    "status": "error",
                    "message": "Test session is already completed"
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Mark the session as complete
        session.is_active = False
        session.completed_at = now()
        session.save()
        
        # Add completion message to chat
        AdaptiveTestChatMessage.objects.create(
            session=session,
            sender='system',
            content="You've completed the test.",
            message_type='completion'
        )
        
        # Return completed test
        return self._get_adaptive_test(request, student, str(session.session_id))
    
    def _get_next_adaptive_question(self, session):
        """Get the next question for adaptive test based on adaptive algorithm"""
        category = session.current_category
        
        if not category:
            return None
        
        # Get questions already answered in this session
        answered_question_ids = AdaptiveTestResponse.objects.filter(
            session=session
        ).values_list('question_id', flat=True)
        
        # Get previous responses to calculate performance
        previous_responses = AdaptiveTestResponse.objects.filter(
            session=session,
            question__category=category
        )
        
        # Calculate current performance level
        if not previous_responses.exists():
            # First question - start with lowest difficulty
            target_difficulty = 1
        else:
            # Calculate accuracy
            correct_count = previous_responses.filter(is_correct=True).count()
            total_count = previous_responses.count()
            accuracy = correct_count / total_count
            
            # Adjust difficulty based on accuracy
            if accuracy > 0.8:
                # Increase difficulty for high performers
                max_difficulty = previous_responses.aggregate(
                    max_difficulty=models.Max('question__difficulty')
                )['max_difficulty'] or 1
                target_difficulty = max_difficulty + 1
            elif accuracy < 0.5:
                # Decrease difficulty for struggling students
                min_difficulty = previous_responses.aggregate(
                    min_difficulty=models.Min('question__difficulty')
                )['min_difficulty'] or 1
                target_difficulty = max(1, min_difficulty - 1)
            else:
                # Maintain similar difficulty
                avg_difficulty = previous_responses.aggregate(
                    avg_difficulty=models.Avg('question__difficulty')
                )['avg_difficulty'] or 1
                target_difficulty = round(avg_difficulty)
        
        # Find next question - exclude already answered questions
        available_questions = AdaptiveTestQuestion.objects.filter(
            category=category
        ).exclude(
            id__in=answered_question_ids
        )
        
        # If no more questions, return None
        if not available_questions.exists():
            return None
        
        # Get question closest to target difficulty
        closest_question = available_questions.filter(
            difficulty__gte=target_difficulty
        ).order_by('difficulty').first()
        
        # If no questions with higher difficulty, get the hardest available
        if not closest_question:
            closest_question = available_questions.order_by('-difficulty').first()
        
        return closest_question
    
    def _process_adaptive_answer(self, answer, question):
        """Process an answer for adaptive test to determine if it's correct"""
        # Clean up the answer
        user_answer = str(answer).strip().lower()
        correct_answer = str(question.correct_answer).strip().lower()
        
        # Direct match
        if user_answer == correct_answer:
            return True, None
        
        # Option match (e.g., 'a', 'b', 'c', 'd')
        if user_answer in ['a', 'b', 'c', 'd', 'e'] and user_answer == correct_answer:
            return True, None
        
        # Handle multi-choice options
        if question.options:
            # Check if user entered option value instead of key
            for key, value in question.options.items():
                if user_answer == str(value).strip().lower():
                    return key.lower() == correct_answer.lower(), key
        
        # Try spell correction
        corrected = str(TextBlob(user_answer).correct())
        
        if corrected.lower() == correct_answer:
            return True, corrected
        
        # Try fuzzy matching
        if fuzz.ratio(user_answer, correct_answer) >= 85:
            return True, correct_answer
        
        # Not correct
        return False, correct_answer
    
    def _update_adaptive_session_metrics(self, session):
        """Update session metrics for adaptive test"""
        responses = AdaptiveTestResponse.objects.filter(session=session)
        
        if responses.exists():
            # Calculate accuracy
            correct_count = responses.filter(is_correct=True).count()
            total_count = responses.count()
            accuracy = correct_count / total_count
            
            # Calculate average response time
            avg_time = responses.aggregate(avg_time=models.Avg('response_time'))['avg_time']
            
            # Calculate stats by category
            categories = {}
            for category in responses.values_list('question__category', flat=True).distinct():
                cat_responses = responses.filter(question__category=category)
                cat_correct = cat_responses.filter(is_correct=True).count()
                cat_accuracy = cat_correct / cat_responses.count()
                cat_avg_difficulty = cat_responses.aggregate(
                    avg=models.Avg('question__difficulty')
                )['avg']
                
                categories[category] = {
                    'accuracy': cat_accuracy,
                    'avg_difficulty': cat_avg_difficulty,
                    'questions_answered': cat_responses.count()
                }
            
            # Preserve existing metrics instead of overwriting
            # Get current metrics or initialize if None
            current_metrics = session.metrics or {}
            
            # Update performance metrics but preserve other fields like completed_categories
            performance_metrics = {
                'accuracy': accuracy,
                'avg_response_time': avg_time,
                'total_questions': total_count,
                'correct_answers': correct_count,
                'categories': categories
            }
            
            # Merge the dictionaries, preserving special fields
            for key, value in performance_metrics.items():
                current_metrics[key] = value
                
            # Update session with merged metrics
            session.metrics = current_metrics
            session.save()
    
    def _generate_adaptive_test_report(self, session):
        """Generate a comprehensive test report for adaptive test"""
        # Get all responses for this session
        responses = AdaptiveTestResponse.objects.filter(
            session=session
        ).select_related('question')
        
        if not responses.exists():
            return {
                'message': 'No test data available'
            }
        
        # Calculate test statistics
        test_stats = {
            'total_questions': responses.count(),
            'correct_answers': responses.filter(is_correct=True).count(),
            'accuracy': responses.filter(is_correct=True).count() / responses.count(),
            'avg_response_time': responses.aggregate(avg=models.Avg('response_time'))['avg'],
            'categories': {}
        }
        
        # Calculate stats by category
        for category in responses.values_list('question__category', flat=True).distinct():
            cat_responses = responses.filter(question__category=category)
            cat_correct = cat_responses.filter(is_correct=True).count()
            
            test_stats['categories'][category] = {
                'questions': cat_responses.count(),
                'correct': cat_correct,
                'accuracy': cat_correct / cat_responses.count(),
                'avg_difficulty': cat_responses.aggregate(avg=models.Avg('question__difficulty'))['avg'],
                'avg_time': cat_responses.aggregate(avg=models.Avg('response_time'))['avg']
            }
        
        # Format report
        report = {
            'student': {
                'id': session.student.id,
                'name': session.student.user.name,
                'email': session.student.user.email,
                'class': session.student.student_class,
                'section': session.student.section
            },
            'test_details': {
                'started_at': session.created_at,
                'completed_at': session.completed_at,
                'duration_minutes': (session.completed_at - session.created_at).total_seconds() / 60 if session.completed_at else (now() - session.created_at).total_seconds() / 60,
                'completed_categories': session.metrics.get('completed_categories', []) if session.metrics else []
            },
            'performance': test_stats,
            'detailed_responses': []
        }
        
        # Add detailed response data
        for response in responses:
            report['detailed_responses'].append({
                'question': response.question.question_text,
                'category': response.question.category,
                'difficulty': response.question.difficulty,
                'student_answer': response.student_answer,
                'correct_answer': response.question.correct_answer,
                'is_correct': response.is_correct,
                'response_time': response.response_time,
                'explanation': response.question.explanation
            })
        
        # Get career recommendations
        report['career_recommendations'] = self._get_career_recommendations(test_stats)
        
        return report
    
    def _get_career_recommendations(self, test_stats):
        """Generate career recommendations based on test performance"""
        try:
            recommendations = []
            
            # Generate recommendations for each category where accuracy is high
            for category, stats in test_stats['categories'].items():
                if stats['accuracy'] >= 0.7:  # If accuracy is high
                    # Map test categories to career fields
                    if category == 'Numerical_Reasoning':
                        careers = Career.objects.filter(
                            Q(name__icontains='engineer') | 
                            Q(name__icontains='finance') |
                            Q(name__icontains='banking')
                        )
                    elif category == 'Verbal_Aptitude':
                        careers = Career.objects.filter(
                            Q(name__icontains='writer') | 
                            Q(name__icontains='lawyer') |
                            Q(name__icontains='teacher')
                        )
                    elif category == 'Logical_Reasoning':
                        careers = Career.objects.filter(
                            Q(name__icontains='computer') | 
                            Q(name__icontains='law') |
                            Q(name__icontains='business')
                        )
                    elif category == 'Technical_Aptitude':
                        careers = Career.objects.filter(
                            Q(name__icontains='comp') | 
                            Q(name__icontains='tech') |
                            Q(name__icontains='engin')
                        )
                    else:
                        # Default to all careers
                        careers = Career.objects.all()[:3]
                    
                    # Add match scores
                    for career in careers:
                        recommendations.append({
                            'id': career.value,
                            'name': career.name,
                            'match_score': round(stats['accuracy'] * 100, 1),
                            'category': category.replace('_', ' ')
                        })
            
            # Return top 5 recommendations
            return sorted(recommendations, key=lambda x: x['match_score'], reverse=True)[:5]
            
        except Exception as e:
            print(f"Error generating career recommendations: {str(e)}")
            return []
    
    def _get_image_url(self, request, image_path):
        """Generate a full URL for an image path - using Azure storage with quiz-patterns blob"""
        if not image_path:
            return None
        
        from django.conf import settings
        
        # Get Azure Storage settings
        azure_account = getattr(settings, 'AZURE_ACCOUNT_NAME', None)
        azure_container = getattr(settings, 'AZURE_MEDIA_CONTAINER', 'media')
        
        # Generate Azure URL pointing to quiz-patterns blob
        # The format is https://{account}.blob.core.windows.net/{container}/quiz-patterns/{image}
        
        # Ensure we're using a clean image path without any directory prefixes
        image_filename = image_path
        if '/' in image_path:
            # Extract just the filename if there's a path
            image_filename = image_path.split('/')[-1]
        
        # Generate the full Azure URL
        azure_url = f"https://{azure_account}.blob.core.windows.net/{azure_container}/quiz-patterns/{image_filename}"
        
        print(f"Generated Azure image URL: {azure_url} from path: {image_path}")
        return azure_url
    
    # Helper methods for personality test
    
    def _create_new_personality_session(self, student):
        """Create a new personality test session"""
        session = PersonalityTestSession.objects.create(
            student=student,
            is_active=True
        )
        
        # Add welcome message
        PersonalityTestChatMessage.objects.create(
            session=session,
            sender='system',
            content='Welcome to your personality test! This test will help determine your personality type based on your preferences and tendencies.',
            message_type='greeting'
        )
        
        return session
    
    def _handle_complete_personality_test(self, request, session, student, test_type):
        """Handle completion of personality test"""
        if not session.is_active:
            return Response(
                {
                    "status": "error",
                    "message": "Test session is already completed"
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Mark the session as complete
        session.is_active = False
        session.completed_at = now()
        session.calculate_result()
        session.save()
        
        # Return completed test report
        return self._get_personality_test(request, student, str(session.session_id))
    
    def _generate_personality_test_report(self, session):
        """Generate a personality test report"""
        # Get the student
        student = session.student
        
        # Get the school safely
        try:
            school = student.school
            school_name = school.name if school else "Unknown School"
        except (AttributeError, Exception) as e:
            print(f"Warning: Error accessing school for student {student.id}: {str(e)}")
            school_name = "Unknown School"
        
        # Format dimensions for UI display
        dimensions = []
        for name, values in session.dimension_scores.items():
            dimension_data = {
                'name': name
            }
            
            if name == 'Extraversion_Introversion':
                dimension_data['left_label'] = 'Introvert'
                dimension_data['left_percentage'] = values['Introversion']
                dimension_data['right_label'] = 'Extrovert'
                dimension_data['right_percentage'] = values['Extraversion']
                dimension_data['left_description'] = ''
                dimension_data['right_description'] = ''
            elif name == 'Sensing_Intuition':
                dimension_data['left_label'] = 'Sensing'
                dimension_data['left_percentage'] = values['Sensing']
                dimension_data['right_label'] = 'iNtuitive'
                dimension_data['right_percentage'] = values['Intuition']
                dimension_data['left_description'] = '(Observant)'
                dimension_data['right_description'] = '(Futuristic)'
            elif name == 'Thinking_Feeling':
                dimension_data['left_label'] = 'Thinking'
                dimension_data['left_percentage'] = values['Thinking']
                dimension_data['right_label'] = 'Feeling'
                dimension_data['right_percentage'] = values['Feeling']
                dimension_data['left_description'] = ''
                dimension_data['right_description'] = ''
            elif name == 'Judging_Perceiving':
                dimension_data['left_label'] = 'Judging'
                dimension_data['left_percentage'] = values['Judging']
                dimension_data['right_label'] = 'Perceiving'
                dimension_data['right_percentage'] = values['Perceiving']
                dimension_data['left_description'] = '(Organized)'
                dimension_data['right_description'] = '(Spontaneous)'
            
            dimensions.append(dimension_data)
        
        # Format complete report
        report = {
            'student_name': student.user.name,
            'grade': f"{student.student_class}",
            'school_name': school_name,
            'personality_type': session.personality_type,
            'dimensions': dimensions,
            'session_id': str(session.session_id),
            'generated_at': now().isoformat()
        }
        
        # Store report in Azure
        storage_info = self._store_personality_report(
            session_id=session.session_id,
            student_id=student.id,
            report_data=report
        )
        
        # Add storage info to the report
        report['file'] = storage_info
        
        return report
    
    def _store_personality_report(self, session_id, student_id, report_data):
        """Store the personality test report in Azure Blob Storage"""
        try:
            # Generate a unique filename
            timestamp = now().strftime("%Y%m%d_%H%M%S")
            filename = f"personality_reports/student_{student_id}/{session_id}/report_{timestamp}.json"
            
            # Convert report data to JSON
            report_json = json.dumps(report_data, indent=2, default=str)
            
            # Store the report in Azure Blob Storage
            azure_storage = AzureMediaStorage()
            saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
            
            # Get the URL for the stored report
            try:
                report_url = azure_storage.url(saved_path)
            except Exception as e:
                # If URL generation fails, provide just the path
                report_url = f"/media/{saved_path}"
                print(f"Error generating URL for report: {str(e)}")
            
            return {
                'file_path': saved_path,
                'file_url': report_url
            }
        except Exception as e:
            print(f"Error storing report: {str(e)}")
            return {
                'file_path': None,
                'file_url': None,
                'error': str(e)
            }
    
    def _delete_previous_reports(self, student_id, test_type):
        """Delete previous reports from Azure Blob Storage"""
        try:
            # Determine the prefix based on test type
            if test_type == 'personality':
                prefix = f"personality_reports/student_{student_id}/"
            else:  # adaptive
                prefix = f"reports/student_{student_id}/"
                
            # Get Azure storage instance
            azure_storage = AzureMediaStorage()
            
            # List all files with the prefix
            try:
                # List directories (will return subdirectories under the prefix)
                directories, files = azure_storage.listdir(prefix)
                
                # For each session directory, delete its contents
                for directory in directories:
                    session_prefix = f"{prefix}{directory}/"
                    _, session_files = azure_storage.listdir(session_prefix)
                    
                    # Delete each file in the session directory
                    for file in session_files:
                        file_path = f"{session_prefix}{file}"
                        azure_storage.delete(file_path)
                        print(f"Deleted file: {file_path}")
                
                print(f"Successfully deleted previous {test_type} reports for student {student_id}")
            except Exception as e:
                # If listing fails, it might be because the directory doesn't exist yet
                print(f"Note: No previous reports found or error listing: {str(e)}")
        except Exception as e:
            # Log error but continue - failure to delete old reports shouldn't break the app
            print(f"Error deleting previous reports: {str(e)}")
            import traceback
            traceback.print_exc()
    
    # Report endpoint methods
    
    def _get_personality_report_by_session(self, student, session_id):
        """Get personality test report for a specific session"""
        try:
            session = PersonalityTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except PersonalityTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Ensure results are calculated
        if not session.personality_type or not session.dimension_scores:
            session.calculate_result()
        
        # Generate report
        report = self._generate_personality_test_report(session)
        
        # Return report
        return Response(report)
    
    def _get_personality_report_by_student(self, request, student_id):
        """Get latest personality test report for a student"""
        # Determine which student to use
        if student_id is None:
            # Use current user's profile
            if hasattr(request.user, 'student_profile'):
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "When no student ID is provided, you must be logged in as a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            # Student ID provided - verify permissions
            if hasattr(request.user, 'school_admin'):
                # School admin can access any student's report
                school = request.user.school_admin
                student = get_object_or_404(Student, id=student_id, school=school)
            elif hasattr(request.user, 'student_profile'):
                # Students can only access their own reports
                if int(student_id) != request.user.student_profile.id:
                    return Response(
                        {"error": "You can only access your own reports"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "User is neither a school admin nor a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        
        # Find the latest test session for this student
        latest_session = PersonalityTestSession.objects.filter(
            student=student,
            completed_at__isnull=False  # Only include completed sessions
        ).order_by('-completed_at').first()
        
        if not latest_session:
            return Response(
                {"error": "No completed personality test sessions found for this student"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Return report for this session
        return self._get_personality_report_by_session(student, latest_session.session_id)
    
    def _get_adaptive_report_by_session(self, student, session_id):
        """Get adaptive test report for a specific session"""
        try:
            session = AdaptiveTestSession.objects.get(
                session_id=session_id,
                student=student
            )
        except AdaptiveTestSession.DoesNotExist:
            return Response(
                {"error": "Test session not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Generate report
        report = self._generate_adaptive_test_report(session)
        
        # Return report
        return Response({
            "test_report": report,
            "test_type": "adaptive"
        })
    
    def _get_adaptive_report_by_student(self, request, student_id):
        """Get latest adaptive test report for a student"""
        # Determine which student to use
        if student_id is None:
            # Use current user's profile
            if hasattr(request.user, 'student_profile'):
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "When no student ID is provided, you must be logged in as a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        else:
            # Student ID provided - verify permissions
            if hasattr(request.user, 'school_admin'):
                # School admin can access any student's report
                school = request.user.school_admin
                student = get_object_or_404(Student, id=student_id, school=school)
            elif hasattr(request.user, 'student_profile'):
                # Students can only access their own reports
                if int(student_id) != request.user.student_profile.id:
                    return Response(
                        {"error": "You can only access your own reports"},
                        status=status.HTTP_403_FORBIDDEN
                    )
                student = request.user.student_profile
            else:
                return Response(
                    {"error": "User is neither a school admin nor a student"},
                    status=status.HTTP_403_FORBIDDEN
                )
        
        # Find the latest test session for this student
        latest_session = AdaptiveTestSession.objects.filter(
            student=student,
            completed_at__isnull=False  # Only include completed sessions
        ).order_by('-completed_at').first()
        
        if not latest_session:
            return Response(
                {"error": "No completed adaptive test sessions found for this student"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Return report for this session
        return self._get_adaptive_report_by_session(student, latest_session.session_id)
    
    #  general test

    def _get_general_test(self, request, student, session_id):
        # Auto-detect student from logged-in user if not provided
        if student is None and hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
        """Handle GET request for general test"""
        # If session_id provided, get that session
        if session_id:
            try:
                session = GeneralTestSession.objects.get(
                    session_id=session_id,
                    student=student
                )
            except GeneralTestSession.DoesNotExist:
                session = self._create_new_general_session(student)
        else:
            session = GeneralTestSession.objects.filter(
                student=student
            ).order_by('-created_at').first()
            if not session:
                session = self._create_new_general_session(student)

        # Get the conversation history
        chat_messages = GeneralTestChatMessage.objects.filter(
            session=session
        ).order_by('timestamp')

        conversation = []
        next_question = None
        current_message = "Welcome to the General Test!"

        for msg in chat_messages:
            chat_msg = {
                'sender': msg.sender,
                'message_type': msg.message_type,
                'content': msg.content,
                'timestamp': msg.timestamp
            }
            if msg.message_type == 'question' and msg.metadata and 'question_id' in msg.metadata:
                # Set as the current question if it's the most recent question without an answer
                if not GeneralTestResponse.objects.filter(
                    session=session,
                    question_id=msg.metadata.get('question_id')
                ).exists():
                    next_question = {
                        'question_id': msg.metadata.get('question_id'),
                        'question_text': msg.content
                    }
            conversation.append(chat_msg)
            if msg.message_type in ['greeting', 'question']:
                current_message = msg.content

        # If session is completed, return the results
        if not session.is_active and session.completed_at:
            completion_msg_exists = any(
                msg.message_type == 'completion' for msg in chat_messages
            )
            if not completion_msg_exists:
                completion_message = {
                    'sender': 'system',
                    'message_type': 'completion',
                    'content': "General test completed! Your responses have been saved.",
                    'timestamp': session.completed_at
                }
                conversation.append(completion_message)
            general_report = self._generate_general_test_report(session)
            return Response({
                "status": "success",
                "message": "General test completed! Your responses have been saved.",
                "conversation": conversation,
                "test_report": general_report,
                "session_id": str(session.session_id),
                "test_type": "general",
                "is_complete": True
            })

        # Regular response with conversation and next question
        response_data = {
            "status": "success",
            "message": current_message,
            "conversation": conversation,
            "session_id": str(session.session_id),
            "test_type": "general"
        }
        if next_question:
            response_data["next_question"] = next_question
        return Response(response_data)

    def _post_general_test(self, request, student, session_id, message, test_type):
        # Auto-detect student from logged-in user if not provided
        if student is None and hasattr(request.user, 'student_profile'):
            student = request.user.student_profile
        # Create new session if message is "start" and no session_id
        if message.lower() == "start" and not session_id:
            self._delete_previous_reports(student.id, 'general')
            session = self._create_new_general_session(student)
            return self._get_general_test(request, student, str(session.session_id))

        # Get existing session
        if session_id:
            session = GeneralTestSession.objects.filter(session_id=session_id, student=student).first()
            if not session:
                return Response({
                    "status": "error",
                    "message": f"Session with ID {session_id} not found"
                }, status=status.HTTP_404_NOT_FOUND)
        else:
            session = GeneralTestSession.objects.filter(student=student, is_active=True).order_by('-created_at').first()
            if not session:
                return Response({
                    "status": "error",
                    "message": "Please provide a session_id or send 'start' to create a new session"
                }, status=status.HTTP_400_BAD_REQUEST)

        # Check for completed session
        if not session.is_active:
            return Response({
                "status": "error",
                "message": "This session has already been completed. Please start a new session.",
                "is_complete": True,
                "test_type": "general",
                "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=general"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Check for command keywords
        if message.lower() in ['exit', 'quit', 'finish', 'complete', 'end']:
            return self._handle_complete_general_test(request, session, student, test_type)

        if message.lower() in ['start over', 'new test', 'reset', 'restart']:
            self._delete_previous_reports(student.id, 'general')
            new_session = self._create_new_general_session(student)
            return self._get_general_test(request, student, str(new_session.session_id))

        # Save answer to the current question (the latest question shown to the user)
        latest_question_msg = GeneralTestChatMessage.objects.filter(session=session, message_type='question').order_by('-timestamp').first()
        if not latest_question_msg or not latest_question_msg.metadata:
            return Response({"error": "No current question found to answer."}, status=status.HTTP_400_BAD_REQUEST)
        question_id = latest_question_msg.metadata.get('question_id')
        current_question = get_object_or_404(GeneralTestQuestion, question_id=question_id)
        if GeneralTestResponse.objects.filter(session=session, question=current_question).exists():
            return Response({"error": "This question has already been answered."}, status=status.HTTP_400_BAD_REQUEST)
        GeneralTestResponse.objects.create(
            session=session,
            question=current_question,
            answer_text=message,
            response_time=0.0
        )
        GeneralTestChatMessage.objects.create(
            session=session,
            sender='student',
            content=message,
            message_type='answer'
        )

        # --- Gemini analysis after each answer ---
        responses = GeneralTestResponse.objects.filter(session=session).select_related('question').order_by('question__order')
        questions_data = []
        user_answers = {}
        for response in responses:
            questions_data.append({
                'order': response.question.order,
                'question_text': response.question.question_text
            })
            user_answers[response.question.order] = response.answer_text

        from .openai_service import analyze_student_profile
        analysis_result = analyze_student_profile(questions_data, user_answers)
        if analysis_result:
            # Ensure boolean fields are stored as True/False, not 1/0
            def to_bool(val):
                if isinstance(val, bool):
                    return val
                if isinstance(val, int):
                    return bool(val)
                if isinstance(val, str):
                    return val.lower() == 'true'
                return None

            # --- MODIFIED: Use GeneralTestAIAnalysis ---
            # Prepare all values to save as JSON
            ai_data = {
                'session': str(session.session_id),
                'student': student.id,
                'subject_name': analysis_result.get('subject_name'),
                'hobby_1': analysis_result.get('hobby_1'),
                'hobby_2': analysis_result.get('hobby_2'),
                'hobby_3': analysis_result.get('hobby_3'),
                'unique_qualities': analysis_result.get('unique_qualities'),
                'career_profession': analysis_result.get('career_profession'),
                'is_passion': to_bool(analysis_result.get('is_passion')),
                'is_family_influenced': to_bool(analysis_result.get('is_family_influenced')),
                'parental_profession_type': analysis_result.get('parental_profession_type'),
                'has_negotiation_skill': to_bool(analysis_result.get('has_negotiation_skill')),
                'is_public_service': to_bool(analysis_result.get('is_public_service')),
                'book_movie_genre': analysis_result.get('book_movie_genre'),
                'nature_exploration': to_bool(analysis_result.get('nature_exploration')),
                'cultural_exploration': to_bool(analysis_result.get('cultural_exploration')),
                'historical_exploration': to_bool(analysis_result.get('historical_exploration')),
                'socioeconomic_class': analysis_result.get('socioeconomic_class'),
                'upbringing_indicator': analysis_result.get('upbringing_indicator')
            }
            # Update AI analysis for this student (overwrite old if exists, regardless of session)
            GeneralTestAIAnalysis.objects.update_or_create(
                ai_json__student=student.id,
                defaults={
                    'ai_json': ai_data
                }
            )

        # Check if there are any more unanswered questions
        answered_ids = session.responses.values_list('question_id', flat=True)
        next_q = GeneralTestQuestion.objects.exclude(question_id__in=answered_ids).order_by('order').first()
        if next_q:
            GeneralTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=next_q.question_text,
                message_type='question',
                metadata={'question_id': next_q.question_id, 'order': next_q.order}
            )
            return self._get_general_test(request, student, str(session.session_id))
        else:
            # Test is complete
            session.completed_at = now()
            session.is_active = False
            session.save()
            GeneralTestChatMessage.objects.create(
                session=session,
                sender='system',
                content='You have completed the General Test.',
                message_type='completion'
            )
            return self._get_general_test(request, student, str(session.session_id))
    
    def _create_new_general_session(self, student):
        """Create a new general test session with welcome message"""
        self._delete_previous_reports(student.id, 'general')
        session = GeneralTestSession.objects.create(student=student, is_active=True)
        GeneralTestChatMessage.objects.create(
            session=session,
            sender='system',
            content='Welcome to the General Test! Please answer the following questions.',
            message_type='greeting'
        )
        # Add first question
        first_question = GeneralTestQuestion.objects.order_by('order').first()
        if first_question:
            GeneralTestChatMessage.objects.create(
                session=session,
                sender='system',
                content=first_question.question_text,
                message_type='question',
                metadata={'question_id': first_question.question_id, 'order': first_question.order}
            )
        return session

    def _handle_complete_general_test(self, request, session, student, test_type):
        """Handle completion of general test"""
        if not session.is_active:
            return Response({
                "status": "error",
                "message": "This session is already completed.",
                "test_type": "general",
                "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=general"
            }, status=status.HTTP_400_BAD_REQUEST)

        # Get all questions and responses
        questions_data = []
        user_answers = {}
        responses = GeneralTestResponse.objects.filter(session=session).select_related('question')
        
        for response in responses:
            questions_data.append({
                'order': response.question.order,
                'question_text': response.question.question_text
            })
            user_answers[response.question.order] = response.answer_text

        # Send to OpenAI for analysis
        from .openai_service import analyze_student_profile
        analysis_result = analyze_student_profile(questions_data, user_answers)
        
        if analysis_result:
            # Store OpenAI analysis with boolean fields as True/False
            def to_bool(val):
                if isinstance(val, bool):
                    return val
                if isinstance(val, int):
                    return bool(val)
                if isinstance(val, str):
                    return val.lower() == 'true'
                return None

            # --- MODIFIED: Use GeneralTestAIAnalysis with update_or_create ---
            GeneralTestAIAnalysis.objects.update_or_create(
                ai_json__student=student.id,
                ai_json__session=str(session.session_id),
                defaults={
                    'ai_json': {
                        'session': str(session.session_id),
                        'student': student.id,
                        'subject_name': analysis_result.get('subject_name'),
                        'hobby_1': analysis_result.get('hobby_1'),
                        'hobby_2': analysis_result.get('hobby_2'),
                        'hobby_3': analysis_result.get('hobby_3'),
                        'unique_qualities': analysis_result.get('unique_qualities'),
                        'career_profession': analysis_result.get('career_profession'),
                        'is_passion': to_bool(analysis_result.get('is_passion')),
                        'is_family_influenced': to_bool(analysis_result.get('is_family_influenced')),
                        'parental_profession_type': analysis_result.get('parental_profession_type'),
                        'has_negotiation_skill': to_bool(analysis_result.get('has_negotiation_skill')),
                        'is_public_service': to_bool(analysis_result.get('is_public_service')),
                        'book_movie_genre': analysis_result.get('book_movie_genre'),
                        'nature_exploration': to_bool(analysis_result.get('nature_exploration')),
                        'cultural_exploration': to_bool(analysis_result.get('cultural_exploration')),
                        'historical_exploration': to_bool(analysis_result.get('historical_exploration')),
                        'socioeconomic_class': analysis_result.get('socioeconomic_class'),
                        'upbringing_indicator': analysis_result.get('upbringing_indicator')
                    }
                }
            )

        # Mark session as complete
        session.is_active = False
        session.completed_at = now()
        session.save()

        GeneralTestChatMessage.objects.create(
            session=session,
            sender='system',
            content='You have completed the General Test.',
            message_type='completion'
        )

        # Return success response with report URL
        return Response({
            "status": "success",
            "message": "General test completed successfully.",
            "is_complete": True,
            "test_type": "general",
            "report_url": f"/api/school/chat/report/?session_id={session.session_id}&test_type=general"
        })
            
    def _generate_general_test_report(self, session):
        """Generate report for completed general test session"""
        # Get all responses
        responses = GeneralTestResponse.objects.filter(session=session).select_related('question')
        if not responses.exists():
            return {'message': 'No test data available'}
            
        questions_and_answers = []
        for response in responses:
            questions_and_answers.append({
                "question": response.question.question_text,
                "answer": response.answer_text,
                "order": response.question.order
            })
            
        report = {
            "session_id": str(session.session_id),
            "student": {
                "id": session.student.id,
                "name": session.student.user.name,
                "email": session.student.user.email,
                "class": session.student.student_class,
                "section": session.student.section
            },
            "test_details": {
                "started_at": session.created_at,
                "completed_at": session.completed_at,
                "duration_minutes": (session.completed_at - session.created_at).total_seconds() / 60 if session.completed_at else (now() - session.created_at).total_seconds() / 60
            },
            "questions_and_answers": sorted(questions_and_answers, key=lambda x: x['order'])
        }
        
        return report

    def _delete_previous_reports(self, student_id, test_type):
        """Delete previous reports for a student and test type (stub for parity)"""
        # Implement actual deletion logic if needed (e.g., from blob storage)
        pass

    # Report endpoint methods for general test
    def _get_general_report_by_session(self, student, session_id):
        """Get general test report for a specific session"""
        try:
            session = GeneralTestSession.objects.get(session_id=session_id, student=student)
        except GeneralTestSession.DoesNotExist:
            return Response({"error": "Test session not found"}, status=status.HTTP_404_NOT_FOUND)
            
        report = self._generate_general_test_report(session)

        # --- MODIFIED: Get Gemini analysis from GeneralTestAIAnalysis ---
        analysis = GeneralTestAIAnalysis.objects.filter(
            ai_json__student=student.id
        ).order_by('-id').first()
        if analysis:
            ai_json = analysis.ai_json
            ai_analysis = {
                "subject_name": ai_json.get("subject_name"),
                "hobbies": [
                    ai_json.get("hobby_1"),
                    ai_json.get("hobby_2"),
                    ai_json.get("hobby_3")
                ],
                "unique_qualities": ai_json.get("unique_qualities"),
                "career_profession": ai_json.get("career_profession"),
                "personality_indicators": {
                    "is_passion": ai_json.get("is_passion"),
                    "is_family_influenced": ai_json.get("is_family_influenced"),
                    "parental_profession_type": ai_json.get("parental_profession_type"),
                    "has_negotiation_skill": ai_json.get("has_negotiation_skill"),
                    "is_public_service": ai_json.get("is_public_service")
                },
                "interests": {
                    "book_movie_genre": ai_json.get("book_movie_genre"),
                    "nature_exploration": ai_json.get("nature_exploration"),
                    "cultural_exploration": ai_json.get("cultural_exploration"),
                    "historical_exploration": ai_json.get("historical_exploration")
                },
                "background": {
                    "socioeconomic_class": ai_json.get("socioeconomic_class"),
                    "upbringing_indicator": ai_json.get("upbringing_indicator")
                }
            }
        else:
            ai_analysis = None
            
        return Response({
            "test_report": report, 
            "test_type": "general",
            "ai_analysis": ai_analysis
        })

    def _get_general_report_by_student(self, request, student_id):
        # Auto-detect student_id from logged-in user if not provided
        if student_id is None and hasattr(request.user, 'student_profile'):
            student_id = request.user.student_profile.id
        """Get latest general test report for a student"""
        # Determine which student to use
        if student_id is None:
            if hasattr(request.user, 'student_profile'):
                student = request.user.student_profile
            else:
                return Response({"error": "When no student ID is provided, you must be logged in as a student"}, status=status.HTTP_403_FORBIDDEN)
        else:
            if hasattr(request.user, 'school_admin'):
                school = request.user.school_admin
                student = get_object_or_404(Student, id=student_id, school=school)
            elif hasattr(request.user, 'student_profile'):
                if int(student_id) != request.user.student_profile.id:
                    return Response({"error": "You can only access your own reports"}, status=status.HTTP_403_FORBIDDEN)
                student = request.user.student_profile
            else:
                return Response({"error": "User is neither a school admin nor a student"}, status=status.HTTP_403_FORBIDDEN)
        latest_session = GeneralTestSession.objects.filter(student=student, completed_at__isnull=False).order_by('-completed_at').first()
        if not latest_session:
            return Response({"error": "No completed general test sessions found for this student"}, status=status.HTTP_404_NOT_FOUND)
        return self._get_general_report_by_session(student, latest_session.session_id)
   
