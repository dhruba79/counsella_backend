import sys
import json
import uuid
from io import BytesIO
from PIL import Image
from django.core.files.uploadedfile import InMemoryUploadedFile
from datetime import datetime
from django.utils.timezone import now
from storage_backends import AzureMediaStorage
from django.core.files.base import ContentFile

def process_avatar_image(image_file, max_size=(300, 300), quality=85):
    """Process an uploaded image"""
    try:
        print(f"Processing image: {image_file.name}, size: {image_file.size}, type: {image_file.content_type}")
        
        # Open the uploaded image
        img = Image.open(image_file)
        print(f"Image opened successfully: {img.format}, {img.mode}, {img.size}")
        
        # Convert to RGB if necessary
        if img.mode not in ('RGB', 'L'):
            print(f"Converting image from {img.mode} to RGB")
            img = img.convert('RGB')
        
        # Resize image
        print(f"Resizing image from {img.size} to max size {max_size}")
        img.thumbnail(max_size, Image.LANCZOS)
        print(f"New image size: {img.size}")
        
        # Save to BytesIO
        output = BytesIO()
        img.save(output, format='JPEG', quality=quality)
        output.seek(0)
        
        # Important: Get the actual length of the content
        content_length = len(output.getvalue())
        print(f"Processed image size: {content_length} bytes")
        
        # Create a new InMemoryUploadedFile with the correct size
        new_file = InMemoryUploadedFile(
            output, 'ImageField', 
            f"{image_file.name.split('.')[0]}.jpg", 'image/jpeg',
            content_length, None
        )
        
        print("Image processing completed successfully")
        return new_file
        
    except Exception as e:
        print(f"Error in process_avatar_image: {str(e)}")
        raise

def store_test_report(session_id, student_id, report_data, report_type="detailed"):
    """
    Store a test report in Azure Blob Storage
    
    Args:
        session_id: The session ID of the test
        student_id: The ID of the student
        report_data: The report data to store (dict)
        report_type: The type of report (detailed or template)
        
    Returns:
        str: The URL of the stored report
    """
    # Generate a unique filename
    timestamp = now().strftime("%Y%m%d_%H%M%S")
    filename = f"reports/student_{student_id}/{session_id}/{report_type}_report_{timestamp}.json"
    
    # Convert report data to JSON
    report_json = json.dumps(report_data, indent=2)
    
    # Store the report in Azure Blob Storage
    azure_storage = AzureMediaStorage()
    saved_path = azure_storage.save(filename, ContentFile(report_json.encode('utf-8')))
    
    # Get the URL for the stored report
    report_url = azure_storage.url(saved_path)
    
    return {
        'file_path': saved_path,
        'file_url': report_url
    }