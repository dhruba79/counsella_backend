#!/usr/bin/env python3
"""
Script to create sample feedback questions for API testing (parent/teacher)
"""

import os
import sys
import django

# Add the project directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')
django.setup()

from school.models import FeedbackQuestion

questions = [
    # q1
    {
        "fid": "parent",
        "qid": "q1",
        "type": "checkbox",
        "label": "Choose unique qualities from list of qualities",
        "options": [
            "mimicry_impersonation", "storytelling_expressiveness", "performance_skills_stage",
            "imagination_creativity", "observation_emotional_awareness", "organizational_skills",
            "persistence_determination", "curiosity", "sense_of_justice_fairness", "initiative_drive",
            "problem_solving", "leadership", "communication_skills", "analytical_logical_thinking",
            "sense_of_responsibility", "calmness_under_pressure", "helpfulness_empathy", "numerical_ability",
            "patience", "attention_to_detail", "reading_habbit", "debating_argumentation",
            "steady_hands_manual_dexterity", "writing_skills"
        ],
        
    },
    {
        "fid": "teacher",
        "qid": "q1",
        "type": "checkbox",
        "label": "Choose unique qualities from list of qualities",
        "options": [
            "mimicry_impersonation", "storytelling_expressiveness", "performance_skills_stage",
            "imagination_creativity", "observation_emotional_awareness", "organizational_skills",
            "persistence_determination", "curiosity", "sense_of_justice_fairness", "initiative_drive",
            "problem_solving", "leadership", "communication_skills", "analytical_logical_thinking",
            "sense_of_responsibility", "calmness_under_pressure", "helpfulness_empathy", "numerical_ability",
            "patience", "attention_to_detail", "reading_habbit", "debating_argumentation",
            "steady_hands_manual_dexterity", "writing_skills"
        ],
        
    },

    # q2
    {
        "fid": "parent",
        "qid": "q2",
        "type": "checkbox",
        "label": "Has your kid participated any analytical activities ?",
        "options": [
            "strategic_games", "story_writing", "chess", "puzzles", "tinkering_with_gadgets",
            "building_things", "working_with_computers", "quiz", "None"
        ],
         
    },
    {
        "fid": "teacher",
        "qid": "q2",
        "type": "checkbox",
        "label": "Has your kid participated any analytical activities ?",
        "options": [
            "strategic_games", "story_writing", "chess", "puzzles", "tinkering_with_gadgets",
            "building_things", "working_with_computers", "quiz", "None"
        ],
        
    },

    # q3
    {
        "fid": "parent",
        "qid": "q3",
        "type": "checkbox",
        "label": "What is your kid main hobby ? (Categoriy only)",
        "options": [
            "literature", "sports_outdoor_activities", "performance_theatre_arts", "interested_current_affairs",
            "problem-solving_puzzles_strategy-games", "team_organisation",
            "observation_exploration", "research",
            "debate_discussions_argumentation", "experiments_scientific_enquiry",
            "building_making_tinkering", "technology_programming_computers","None"
        ],
        
    },
    {
        "fid": "teacher",
        "qid": "q3",
        "type": "checkbox",
        "label": "What is your kid main hobby ? (Categoriy only)",
        "options": [
            "literature", "sports_outdoor_activities", "performance_theatre_arts", "interested_current_affairs",
            "problem-solving_puzzles_strategy-games", "team_organisation",
            "observation_exploration", "research",
            "debate_discussions_argumentation", "experiments_scientific_enquiry",
            "building_making_tinkering", "technology_programming_computers", "None"
        ],
        
    },

    # q4
    {
        "fid": "parent",
        "qid": "q4",
        "type": "checkbox",
        "label": "Has your kid involved in any reading activity ?",
        "options": ["Newspaper", "Books", "Magazine/Gazzets", "None"],
        
    },
    {
        "fid": "teacher",
        "qid": "q4",
        "type": "checkbox",
        "label": "Has your kid involved in any reading activity ?",
        "options": ["Newspaper", "Books", "Magazine/Gazzets", "None"],
        
    },

    # q5
    {
        "fid": "parent",
        "qid": "q5",
        "type": "checkbox",
        "label": "Has your kid involved in any communication activuty ?",
        "options": [
            "dramatics", "debate", "storytelling", "oratory_competition",
            "discussions", "presentation", "None"
        ],
        
    },
    {
        "fid": "teacher",
        "qid": "q5",
        "type": "checkbox",
        "label": "Has your kid involved in any communication activuty ?",
        "options": [
            "dramatics", "debate", "storytelling", "oratory_competition",
            "discussions", "presentation", "None"
        ],
        
    },

    # q6
    {
        "fid": "parent",
        "qid": "q6",
        "type": "radio",
        "label": "Has your kid partcipated any leadership activity ?",
        "options": ["Yes", "No"],
       
    },
    {
        "fid": "teacher",
        "qid": "q6",
        "type": "radio",
        "label": "Has your kid partcipated any leadership activity ?",
        "options": ["Yes", "No"],
       
    },

    # q7
    {
        "fid": "parent",
        "qid": "q7",
        "type": "radio",
        "label": "Has your kid partcipated any sports activity ?",
        "options": ["Yes", "No"],
       
    },
    {
        "fid": "teacher",
        "qid": "q7",
        "type": "radio",
        "label": "Has your kid partcipated any sports activity ?",
        "options": ["Yes", "No"],
       
    },

    # q8
    {
        "fid": "parent",
        "qid": "q8",
        "type": "checkbox",
        "label": "Has your kid partcipated in music activity ?",
        "options": ["Vocal", "Instrumental", "None"],
        
    },
    {
        "fid": "teacher",
        "qid": "q8",
        "type": "checkbox",
        "label": "Has your kid partcipated in music activity ?",
        "options": ["Vocal", "Instrumental", "None"],
        
    },

    # q9
    {
        "fid": "parent",
        "qid": "q9",
        "type": "checkbox",
        "label": "Has your kid particilpated in Drwaing/Painting/Craftsmanship ?",
        "options": ["Drawing", "Painting", "Craftsman", "None"],
        
    },
    {
        "fid": "teacher",
        "qid": "q9",
        "type": "checkbox",
        "label": "Has your kid particilpated in Drwaing/Painting/Craftsmanship ?",
        "options": ["Drawing", "Painting", "Craftsman", "None"],
        
    }
]


def create_feedback_questions():
    created, existed = 0, 0
    for q in questions:
        obj, is_created = FeedbackQuestion.objects.get_or_create(
            fid=q["fid"],
            qid=q["qid"],
            defaults={
                "type": q["type"],
                "label": q["label"],
                "options": q["options"],
               
            }
        )
        if is_created:
            created += 1
            print(f"Created: {q['fid']} - {q['qid']} ({q['type']})")
        else:
            existed += 1
            print(f"Already exists: {q['fid']} - {q['qid']} ({q['type']})")

    print(f"\nSummary:")
    print(f"Created: {created} feedback questions")
    print(f"Already existed: {existed} feedback questions")
    print(f"Total feedback questions in database: {FeedbackQuestion.objects.count()}")

if __name__ == "__main__":
    create_feedback_questions()
