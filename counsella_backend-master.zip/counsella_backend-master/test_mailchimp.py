# test_mailchimp.py
import os
from pathlib import Path
from dotenv import read_dotenv
import mailchimp_transactional as MailchimpTransactional
### Testing the functionality of mailchimp providers
# BASE_DIR = Path(__file__).resolve().parent.parent

# env_file = os.path.join(BASE_DIR, '.env')
# print(f"Reading .env file from: {env_file}")
read_dotenv(".env")

api_key = os.getenv('MAILCHIMP_TRANSACTIONAL_API_KEY')
print(f"API Key: {api_key}")
print(f"API Key length: {len(api_key) if api_key else 0}")

try:
    mailchimp = MailchimpTransactional.Client(api_key)
    # Test with a simple ping
    response = mailchimp.users.ping()
    print(f"Mailchimp ping successful: {response}")
except Exception as e:
    print(f"Mailchimp error: {e}")
