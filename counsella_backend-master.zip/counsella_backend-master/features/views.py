from django.http import JsonResponse
from django.shortcuts import render
from django.views import View
from django.db import models
import requests
from bs4 import BeautifulSoup
from .models import FeaturesKeyword
from . import serializers
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

class GetFeaturesURLsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = serializers.FeaturesKeywordSerializer(data=request.data)

        if serializer.is_valid(raise_exception=True):
            name = serializer.data.get('name')
            keyword = serializer.data.get('keyword')
            count = serializer.data.get('count')

            # Save or update keyword details in the database
            features_keyword, created = FeaturesKeyword.objects.get_or_create(name=name, keyword=keyword)
            features_keyword.search_count += 1
            features_keyword.save()

            search_results = self.perform_google_search(keyword, count)
            return Response({'results': search_results}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def perform_google_search(self, keyword, count):
        search_results = []
        query = f'https://www.google.com/search?q={keyword}&num={count}'
        print (query)
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        }
        response = requests.get(query, headers=headers)
        print(response)

        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            for g in soup.find_all('div', class_='tF2Cxc'):
                title = g.find('h3').text if g.find('h3') else ''
                link = g.find('a')['href'] if g.find('a') else ''
                description = g.find('span', class_='aCOpRe').text if g.find('span', class_='aCOpRe') else ''
                search_results.append({'title': title, 'link': link, 'description': description})

        print (search_results)

        return search_results[:count]
