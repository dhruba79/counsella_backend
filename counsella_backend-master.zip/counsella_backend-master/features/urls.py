
from django.urls import path

from . import views

urlpatterns = [
    path('get/urls/', views.GetFeaturesURLsView.as_view(), name='features_get_urls'),

]
