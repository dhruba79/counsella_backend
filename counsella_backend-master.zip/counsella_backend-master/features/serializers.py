from rest_framework import serializers

from .models import FeaturesKeyword


class FeaturesKeywordSerializer(serializers.ModelSerializer):
    count = serializers.IntegerField(default=10)

    class Meta:
        model = FeaturesKeyword
        fields = ['name', 'keyword', 'count']

    # def validate(self, attrs):
    #     keyword = attrs.get('keyword')

    #     if not keyword:
    #         raise serializers.ValidationError('Keyword parameter is required')

    #     return attrs
