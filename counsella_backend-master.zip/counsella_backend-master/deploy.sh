#!/bin/bash
set -e

# If using Private Repo
# GIT_REPO_URL="https://dchaitanya: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@github.com/MyCareerMyWay/dj_mcmy.git"


# Replace {YOUR_PROJECT_MAIN_DIR_NAME} with your actual project directory name
PROJECT_MAIN_DIR_NAME="dj_mcmy"

# Clone repository
# git clone "$GIT_REPO_URL" "/home/ubuntu/$PROJECT_MAIN_DIR_NAME"

cd "/home/ubuntu/$PROJECT_MAIN_DIR_NAME"

# Make all .sh files executable
chmod +x scripts/*.sh

# Execute scripts for OS dependencies, Python dependencies, Gunicorn, Nginx, and starting the application
./scripts/instance_os_dependencies.sh
./scripts/python_dependencies.sh
./scripts/gunicorn.sh
./scripts/nginx.sh
# ./scripts/start_app.sh

# Restart services
sudo systemctl restart dj_mcmy.socket
sudo systemctl restart dj_mcmy.service
sudo systemctl restart nginx

# sudo service dj_mcmy stop
# sudo service nginx stop
# mv dj_mcmy dj_mcmy_4feb