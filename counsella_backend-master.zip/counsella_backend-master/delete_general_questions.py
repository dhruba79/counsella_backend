#!/usr/bin/env python3
"""
Script to delete all general assessment questions from the GeneralTestQuestion model.
Place this file in your Django project root (where manage.py is).
Usage:
  python delete_general_questions.py
"""

import os
import sys
import django

# Adjust these as needed for your project name and app location!
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dj_mcmy.settings')  # Update your Django project name here
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
django.setup()

from school.models import GeneralTestQuestion

def delete_all_questions():
    """Deletes all existing general test questions."""
    count = GeneralTestQuestion.objects.all().delete()[0]
    print(f"Deleted {count} existing questions.")

if __name__ == "__main__":
    delete_all_questions()
