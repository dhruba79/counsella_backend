from rest_framework import renderers


class ResponseRenderer(renderers.JSONRenderer):
    """
    Renderer which serializes to JSON.
    """

    charset = 'utf-8'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        """
        Render `data` into JSON, returning a bytestring.

        If the data contains an 'ErrorDetail' key, it is serialized as an
        error response. Otherwise, it is serialized as a normal response.
        """

        if 'ErrorDetail' in str(data):
            response = {'errors': data}
        else:
            response = data

        return super(ResponseRenderer, self).render(response)
